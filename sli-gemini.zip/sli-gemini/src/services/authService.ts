import api from './api';
import type { User, AccountType } from '@/interfaces/User';

export type { User, AccountType };

export async function loginUser(credentials: {
  email: string;
  password: string;
}) {
  const response = await api.post('/auth/login-user', credentials);
  return response.data;
}

export async function loginAdmin(credentials: {
  username: string;
  password: string;
}) {
  const response = await api.post('/auth/login-admin', credentials);
  return response.data;
}

export async function registerUser(data: {
  nama: string;
  email: string;
  password: string;
  password_confirmation?: string;
  no_telp?: string;
}) {
  const response = await api.post('/auth/register', data);
  return response.data;
}

export function saveLoginResponse(
  response: any,
  accountType: AccountType
): User {
  const token = response?.token;
  const user = response?.data;

  if (!token) {
    throw new Error('Token tidak ditemukan dari respons Laravel.');
  }

  if (!user || typeof user !== 'object') {
    throw new Error('Data akun tidak ditemukan dari respons Laravel.');
  }

  localStorage.setItem('token', token);
  localStorage.setItem('user', JSON.stringify(user));
  localStorage.setItem('account_type', accountType);

  window.dispatchEvent(new Event('auth-changed'));

  return user;
}

export function getToken(): string | null {
  return localStorage.getItem('token');
}

export function getUser(): User | null {
  try {
    const user = localStorage.getItem('user');
    return user ? JSON.parse(user) : null;
  } catch {
    return null;
  }
}

export function getUserName(): string {
  const user = getUser();

  return (
    user?.nama ||
    user?.name ||
    user?.nama_lengkap ||
    user?.username ||
    'Pengguna'
  );
}

export function getUserRole(): string {
  const accountType = localStorage.getItem('account_type');

  if (accountType === 'admin') {
    return 'admin';
  }

  const user = getUser();

  return String(
    user?.tipe ||
    user?.role ||
    user?.hak_akses ||
    user?.level ||
    'pengguna'
  ).toLowerCase();
}

export function isLoggedIn(): boolean {
  return !!getToken();
}

export function isAdmin(): boolean {
  return localStorage.getItem('account_type') === 'admin';
}

export function logoutUser(): void {
  localStorage.removeItem('token');
  localStorage.removeItem('user');
  localStorage.removeItem('account_type');

  window.dispatchEvent(new Event('auth-changed'));
}