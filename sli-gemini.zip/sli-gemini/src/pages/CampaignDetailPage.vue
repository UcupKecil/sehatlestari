
<template>
  <ion-page>
    <ion-header>
      <ion-toolbar color="primary">
        <ion-buttons slot="start">
          <ion-back-button default-href="/campaign" />
        </ion-buttons>
        <ion-title>Detail Campaign</ion-title>
      </ion-toolbar>
    </ion-header>

    <ion-content class="ion-padding">
      <ion-spinner v-if="loading" />

      <ion-text color="danger" v-if="error">
        <p>{{ error }}</p>
      </ion-text>

      <ion-card v-if="campaign">
        <ion-card-header>
          <ion-card-title>
            {{ campaign.judul || campaign.nama_campaign }}
          </ion-card-title>
          <ion-card-subtitle>
            Status: {{ campaign.status || 'Tidak diketahui' }}
          </ion-card-subtitle>
        </ion-card-header>

        <ion-card-content>
          <p>{{ campaign.deskripsi || 'Tidak ada deskripsi.' }}</p>
          <p>
            <strong>Target Dana:</strong>
            {{ formatRupiah(campaign.target_dana) }}
          </p>
          <p v-if="campaign.tanggal_mulai">
            <strong>Tanggal Mulai:</strong> {{ campaign.tanggal_mulai }}
          </p>
          <p v-if="campaign.batas_waktu">
            <strong>Batas Waktu:</strong> {{ campaign.batas_waktu }}
          </p>

          <ion-button
            expand="block"
            :router-link="`/donasi?campaign_id=${campaign.id}`"
          >
            Donasi Sekarang
          </ion-button>
        </ion-card-content>
      </ion-card>
    </ion-content>
  </ion-page>
</template>

<script setup lang="ts">
import { onMounted, ref } from 'vue';
import { useRoute } from 'vue-router';
import {
  IonPage, IonHeader, IonToolbar, IonTitle, IonContent,
  IonButtons, IonBackButton, IonCard, IonCardHeader,
  IonCardTitle, IonCardSubtitle, IonCardContent,
  IonButton, IonSpinner, IonText
} from '@ionic/vue';
import api from '../services/api';

const route = useRoute();

const campaign = ref<Record<string, any> | null>(null);
const loading = ref(false);
const error = ref('');

function formatRupiah(value?: number): string {
  return new Intl.NumberFormat('id-ID', {
    style: 'currency',
    currency: 'IDR',
    maximumFractionDigits: 0
  }).format(Number(value || 0));
}

onMounted(async () => {
  const id = Number(route.params.id);

  if (!Number.isInteger(id) || id <= 0) {
    error.value = 'ID campaign tidak valid.';
    return;
  }

  loading.value = true;

  try {
    const response = await api.get(`/campaigns/${id}`);
    const result = response.data?.data ?? response.data;
    campaign.value = result?.campaign ?? result;
  } catch (err: any) {
    error.value = err.response?.data?.message || 'Gagal mengambil detail campaign.';
  } finally {
    loading.value = false;
  }
});
</script>
