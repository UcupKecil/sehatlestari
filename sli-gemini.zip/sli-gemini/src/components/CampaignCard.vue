
<template>
  <ion-card class="campaign-card">
    <div class="campaign-image">
      <img
        v-if="imageUrl"
        :src="imageUrl"
        :alt="title"
        @error="imageError = true"
      />

      <div v-if="!imageUrl || imageError" class="image-placeholder">
        <div class="placeholder-circle">
          <ion-icon :icon="heartOutline" />
        </div>
        <span>{{ imageLabel }}</span>
      </div>

      <ion-badge
        class="status-badge"
        :color="status.toLowerCase() === 'aktif' ? 'success' : 'medium'"
      >
        {{ status }}
      </ion-badge>
    </div>

    <ion-card-content>
      <div class="campaign-category">
        <ion-icon :icon="leafOutline" />
        <span>Program Kebaikan</span>
      </div>

      <h2>{{ title }}</h2>

      <p class="campaign-description">
        {{ shortDescription }}
      </p>

      <div class="target-box">
        <div>
          <span class="target-label">Target dana</span>
          <strong>{{ formatRupiah(targetDana) }}</strong>
        </div>

        <ion-icon :icon="walletOutline" />
      </div>

      <div class="deadline">
        <ion-icon :icon="calendarOutline" />
        <span>{{ deadlineText }}</span>
      </div>

      <ion-button
        expand="block"
        color="success"
        class="detail-button"
        @click="openDetail"
      >
        Lihat Detail
        <ion-icon slot="end" :icon="arrowForwardOutline" />
      </ion-button>
    </ion-card-content>
  </ion-card>
</template>

<script setup lang="ts">
import { computed, ref, watch } from 'vue';
import { useRouter } from 'vue-router';

import {
  IonCard,
  IonCardContent,
  IonBadge,
  IonIcon,
  IonButton
} from '@ionic/vue';

import {
  heartOutline,
  leafOutline,
  walletOutline,
  calendarOutline,
  arrowForwardOutline
} from 'ionicons/icons';

const props = withDefaults(
  defineProps<{
    id: number;
    title: string;
    description?: string;
    targetDana?: number;
    status?: string;
    deadline?: string;
    image?: string;
  }>(),
  {
    description: '',
    targetDana: 0,
    status: 'Aktif',
    deadline: '',
    image: ''
  }
);

const router = useRouter();
const imageError = ref(false);

watch(
  () => props.image,
  () => {
    imageError.value = false;
  }
);

const imageUrl = computed(() => {
  if (!props.image || imageError.value) return '';

  if (
    props.image.startsWith('http://') ||
    props.image.startsWith('https://')
  ) {
    return props.image;
  }

  const serverUrl = 'https://sehatlestariindonesia.vps-m.com';
  const path = props.image.startsWith('/')
    ? props.image
    : `/${props.image}`;

  return `${serverUrl}${path}`;
});

const shortDescription = computed(() => {
  if (!props.description) {
    return 'Mari bersama membantu sesama melalui program kebaikan ini.';
  }

  return props.description.length > 110
    ? `${props.description.substring(0, 110)}...`
    : props.description;
});

const deadlineText = computed(() => {
  if (!props.deadline) return 'Batas waktu belum tersedia';

  const date = new Date(props.deadline);

  if (Number.isNaN(date.getTime())) return props.deadline;

  return `Batas: ${date.toLocaleDateString('id-ID', {
    day: 'numeric',
    month: 'long',
    year: 'numeric'
  })}`;
});

const imageLabel = computed(() => {
  const text = props.title.toLowerCase();

  if (text.includes('sembako')) return 'Bantuan Sembako';
  if (text.includes('sumur') || text.includes('air')) return 'Air Bersih';
  if (text.includes('yatim')) return 'Santunan Anak Yatim';
  if (text.includes('kesehatan')) return 'Bantuan Kesehatan';

  return 'Program Kebaikan';
});

const formatRupiah = (value: number) => {
  return new Intl.NumberFormat('id-ID', {
    style: 'currency',
    currency: 'IDR',
    maximumFractionDigits: 0
  }).format(value || 0);
};

const openDetail = () => {
  router.push(`/campaign/${props.id}`);
};
</script>

<style scoped>
.campaign-card {
  margin: 0;
  border-radius: 20px;
  overflow: hidden;
  background: #ffffff;
  box-shadow: 0 5px 18px rgba(24, 70, 43, 0.07);
}

.campaign-image {
  height: 175px;
  position: relative;
  overflow: hidden;
  background: linear-gradient(135deg, #d9f2df, #a9dfb9);
}

.campaign-image img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.image-placeholder {
  height: 100%;
  width: 100%;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  gap: 10px;
  color: #176b3b;
  background:
    radial-gradient(circle at 20% 20%, #f1fff3 0 8%, transparent 9%),
    radial-gradient(circle at 80% 75%, #bce8c7 0 12%, transparent 13%),
    linear-gradient(135deg, #e6f8e9, #b7e5c2);
}

.placeholder-circle {
  width: 66px;
  height: 66px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  background: rgba(255, 255, 255, 0.75);
}

.placeholder-circle ion-icon {
  font-size: 34px;
}

.image-placeholder span {
  font-size: 13px;
  font-weight: 800;
}

.status-badge {
  position: absolute;
  top: 12px;
  right: 12px;
  padding: 7px 11px;
  border-radius: 20px;
  font-size: 10px;
  font-weight: 700;
}

ion-card-content {
  padding: 16px;
}

.campaign-category {
  display: flex;
  align-items: center;
  gap: 5px;
  color: #16834a;
  font-size: 11px;
  font-weight: 700;
  margin-bottom: 9px;
}

.campaign-category ion-icon {
  font-size: 15px;
}

h2 {
  color: #183c29;
  font-size: 17px;
  line-height: 1.4;
  font-weight: 800;
  margin: 0 0 8px;
}

.campaign-description {
  color: #718078;
  font-size: 12px;
  line-height: 1.6;
  margin: 0 0 14px;
}

.target-box {
  background: #f0f8f2;
  border-radius: 13px;
  padding: 12px;
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.target-box div {
  display: flex;
  flex-direction: column;
  gap: 5px;
}

.target-label {
  font-size: 10px;
  color: #819187;
}

.target-box strong {
  color: #16834a;
  font-size: 15px;
  font-weight: 800;
}

.target-box ion-icon {
  color: #16834a;
  font-size: 23px;
}

.deadline {
  display: flex;
  align-items: center;
  gap: 7px;
  color: #84918a;
  font-size: 11px;
  margin: 13px 0;
}

.deadline ion-icon {
  font-size: 16px;
}

.detail-button {
  --border-radius: 12px;
  height: 43px;
  font-size: 12px;
  font-weight: 700;
  margin: 0;
}
</style>
