
<template>
  <ion-page>
    <ion-header>
      <ion-toolbar color="primary">
        <ion-buttons slot="start">
          <ion-back-button default-href="/campaign" />
        </ion-buttons>
        <ion-title>Form Donasi</ion-title>
      </ion-toolbar>
    </ion-header>

    <ion-content class="ion-padding">
      <h2>Salurkan Donasi Anda</h2>
      <p>Isi formulir berikut untuk melakukan donasi.</p>

      <form @submit.prevent="submitDonasi">
        <ion-item>
          <ion-label position="stacked">ID Campaign</ion-label>
          <ion-input
            v-model.number="form.campaign_id"
            type="number"
            required
          />
        </ion-item>

        <ion-item>
          <ion-label position="stacked">ID Kategori Dana</ion-label>
          <ion-input
            v-model.number="form.kategori_dana_id"
            type="number"
            required
          />
        </ion-item>

        <ion-item>
          <ion-label position="stacked">ID Rekening Kas</ion-label>
          <ion-input
            v-model.number="form.rekening_kas_id"
            type="number"
            required
          />
        </ion-item>

        <ion-item>
          <ion-label position="stacked">Nama Pemberi</ion-label>
          <ion-input
            v-model="form.nama_pemberi"
            placeholder="Masukkan nama"
            required
          />
        </ion-item>

        <ion-item>
          <ion-label position="stacked">Jumlah Donasi (Rp)</ion-label>
          <ion-input
            v-model.number="form.jumlah"
            type="number"
            min="1"
            required
          />
        </ion-item>

        <ion-item>
          <ion-label position="stacked">Metode Pembayaran</ion-label>
          <ion-select
            v-model="form.metode_pembayaran"
            placeholder="Pilih metode"
            required
          >
            <ion-select-option value="transfer_bank">
              Transfer Bank
            </ion-select-option>
            <ion-select-option value="tunai">
              Tunai
            </ion-select-option>
          </ion-select>
        </ion-item>

        <ion-item>
          <ion-label position="stacked">Catatan (Opsional)</ion-label>
          <ion-textarea
            v-model="form.catatan"
            placeholder="Tuliskan doa atau pesan"
            :auto-grow="true"
          />
        </ion-item>

        <ion-button
          type="submit"
          expand="block"
          class="ion-margin-top"
          :disabled="loading"
        >
          {{ loading ? 'Mengirim...' : 'Kirim Donasi' }}
        </ion-button>
      </form>

      <ion-text color="success" v-if="success">
        <p>{{ success }}</p>
      </ion-text>
      <ion-text color="danger" v-if="error">
        <p>{{ error }}</p>
      </ion-text>
    </ion-content>
  </ion-page>
</template>

<script setup lang="ts">
import { reactive, ref, watch } from 'vue';
import { useRoute } from 'vue-router';
import {
  IonPage, IonHeader, IonToolbar, IonTitle, IonContent,
  IonButtons, IonBackButton, IonItem, IonLabel, IonInput,
  IonSelect, IonSelectOption, IonTextarea, IonButton, IonText
} from '@ionic/vue';
import { createDonasi } from '../services/donasiService';

const route = useRoute();

const form = reactive({
  campaign_id: Number(route.query.campaign_id) || 0,
  kategori_dana_id: 0,
  rekening_kas_id: 0,
  nama_pemberi: '',
  jumlah: 0,
  metode_pembayaran: 'transfer_bank',
  catatan: ''
});

const loading = ref(false);
const success = ref('');
const error = ref('');

watch(
  () => route.query.campaign_id,
  value => {
    form.campaign_id = Number(value) || 0;
  }
);

async function submitDonasi() {
  success.value = '';
  error.value = '';

  if (
    !form.campaign_id ||
    !form.kategori_dana_id ||
    !form.rekening_kas_id ||
    !form.nama_pemberi.trim() ||
    form.jumlah <= 0
  ) {
    error.value = 'Mohon lengkapi semua data wajib dengan benar.';
    return;
  }

  loading.value = true;

  try {
    const response = await createDonasi({ ...form });
    success.value =
      response?.message || 'Permintaan donasi berhasil dikirim.';
  } catch (err: any) {
    error.value =
      err.response?.data?.message || 'Donasi gagal dikirim. Silakan coba lagi.';
  } finally {
    loading.value = false;
  }
}
</script>
