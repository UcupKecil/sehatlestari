export interface Mustahik {
  id: number;
  nama: string;
  nik: string;
  kategori_asnaf: string;
  alamat: string;
  no_telp?: string;
  keterangan?: string;
  [key: string]: any;
}
