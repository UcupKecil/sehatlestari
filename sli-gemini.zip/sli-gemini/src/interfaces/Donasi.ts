export interface DonasiData {
  campaign_id: number;
  kategori_dana_id: number;
  rekening_kas_id: number;
  nama_pemberi: string;
  jumlah: number;
  metode_pembayaran: string;
  catatan?: string;
  [key: string]: any;
}
