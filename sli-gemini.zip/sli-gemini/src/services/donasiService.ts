
import api from './api';
import type { DonasiData } from '@/interfaces/Donasi';

// ===============================
// INTERFACE DONASI
// ===============================

export type { DonasiData };

// ===============================
// MENYIMPAN DONASI
// ===============================

export const createDonasi = async (data: DonasiData) => {
  const response = await api.post('/donasi/store', data);

  return response.data;
};

// ===============================
// CONTOH DATA DONASI
// ===============================

export const contohDonasi: DonasiData = {
  campaign_id: 1,
  kategori_dana_id: 1,
  rekening_kas_id: 1,
  nama_pemberi: 'Ahmad Fauzi',
  jumlah: 150000,
  metode_pembayaran: 'transfer_bank',
  catatan: 'Semoga berkah dan bermanfaat'
};
