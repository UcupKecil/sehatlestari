
import { createRouter, createWebHistory } from '@ionic/vue-router';
import type { RouteRecordRaw } from 'vue-router';
import { isAdmin, isLoggedIn } from '@/services/authService';

// HALAMAN PENGGUNA
import HomePage from '@/pages/HomePage.vue';
import ProfilPage from '@/pages/ProfilPage.vue';
import CampaignPage from '@/pages/CampaignPage.vue';
import CampaignDetailPage from '@/pages/CampaignDetailPage.vue';
import DonasiPage from '@/pages/DonasiPage.vue';
import ZakatPage from '@/pages/ZakatPage.vue';
import LoginPage from '@/pages/LoginPage.vue';
import RegisterPage from '@/pages/RegisterPage.vue';

// HALAMAN ADMIN
import DashboardPage from '@/pages/admin/DashboardPage.vue';
import MustahikPage from '@/pages/admin/MustahikPage.vue';
import RealisasiPage from '@/pages/admin/RealisasiPage.vue';
import OperasionalPage from '@/pages/admin/OperasionalPage.vue';
import CampaignAdminPage from '@/pages/admin/CampaignAdminPage.vue';

const routes: Array<RouteRecordRaw> = [
  {
    path: '/',
    redirect: '/home'
  },

  // =========================
  // ROUTE PENGGUNA
  // =========================

  {
    path: '/home',
    name: 'Home',
    component: HomePage
  },
  {
    path: '/profil',
    name: 'Profil',
    component: ProfilPage
  },
  {
    path: '/campaign',
    name: 'Campaign',
    component: CampaignPage
  },
  {
    path: '/campaign/:id',
    name: 'CampaignDetail',
    component: CampaignDetailPage,
    props: true
  },
  {
    path: '/donasi',
    name: 'Donasi',
    component: DonasiPage
  },
  {
    path: '/zakat',
    name: 'Zakat',
    component: ZakatPage
  },

  // =========================
  // ROUTE AUTENTIKASI
  // =========================

  {
    path: '/login',
    name: 'Login',
    component: () => import('@/pages/LoginPage.vue')
  },
  {
    path: '/register',
    name: 'Register',
    component: () => import('@/pages/RegisterPage.vue')
  },

  // =========================
  // ROUTE ADMIN
  // =========================

  {
    path: '/admin',
    redirect: '/admin/dashboard'
  },
  {
    path: '/admin/dashboard',
    name: 'AdminDashboard',
    component: DashboardPage,
    meta: {
      requiresAuth: true,
      requiresAdmin: true
    }
  },
  {
    path: '/admin/mustahik',
    name: 'AdminMustahik',
    component: MustahikPage,
    meta: {
      requiresAuth: true,
      requiresAdmin: true
    }
  },
  {
  path: '/admin/realisasi',
  name: 'AdminRealisasi',
  component: RealisasiPage,
  meta: {
    requiresAuth: true,
    requiresAdmin: true
  }
},
{
  path: '/admin/realisasi/:campaignId',
  name: 'AdminRealisasiCampaign',
  component: RealisasiPage,
  props: true,
  meta: {
    requiresAuth: true,
    requiresAdmin: true
  }
},
  {
    path: '/admin/operasional',
    name: 'AdminOperasional',
    component: OperasionalPage,
    meta: {
      requiresAuth: true,
      requiresAdmin: true
    }
  },
  {
    path: '/admin/campaign',
    name: 'AdminCampaign',
    component: CampaignAdminPage,
    meta: {
      requiresAuth: true,
      requiresAdmin: true
    }
  },

  // =========================
  // HALAMAN TIDAK DITEMUKAN
  // =========================

  {
    path: '/:pathMatch(.*)*',
    redirect: '/home'
  }
];

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes
});

// =========================
// NAVIGATION GUARD
// =========================

router.beforeEach((to, _from, next) => {
  const authenticated = isLoggedIn();
  const userIsAdmin = isAdmin();

  // Rute khusus admin: hanya boleh diakses akun dengan account_type === 'admin'
  if (to.meta.requiresAdmin) {
    if (!authenticated) {
      // Admin belum login -> arahkan ke halaman login
      next('/login');
      return;
    }

    if (!userIsAdmin) {
      // Pengguna biasa yang mencoba membuka URL admin diarahkan ke halaman utama
      next('/home');
      return;
    }
  }

  // Rute yang membutuhkan autentikasi umum
  if (to.meta.requiresAuth && !authenticated) {
    next('/login');
    return;
  }

  next();
});

export default router;
