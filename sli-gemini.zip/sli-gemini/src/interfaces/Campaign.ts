export interface KategoriDana {
  id: number;
  nama_kategori?: string;
  nama?: string;
  kategori?: string;
}

export interface PhotoPreview {
  id: number;
  file: File;
  url: string;
}

export interface Campaign {
  id: number;
  judul: string;
  slug?: string;
  kategori_dana_id: number;
  users_admin_id?: number;
  target_dana: number | string;
  dana_terkumpul?: number | string;
  tanggal_mulai: string;
  batas_waktu: string | null;
  lokasi?: string | null;
  deskripsi: string;
  foto_utama?: string | null;
  tipe_program?: string;
  status: string;
  kategori_dana?: KategoriDana;
  kategoriDana?: KategoriDana;
  [key: string]: any;
}
