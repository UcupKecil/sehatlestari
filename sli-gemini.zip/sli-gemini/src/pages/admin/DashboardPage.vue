
<template>
  <ion-page>
    <ion-content :fullscreen="true" class="dashboard-content">

      <div class="dashboard-wrapper">

        <!-- HEADER -->
        <section class="hero-header">
          <div class="top-header">
            <div class="brand">
              <img
                :src="logoSehatLestari"
                alt="Logo Sehat Lestari Indonesia"
                class="brand-logo"
              />

              <div class="brand-info">
                <h2>Sehat Lestari</h2>
                <span>Indonesia • Admin Panel</span>
              </div>
            </div>

            <!-- LOGOUT KANAN ATAS -->
            <button
              class="logout-header"
              @click="handleLogout"
              aria-label="Keluar dari akun"
              title="Keluar dari akun"
            >
              <ion-icon :icon="logOutOutline" />
            </button>
          </div>

          <div class="welcome-section">
            <span class="welcome-label">SELAMAT DATANG</span>
            <h1>{{ adminName }}</h1>
            <p>Kelola donasi dan program kebaikan hari ini.</p>
          </div>

          <div class="header-date">
            <ion-icon :icon="calendarOutline" />
            <span>{{ today }}</span>
          </div>
        </section>

        <!-- MAIN CONTENT -->
        <main class="main-content">

          <div class="section-heading">
            <div>
              <h2>Ringkasan Dashboard</h2>
              <p>Pantau perkembangan yayasan</p>
            </div>
            <span class="today-badge">Hari ini</span>
          </div>

          <!-- LOADING -->
          <div v-if="loading" class="loading-state">
            <ion-spinner name="crescent" />
            <span>Memuat data dashboard...</span>
          </div>

          <!-- ERROR -->
          <div v-if="errorMessage" class="error-state">
            <ion-icon :icon="alertCircleOutline" />
            <span>{{ errorMessage }}</span>
            <button @click="loadDashboard">Coba Lagi</button>
          </div>

          <!-- STATISTICS -->
          <div class="stats-grid">

            <div class="stat-card">
              <div class="stat-top">
                <div class="stat-icon green">
                  <ion-icon :icon="walletOutline" />
                </div>
                <span class="stat-caption">Donasi</span>
              </div>
              <h3>{{ statistics.donasi }}</h3>
              <p>Data belum tersedia</p>
            </div>

            <div class="stat-card">
              <div class="stat-top">
                <div class="stat-icon mint">
                  <ion-icon :icon="heartOutline" />
                </div>
                <span class="stat-caption">Program</span>
              </div>
              <h3>{{ statistics.campaign }}</h3>
              <p>Total campaign</p>
            </div>

            <div class="stat-card">
              <div class="stat-top">
                <div class="stat-icon orange">
                  <ion-icon :icon="peopleOutline" />
                </div>
                <span class="stat-caption">Penerima</span>
              </div>
              <h3>{{ statistics.mustahik }}</h3>
              <p>Total mustahik</p>
            </div>

            <div class="stat-card">
              <div class="stat-top">
                <div class="stat-icon blue">
                  <ion-icon :icon="handLeftOutline" />
                </div>
                <span class="stat-caption">Penyaluran</span>
              </div>
              <h3>{{ statistics.realisasi }}</h3>
              <p>Total data realisasi</p>
            </div>

          </div>

          <!-- DONATION SUMMARY -->
          <section class="content-card donation-card">
            <div class="card-heading">
              <div>
                <h3>Ringkasan Donasi</h3>
                <p>Informasi data donasi yayasan</p>
              </div>

              <div class="chart-icon">
                <ion-icon :icon="statsChartOutline" />
              </div>
            </div>

            <div class="chart-placeholder">
              <div class="chart-empty-icon">
                <ion-icon :icon="barChartOutline" />
              </div>

              <strong>Data donasi belum tersedia</strong>

              <p>
                Statistik donasi akan ditampilkan setelah
                tersedia endpoint daftar donasi.
              </p>
            </div>
          </section>

          <!-- RECENT ACTIVITY -->
          <section class="content-card activity-card">
            <div class="card-heading">
              <div>
                <h3>Aktivitas Terbaru</h3>
                <p>Informasi pengelolaan yayasan</p>
              </div>

              <ion-icon
                :icon="timeOutline"
                class="heading-icon"
              />
            </div>

            <div
              v-if="recentActivities.length"
              class="activity-list"
            >
              <div
                v-for="(activity, index) in recentActivities"
                :key="index"
                class="activity-item"
              >
                <div class="activity-dot"></div>

                <div class="activity-info">
                  <strong>{{ activity.title }}</strong>
                  <p>{{ activity.description }}</p>
                </div>
              </div>
            </div>

            <div v-else class="empty-activity">
              <div class="empty-icon">
                <ion-icon :icon="documentTextOutline" />
              </div>

              <strong>Belum ada aktivitas</strong>
              <p>Belum ada informasi aktivitas terbaru.</p>
            </div>
          </section>

        </main>

        <!-- BOTTOM NAVIGATION -->
        <nav class="bottom-navigation">

          <button
            class="nav-item active"
            @click="navigate('/admin/dashboard')"
          >
            <ion-icon :icon="homeOutline" />
            <span>Home</span>
          </button>

          <button
            class="nav-item"
            @click="navigate('/admin/campaign')"
          >
            <ion-icon :icon="heartOutline" />
            <span>Campaign</span>
          </button>

          <button
            class="nav-item"
            @click="navigate('/admin/mustahik')"
          >
            <ion-icon :icon="peopleOutline" />
            <span>Mustahik</span>
          </button>

          <button
            class="nav-item"
            @click="navigate('/admin/realisasi')"
          >
            <ion-icon :icon="receiptOutline" />
            <span>Realisasi</span>
          </button>

          <button
            class="nav-item"
            @click="navigate('/admin/operasional')"
          >
            <ion-icon :icon="businessOutline" />
            <span>Operasional</span>
          </button>

        </nav>

      </div>
    </ion-content>
  </ion-page>
</template>

<script setup lang="ts">
import { computed, onMounted, reactive, ref } from 'vue';
import { useRouter } from 'vue-router';

import {
  IonPage,
  IonContent,
  IonIcon,
  IonSpinner
} from '@ionic/vue';

import logoSehatLestari from '@/assets/logo-sehat-lestari.png';

import api from '@/services/api';

import {
  calendarOutline,
  walletOutline,
  heartOutline,
  peopleOutline,
  handLeftOutline,
  statsChartOutline,
  barChartOutline,
  timeOutline,
  documentTextOutline,
  receiptOutline,
  businessOutline,
  homeOutline,
  logOutOutline,
  alertCircleOutline
} from 'ionicons/icons';

import {
  getUserName,
  logoutUser
} from '@/services/authService';

const router = useRouter();

const loading = ref(false);
const errorMessage = ref('');

const statistics = reactive({
  donasi: '—',
  campaign: '0',
  mustahik: '0',
  realisasi: '0'
});

const recentActivities = ref<
  Array<{ title: string; description: string }>
>([]);

const adminName = computed(() => {
  return getUserName() || 'Superadmin';
});

const today = computed(() => {
  return new Intl.DateTimeFormat('id-ID', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
    year: 'numeric'
  }).format(new Date());
});

/*
|--------------------------------------------------------------------------
| Ekstraksi data respons API Laravel
|--------------------------------------------------------------------------
*/

function extractArray(response: any): any[] {
  let result = response?.data;

  for (let i = 0; i < 5; i++) {
    if (Array.isArray(result)) {
      return result;
    }

    if (!result || typeof result !== 'object') {
      return [];
    }

    if (Array.isArray(result.data)) {
      return result.data;
    }

    if (Array.isArray(result.data?.data)) {
      return result.data.data;
    }

    if (Array.isArray(result.items)) {
      return result.items;
    }

    if (Array.isArray(result.data?.items)) {
      return result.data.items;
    }

    result =
      result.data ??
      result.campaigns ??
      result.mustahik ??
      result.realisasi ??
      result.items;
  }

  return Array.isArray(result) ? result : [];
}

/*
|--------------------------------------------------------------------------
| Mengambil data dashboard
|--------------------------------------------------------------------------
*/

async function loadDashboard() {
  loading.value = true;
  errorMessage.value = '';

  recentActivities.value = [];

  try {
    const results = await Promise.allSettled([
      api.get('/campaigns'),
      api.get('/mustahik'),
      api.get('/realisasi')
    ]);

    let successCount = 0;

    // CAMPAIGN
    if (results[0].status === 'fulfilled') {
      const campaigns = extractArray(results[0].value);

      statistics.campaign = String(campaigns.length);
      successCount++;

      campaigns.slice(0, 2).forEach((item: any) => {
        recentActivities.value.push({
          title: 'Data campaign',
          description:
            item.nama_campaign ??
            item.nama ??
            item.judul ??
            'Campaign tersedia'
        });
      });
    }

    // MUSTAHIK
    if (results[1].status === 'fulfilled') {
      const mustahik = extractArray(results[1].value);

      statistics.mustahik = String(mustahik.length);
      successCount++;
    }

    // REALISASI
    if (results[2].status === 'fulfilled') {
      const realisasi = extractArray(results[2].value);

      statistics.realisasi = String(realisasi.length);
      successCount++;

      realisasi.slice(0, 2).forEach((item: any) => {
        recentActivities.value.push({
          title: 'Data realisasi',
          description:
            item.judul ??
            item.nama_campaign ??
            item.keterangan ??
            'Realisasi penyaluran tersedia'
        });
      });
    }

    if (successCount === 0) {
      errorMessage.value =
        'Data dashboard gagal diambil. Periksa koneksi dan API.';
    }

  } catch (error: any) {
    console.error('Dashboard error:', error);

    errorMessage.value =
      'Terjadi kesalahan saat mengambil data dashboard.';
  } finally {
    loading.value = false;
  }
}

/*
|--------------------------------------------------------------------------
| Navigasi dan logout
|--------------------------------------------------------------------------
*/

function navigate(path: string) {
  router.push(path);
}

function handleLogout() {
  logoutUser();
  router.replace('/login');
}

onMounted(() => {
  loadDashboard();
});
</script>

<style scoped>
/* DASHBOARD GLOBAL */

.dashboard-content {
  --background: #f2f7f3;
}

.dashboard-wrapper {
  min-height: 100%;
  padding-bottom: calc(82px + env(safe-area-inset-bottom, 0px));
  box-sizing: border-box;
}

/* HEADER */

.hero-header {
  background: linear-gradient(145deg, #104b32 0%, #087747 100%);
  color: white;
  padding: calc(22px + env(safe-area-inset-top, 0px)) 20px 27px;
  border-radius: 0 0 28px 28px;
}

.top-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
}

.brand {
  display: flex;
  align-items: center;
  gap: 11px;
  min-width: 0;
}

.brand-logo {
  width: 58px;
  height: 58px;
  object-fit: contain;
  background: white;
  border-radius: 12px;
  padding: 3px;
  flex-shrink: 0;
}

.brand-info {
  min-width: 0;
}

.brand-info h2 {
  color: white;
  font-size: 16px;
  font-weight: 800;
  margin: 0;
}

.brand-info span {
  display: block;
  color: #c9e6d5;
  font-size: 10px;
  margin-top: 3px;
  line-height: 1.4;
}

/* LOGOUT HEADER */

.logout-header {
  width: 42px;
  height: 42px;
  flex-shrink: 0;
  border: 1px solid rgba(255,255,255,.2);
  border-radius: 13px;
  background: rgba(255,255,255,.12);
  color: white;
  font-size: 21px;
  display: flex;
  align-items: center;
  justify-content: center;
}

.welcome-section {
  margin-top: 31px;
}

.welcome-label {
  color: #bce5ce;
  font-size: 10px;
  font-weight: 700;
  letter-spacing: 1.4px;
}

.welcome-section h1 {
  color: white;
  font-size: 27px;
  font-weight: 800;
  margin: 8px 0;
  overflow-wrap: anywhere;
}

.welcome-section p {
  color: #d3eadb;
  font-size: 12px;
  margin: 0;
}

.header-date {
  display: inline-flex;
  align-items: center;
  gap: 7px;
  margin-top: 20px;
  padding: 8px 12px;
  border-radius: 9px;
  background: rgba(255,255,255,.12);
  color: #e2f3e8;
  font-size: 11px;
}

/* MAIN CONTENT */

.main-content {
  padding: 23px 17px;
}

.section-heading {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 15px;
  gap: 8px;
}

.section-heading h2 {
  color: #173e2a;
  font-size: 17px;
  font-weight: 800;
  margin: 0;
}

.section-heading p {
  color: #829087;
  font-size: 11px;
  margin: 5px 0 0;
}

.today-badge {
  background: #e1f2e7;
  color: #16834b;
  padding: 7px 11px;
  border-radius: 20px;
  font-size: 10px;
  font-weight: 700;
  white-space: nowrap;
}

/* LOADING & ERROR */

.loading-state,
.error-state {
  background: white;
  border-radius: 13px;
  padding: 15px;
  margin-bottom: 14px;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 9px;
  color: #16834b;
  font-size: 12px;
}

.loading-state ion-spinner {
  width: 20px;
  height: 20px;
}

.error-state {
  flex-wrap: wrap;
  color: #b42318;
}

.error-state button {
  border: 0;
  background: #e7f5eb;
  color: #16834b;
  padding: 7px 12px;
  border-radius: 8px;
  font-size: 11px;
}

/* STATISTICS */

.stats-grid {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 12px;
}

.stat-card {
  background: white;
  border-radius: 17px;
  padding: 15px;
  min-width: 0;
  box-shadow: 0 3px 14px rgba(25, 75, 45, .045);
}

.stat-top {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 5px;
}

.stat-icon {
  width: 38px;
  height: 38px;
  border-radius: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 20px;
}

.stat-icon.green {
  color: #16834b;
  background: #e4f5e9;
}

.stat-icon.mint {
  color: #0e9271;
  background: #ddf5ed;
}

.stat-icon.orange {
  color: #d97706;
  background: #fff1d9;
}

.stat-icon.blue {
  color: #2875bd;
  background: #e6f1ff;
}

.stat-caption {
  color: #9aa69f;
  font-size: 10px;
}

.stat-card h3 {
  color: #17462e;
  font-size: 22px;
  font-weight: 800;
  margin: 17px 0 4px;
  overflow-wrap: anywhere;
}

.stat-card p {
  color: #849188;
  font-size: 11px;
  margin: 0;
}

/* CONTENT CARDS */

.content-card {
  background: white;
  border-radius: 18px;
  padding: 17px;
  margin-top: 19px;
  box-shadow: 0 3px 14px rgba(25, 75, 45, .045);
}

.card-heading {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 10px;
}

.card-heading h3 {
  color: #17432d;
  font-size: 15px;
  font-weight: 800;
  margin: 0;
}

.card-heading p {
  color: #8a978e;
  font-size: 11px;
  margin: 5px 0 0;
}

.chart-icon,
.chart-empty-icon {
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 11px;
  color: #16834b;
  background: #e6f5ea;
}

.chart-icon {
  width: 37px;
  height: 37px;
  font-size: 21px;
  flex-shrink: 0;
}

.chart-placeholder {
  min-height: 155px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  text-align: center;
  padding: 20px 12px;
}

.chart-empty-icon {
  width: 47px;
  height: 47px;
  border-radius: 15px;
  font-size: 25px;
  margin-bottom: 11px;
}

.chart-placeholder strong,
.empty-activity strong {
  color: #365b44;
  font-size: 12px;
}

.chart-placeholder p,
.empty-activity p {
  max-width: 240px;
  color: #9aa69e;
  font-size: 11px;
  line-height: 1.6;
  margin: 6px 0 0;
}

/* ACTIVITY */

.heading-icon {
  color: #16834b;
  font-size: 21px;
}

.empty-activity {
  min-height: 145px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  text-align: center;
  padding: 18px;
}

.empty-icon {
  width: 43px;
  height: 43px;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 14px;
  background: #e8f5eb;
  color: #16834b;
  font-size: 22px;
  margin-bottom: 10px;
}

.activity-list {
  margin-top: 18px;
}

.activity-item {
  display: flex;
  align-items: flex-start;
  gap: 11px;
  padding: 10px 0;
  border-bottom: 1px solid #edf2ee;
}

.activity-item:last-child {
  border-bottom: 0;
}

.activity-dot {
  width: 9px;
  height: 9px;
  border-radius: 50%;
  background: #16834b;
  margin-top: 4px;
  flex-shrink: 0;
}

.activity-info {
  min-width: 0;
}

.activity-info strong {
  display: block;
  color: #365b44;
  font-size: 12px;
}

.activity-info p {
  color: #8a978e;
  font-size: 11px;
  margin: 4px 0 0;
  overflow-wrap: anywhere;
}

/* BOTTOM NAVIGATION */

.bottom-navigation {
  position: fixed;
  z-index: 100;
  left: 0;
  right: 0;
  bottom: 0;

  height: calc(68px + env(safe-area-inset-bottom, 0px));
  padding: 8px 5px env(safe-area-inset-bottom, 0px);

  background: rgba(255,255,255,.98);
  border-top: 1px solid #e7eee8;

  display: grid;
  grid-template-columns: repeat(5, minmax(0, 1fr));

  box-shadow: 0 -4px 18px rgba(20, 65, 40, .06);
  box-sizing: border-box;
}

.nav-item {
  border: 0;
  background: transparent;
  color: #98a69c;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 5px;
  font-size: 9px;
  font-weight: 600;
  min-width: 0;
  padding: 0;
}

.nav-item ion-icon {
  font-size: 21px;
}

.nav-item.active {
  color: #16834b;
}

.nav-item.active ion-icon {
  background: #e3f4e8;
  padding: 5px 13px;
  border-radius: 20px;
  font-size: 20px;
}

/* TABLET */

@media (min-width: 600px) {
  .dashboard-wrapper {
    max-width: 600px;
    margin: 0 auto;
  }

  .hero-header {
    border-radius: 0 0 30px 30px;
  }

  .main-content {
    padding-left: 23px;
    padding-right: 23px;
  }

  .bottom-navigation {
    left: 50%;
    right: auto;
    width: 100%;
    max-width: 600px;
    transform: translateX(-50%);
  }
}

/* HP LAYAR KECIL */

@media (max-width: 380px) {
  .hero-header {
    padding-left: 15px;
    padding-right: 15px;
  }

  .main-content {
    padding-left: 12px;
    padding-right: 12px;
  }

  .brand-logo {
    width: 50px;
    height: 50px;
  }

  .brand-info h2 {
    font-size: 14px;
  }

  .brand-info span {
    font-size: 9px;
  }

  .logout-header {
    width: 38px;
    height: 38px;
  }

  .nav-item {
    font-size: 8px;
  }
}

/* SCROLLBAR DISEMBUNYIKAN, SCROLL TETAP AKTIF */

.dashboard-content::part(scroll) {
  scrollbar-width: none;
  -ms-overflow-style: none;
}

.dashboard-content::part(scroll)::-webkit-scrollbar {
  display: none;
  width: 0;
  height: 0;
}
</style>
