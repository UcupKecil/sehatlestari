import type { Campaign } from './Campaign';
import type { Mustahik } from './Mustahik';

export interface Realisasi {
  id?: number;
  campaign_kegiatan_id: number;
  mustahik_id: number;
  judul_laporan: string;
  jumlah_keluar: number | string;
  tanggal_realisasi: string;
  rincian_kegiatan: string;
  bukti_pencairan?: string | null;
  foto_kegiatan?: string | null;
  campaign?: Campaign;
  mustahik?: Mustahik;
  created_at?: string;
  updated_at?: string;
  [key: string]: any;
}
