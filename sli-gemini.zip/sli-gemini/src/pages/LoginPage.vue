<template>
  <ion-page>
    <ion-content :fullscreen="true" class="login-content">
      <div class="login-wrapper">
        <div class="login-card">

          <div class="brand">
            <div class="brand-icon">
              <ion-icon :icon="leafOutline" />
            </div>
            <h1>Sehat Lestari</h1>
            <p>Indonesia</p>
          </div>

          <div class="welcome">
            <h2>Selamat Datang</h2>
            <p>Silakan masuk ke akun Anda</p>
          </div>

          <div class="account-tabs">
            <button
              type="button"
              :class="{ active: accountType === 'pengguna' }"
              @click="changeAccountType('pengguna')"
            >
              Pengguna
            </button>

            <button
              type="button"
              :class="{ active: accountType === 'admin' }"
              @click="changeAccountType('admin')"
            >
              Admin
            </button>
          </div>

          <form @submit.prevent="handleLogin">

            <div class="field-group">
              <label>
                {{ accountType === 'admin' ? 'Username' : 'Email' }}
              </label>

              <ion-input
                v-model="identity"
                :type="accountType === 'admin' ? 'text' : 'email'"
                :placeholder="
                  accountType === 'admin'
                    ? 'Masukkan username'
                    : 'Masukkan alamat email'
                "
                class="custom-input"
                autocomplete="username"
                required
              />
            </div>

            <div class="field-group">
              <label>Password</label>

              <div class="password-wrapper">
                <ion-input
                  v-model="password"
                  :type="showPassword ? 'text' : 'password'"
                  placeholder="Masukkan password"
                  class="custom-input password-input"
                  autocomplete="current-password"
                  required
                />

                <button
                  type="button"
                  class="password-toggle"
                  @click="showPassword = !showPassword"
                  :aria-label="showPassword ? 'Sembunyikan password' : 'Tampilkan password'"
                >
                  <ion-icon
                    :icon="showPassword ? eyeOffOutline : eyeOutline"
                  />
                </button>
              </div>
            </div>

            <div v-if="errorMessage" class="error-message">
              {{ errorMessage }}
            </div>

            <ion-button
              expand="block"
              type="submit"
              class="login-button"
              :disabled="loading"
            >
              {{ loading ? 'Memproses...' : 'Masuk' }}
            </ion-button>

          </form>

          <div v-if="accountType === 'pengguna'" class="register-link">
            <span>Belum memiliki akun?</span>
            <router-link to="/register">Daftar sekarang</router-link>
          </div>

          <div v-else class="admin-info">
            Login khusus administrator dan amil yayasan.
          </div>

          <div class="back-link">
            <router-link to="/home">
              Kembali ke halaman utama
            </router-link>
          </div>

        </div>

        <p class="copyright">
          © {{ new Date().getFullYear() }} Sehat Lestari Indonesia
        </p>
      </div>
    </ion-content>
  </ion-page>
</template>

<script setup lang="ts">
import { ref } from 'vue';
import { useRouter } from 'vue-router';

import {
  IonPage,
  IonContent,
  IonInput,
  IonButton,
  IonIcon
} from '@ionic/vue';

import {
  leafOutline,
  eyeOutline,
  eyeOffOutline
} from 'ionicons/icons';

import {
  loginUser,
  loginAdmin,
  saveLoginResponse,
  logoutUser,
  type AccountType
} from '@/services/authService';

const router = useRouter();

const accountType = ref<AccountType>('pengguna');
const identity = ref('');
const password = ref('');

const showPassword = ref(false);
const loading = ref(false);
const errorMessage = ref('');

function changeAccountType(type: AccountType) {
  accountType.value = type;
  identity.value = '';
  password.value = '';
  errorMessage.value = '';
  showPassword.value = false;
}

function getErrorMessage(error: any): string {
  const response = error?.response?.data;

  if (response?.errors) {
    const firstError = Object.values(response.errors)[0];

    if (Array.isArray(firstError) && firstError.length > 0) {
      return String(firstError[0]);
    }
  }

  return (
    response?.message ||
    error?.message ||
    'Login gagal. Periksa kembali data akun Anda.'
  );
}

async function handleLogin() {
  errorMessage.value = '';

  if (!identity.value.trim() || !password.value) {
    errorMessage.value = 'Silakan lengkapi identitas dan password.';
    return;
  }

  loading.value = true;

  try {
    // Bersihkan sesi sebelumnya agar akun tidak tertukar.
    logoutUser();

    let response: any;
    let destination = '/home';

    if (accountType.value === 'admin') {
      response = await loginAdmin({
        username: identity.value.trim(),
        password: password.value
      });

      destination = '/admin/dashboard';
    } else {
      response = await loginUser({
        email: identity.value.trim(),
        password: password.value
      });

      destination = '/home';
    }

    saveLoginResponse(response, accountType.value);

    await router.replace(destination);

  } catch (error: any) {
    errorMessage.value = getErrorMessage(error);
  } finally {
    loading.value = false;
  }
}
</script>

<style scoped>
.login-content {
  --background: #f1f7f3;
}

.login-wrapper {
  min-height: 100%;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  padding: 28px 18px;
}

.login-card {
  width: 100%;
  max-width: 430px;
  background: #ffffff;
  border-radius: 22px;
  padding: 30px 25px;
  box-shadow: 0 12px 40px rgba(20, 83, 45, 0.09);
}

.brand {
  text-align: center;
  margin-bottom: 28px;
}

.brand-icon {
  width: 62px;
  height: 62px;
  margin: 0 auto 12px;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 18px;
  background: #e5f5e9;
  color: #168348;
  font-size: 34px;
}

.brand h1 {
  color: #14532d;
  font-size: 23px;
  font-weight: 800;
  margin: 0;
}

.brand p {
  color: #168348;
  font-size: 14px;
  font-weight: 600;
  margin: 4px 0 0;
}

.welcome {
  margin-bottom: 22px;
}

.welcome h2 {
  color: #173b28;
  font-size: 23px;
  font-weight: 750;
  margin: 0 0 7px;
}

.welcome p {
  color: #64748b;
  font-size: 14px;
  margin: 0;
}

.account-tabs {
  display: flex;
  gap: 8px;
  padding: 5px;
  background: #f0f5f1;
  border-radius: 12px;
  margin-bottom: 24px;
}

.account-tabs button {
  flex: 1;
  border: none;
  border-radius: 9px;
  padding: 12px 8px;
  background: transparent;
  color: #64748b;
  font-size: 14px;
  font-weight: 650;
}

.account-tabs button.active {
  color: #ffffff;
  background: #168348;
  box-shadow: 0 3px 9px rgba(22, 131, 72, 0.2);
}

.field-group {
  margin-bottom: 18px;
}

.field-group label {
  display: block;
  color: #263b2e;
  font-size: 14px;
  font-weight: 650;
  margin-bottom: 8px;
}

.custom-input {
  --background: #f8faf9;
  --color: #263b2e;
  --placeholder-color: #94a3a0;
  --padding-start: 13px;
  --padding-end: 13px;
  --padding-top: 13px;
  --padding-bottom: 13px;
  border: 1px solid #dce7df;
  border-radius: 11px;
  font-size: 14px;
  min-height: 48px;
}

.password-wrapper {
  position: relative;
}

.password-input {
  padding-right: 40px;
}

.password-toggle {
  position: absolute;
  z-index: 5;
  right: 12px;
  top: 50%;
  transform: translateY(-50%);
  border: none;
  background: transparent;
  color: #64748b;
  font-size: 21px;
  padding: 5px;
}

.login-button {
  --background: #168348;
  --background-hover: #116b3a;
  --border-radius: 11px;
  --box-shadow: none;
  height: 48px;
  margin: 26px 0 0;
  font-weight: 700;
  font-size: 15px;
}

.error-message {
  padding: 11px 13px;
  background: #fff1f0;
  color: #b42318;
  border: 1px solid #ffd5d2;
  border-radius: 9px;
  font-size: 13px;
  line-height: 1.5;
}

.register-link {
  display: flex;
  justify-content: center;
  flex-wrap: wrap;
  gap: 5px;
  margin-top: 22px;
  font-size: 13px;
  color: #64748b;
}

.register-link a,
.back-link a {
  color: #168348;
  font-weight: 700;
  text-decoration: none;
}

.admin-info {
  margin-top: 20px;
  color: #64748b;
  font-size: 12px;
  text-align: center;
}

.back-link {
  text-align: center;
  margin-top: 23px;
  font-size: 13px;
}

.copyright {
  color: #82918a;
  font-size: 11px;
  text-align: center;
  margin-top: 22px;
}

@media (max-width: 360px) {
  .login-card {
    padding: 25px 18px;
  }
}
</style>