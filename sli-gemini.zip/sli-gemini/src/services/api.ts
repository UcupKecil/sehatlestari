
import axios from 'axios';
import router from '@/router';
import { logoutUser } from './authService';

const api = axios.create({
  baseURL: import.meta.env.VITE_API_BASE_URL,

  headers: {
    Accept: 'application/json'
  }
});

api.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');

  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }

  return config;
});

api.interceptors.response.use(
  (response) => response,
  (error) => {
    const status = error.response?.status;
    const requestUrl = error.config?.url || '';

    // Error selain 401 diteruskan ke pemanggil tanpa logout otomatis
    if (status !== 401) {
      return Promise.reject(error);
    }

    // Abaikan endpoint autentikasi agar proses login/register tidak terganggu
    const isAuthEndpoint =
      requestUrl.includes('/auth/login-user') ||
      requestUrl.includes('/auth/login-admin') ||
      requestUrl.includes('/auth/register');

    if (isAuthEndpoint) {
      return Promise.reject(error);
    }

    // Bersihkan sesi dan token yang tidak valid secara konsisten
    logoutUser();

    // Dapatkan path saat ini untuk menghindari redirect berulang / loop
    const currentPath =
      router?.currentRoute?.value?.path || window.location.pathname;

    if (currentPath !== '/login') {
      if (router && typeof router.replace === 'function') {
        router.replace('/login').catch(() => {
          if (window.location.pathname !== '/login') {
            window.location.href = '/login';
          }
        });
      } else if (window.location.pathname !== '/login') {
        window.location.href = '/login';
      }
    }

    return Promise.reject(error);
  }
);

export default api;
