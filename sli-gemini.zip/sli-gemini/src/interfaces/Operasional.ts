export interface KategoriOperasional {
  id: number;
  nama_kategori?: string;
  nama?: string;
  keterangan?: string;
  [key: string]: any;
}

export interface RekeningKas {
  id: number;
  nama_bank?: string;
  nomor_rekening?: string;
  nama_pemilik?: string;
  nama?: string;
  [key: string]: any;
}

export interface Operasional {
  id?: number;
  kategori_operasional_id: number;
  rekening_kas_id: number;
  jumlah: number | string;
  tanggal_pengeluaran: string;
  keterangan: string;
  bukti_transaksi?: string | null;
  kategori?: KategoriOperasional;
  rekening?: RekeningKas;
  [key: string]: any;
}
