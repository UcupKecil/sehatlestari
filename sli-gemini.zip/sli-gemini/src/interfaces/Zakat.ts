export interface ZakatData {
  jenis_zakat: string;
  total_harta: number;
  [key: string]: any;
}
