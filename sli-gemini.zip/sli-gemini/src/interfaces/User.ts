export type AccountType = 'pengguna' | 'admin';

export interface User {
  id?: number | string;
  nama?: string;
  name?: string;
  nama_lengkap?: string;
  email?: string;
  username?: string;
  tipe?: string;
  role?: string;
  hak_akses?: string;
  level?: string;
  no_telp?: string;
  [key: string]: any;
}
