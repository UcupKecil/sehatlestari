import api from './api';

export const getCampaigns = async () => {
  const response = await api.get('/campaigns');
  return response.data;
};

export const getCampaignDetail = async (id: number) => {
  const response = await api.get(`/campaigns/${id}`);
  return response.data;
};