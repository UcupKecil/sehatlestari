<template>
  <ion-header class="app-header">
    <ion-toolbar>
      <ion-title>
        <div class="header-brand">
          <ion-icon :icon="leafOutline" />
          <span>Sehat Lestari</span>
        </div>
      </ion-title>

      <div slot="end" class="header-actions">
        <template v-if="loggedIn">
          <div class="user-info">
            <span class="welcome-text">Selamat datang,</span>
            <strong>{{ userName }}</strong>
            <small>{{ roleLabel }}</small>
          </div>

          <ion-button
            fill="outline"
            size="small"
            class="logout-button"
            @click="handleLogout"
          >
            <ion-icon :icon="logOutOutline" slot="start" />
            Keluar
          </ion-button>
        </template>

        <ion-button
          v-else-if="!isAuthPage"
          fill="solid"
          size="small"
          class="login-button"
          @click="goToLogin"
        >
          Masuk
        </ion-button>
      </div>
    </ion-toolbar>
  </ion-header>
</template>

<script setup lang="ts">
import { ref, computed, onMounted, onUnmounted } from 'vue';
import { useRouter, useRoute } from 'vue-router';

import {
  IonHeader,
  IonToolbar,
  IonTitle,
  IonButton,
  IonIcon
} from '@ionic/vue';

import {
  leafOutline,
  logOutOutline
} from 'ionicons/icons';

import {
  getUserName,
  getUserRole,
  isLoggedIn,
  logoutUser
} from '@/services/authService';

const router = useRouter();
const route = useRoute();

const loggedIn = ref(false);
const userName = ref('');
const userRole = ref('');

const isAuthPage = computed(() => {
  return ['/login', '/register'].includes(route.path);
});

const roleLabel = computed(() => {
  if (userRole.value === 'admin') {
    return 'Administrator';
  }

  if (userRole.value === 'muzakki') {
    return 'Muzakki';
  }

  return userRole.value
    ? userRole.value.charAt(0).toUpperCase() + userRole.value.slice(1)
    : 'Pengguna';
});

function refreshAuth() {
  loggedIn.value = isLoggedIn();
  userName.value = getUserName();
  userRole.value = getUserRole();
}

function handleLogout() {
  logoutUser();
  refreshAuth();
  router.replace('/home');
}

function goToLogin() {
  router.push('/login');
}

onMounted(() => {
  refreshAuth();
  window.addEventListener('auth-changed', refreshAuth);
  window.addEventListener('storage', refreshAuth);
});

onUnmounted(() => {
  window.removeEventListener('auth-changed', refreshAuth);
  window.removeEventListener('storage', refreshAuth);
});
</script>

<style scoped>
.app-header ion-toolbar {
  --background: #ffffff;
  --color: #14532d;
  --border-color: #e5eee7;
}

.header-brand {
  display: flex;
  align-items: center;
  gap: 8px;
  color: #14532d;
  font-size: 17px;
  font-weight: 800;
}

.header-brand ion-icon {
  color: #168348;
  font-size: 23px;
}

.header-actions {
  display: flex;
  align-items: center;
  gap: 10px;
  padding-right: 10px;
}

.user-info {
  display: flex;
  flex-direction: column;
  align-items: flex-end;
  line-height: 1.35;
  max-width: 145px;
}

.welcome-text {
  color: #718078;
  font-size: 10px;
}

.user-info strong {
  color: #14532d;
  font-size: 12px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  max-width: 145px;
}

.user-info small {
  color: #168348;
  font-size: 10px;
}

.logout-button {
  --color: #b42318;
  --border-color: #f0c5c1;
  --border-radius: 9px;
  font-size: 11px;
  font-weight: 650;
  margin: 0;
}

.login-button {
  --background: #168348;
  --border-radius: 9px;
  font-size: 12px;
  font-weight: 700;
  margin: 0;
}

@media (max-width: 380px) {
  .header-brand {
    font-size: 14px;
  }

  .user-info {
    max-width: 95px;
  }

  .user-info strong {
    max-width: 95px;
  }

  .header-actions {
    gap: 5px;
    padding-right: 5px;
  }
}
</style>