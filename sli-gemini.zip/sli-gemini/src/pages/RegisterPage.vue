
<template>
  <ion-page>
    <ion-content :fullscreen="true" class="register-content">

      <div class="register-wrapper">

        <!-- HERO SECTION -->
        <section class="hero-section">

          <div class="decoration decoration-one"></div>
          <div class="decoration decoration-two"></div>

          <div class="brand">
            <div class="brand-logo">
              <ion-icon :icon="leafOutline" />
            </div>

            <div>
              <h2>Sehat Lestari</h2>
              <p>Berbagi Kebaikan Untuk Sesama</p>
            </div>
          </div>

          <div class="hero-content">

            <div class="hero-image">
              <div class="image-circle">
                <ion-icon :icon="peopleOutline" />
              </div>

              <div class="floating-icon icon-one">
                <ion-icon :icon="heartOutline" />
              </div>

              <div class="floating-icon icon-two">
                <ion-icon :icon="handLeftOutline" />
              </div>

              <div class="floating-icon icon-three">
                <ion-icon :icon="giftOutline" />
              </div>
            </div>

            <h1>Mari Bergabung dalam Kebaikan</h1>

            <p>
              Jadilah bagian dari gerakan kepedulian
              untuk membantu sesama dan menciptakan
              kehidupan yang lebih baik.
            </p>

          </div>

          <div class="hero-footer">
            <ion-icon :icon="heart" />
            <span>Bersama berbagi manfaat untuk sesama</span>
          </div>

        </section>

        <!-- FORM SECTION -->
        <section class="form-section">

          <div class="form-heading">
            <span class="welcome-label">BUAT AKUN BARU</span>

            <h2>Daftar Sekarang</h2>

            <p>
              Lengkapi informasi berikut untuk
              membuat akun Sehat Lestari Online.
            </p>
          </div>

          <form @submit.prevent="register">

            <!-- NAMA -->
            <div class="form-group">
              <label for="nama">Nama Lengkap</label>

              <div class="input-wrapper">
                <ion-icon
                  :icon="personOutline"
                  class="input-icon"
                />

                <ion-input
                  id="nama"
                  v-model="form.nama"
                  type="text"
                  placeholder="Masukkan nama lengkap"
                  autocomplete="name"
                  required
                />
              </div>
            </div>

            <!-- EMAIL -->
            <div class="form-group">
              <label for="email">Alamat Email</label>

              <div class="input-wrapper">
                <ion-icon
                  :icon="mailOutline"
                  class="input-icon"
                />

                <ion-input
                  id="email"
                  v-model="form.email"
                  type="email"
                  placeholder="nama@email.com"
                  autocomplete="email"
                  required
                />
              </div>
            </div>

            <!-- PASSWORD -->
            <div class="form-group">
              <label for="password">Password</label>

              <div class="input-wrapper">
                <ion-icon
                  :icon="lockClosedOutline"
                  class="input-icon"
                />

                <ion-input
                  id="password"
                  v-model="form.password"
                  :type="showPassword ? 'text' : 'password'"
                  placeholder="Buat password"
                  autocomplete="new-password"
                  required
                />

                <button
                  type="button"
                  class="password-toggle"
                  @click="showPassword = !showPassword"
                  aria-label="Tampilkan atau sembunyikan password"
                >
                  <ion-icon
                    :icon="showPassword ? eyeOffOutline : eyeOutline"
                  />
                </button>
              </div>
            </div>

            <!-- KONFIRMASI PASSWORD -->
            <div class="form-group">
              <label for="password_confirmation">
                Konfirmasi Password
              </label>

              <div class="input-wrapper">
                <ion-icon
                  :icon="shieldCheckmarkOutline"
                  class="input-icon"
                />

                <ion-input
                  id="password_confirmation"
                  v-model="form.password_confirmation"
                  :type="showConfirmation ? 'text' : 'password'"
                  placeholder="Ulangi password"
                  autocomplete="new-password"
                  required
                />

                <button
                  type="button"
                  class="password-toggle"
                  @click="showConfirmation = !showConfirmation"
                  aria-label="Tampilkan atau sembunyikan konfirmasi password"
                >
                  <ion-icon
                    :icon="showConfirmation ? eyeOffOutline : eyeOutline"
                  />
                </button>
              </div>
            </div>

            <!-- ERROR -->
            <div v-if="error" class="error-message">
              <ion-icon :icon="alertCircleOutline" />
              <span>{{ error }}</span>
            </div>

            <!-- SUCCESS -->
            <div v-if="success" class="success-message">
              <ion-icon :icon="checkmarkCircleOutline" />
              <span>{{ success }}</span>
            </div>

            <!-- BUTTON -->
            <ion-button
              type="submit"
              expand="block"
              class="register-button"
              :disabled="loading"
            >
              <span>
                {{ loading ? 'Mendaftarkan...' : 'Daftar Sekarang' }}
              </span>

              <ion-icon
                v-if="!loading"
                :icon="arrowForwardOutline"
                slot="end"
              />
            </ion-button>

          </form>

          <!-- LOGIN LINK -->
          <div class="login-section">
            <p>Sudah memiliki akun?</p>

            <router-link to="/login">
              Login di sini
            </router-link>
          </div>

          <!-- SECURITY -->
          <div class="security-info">
            <ion-icon :icon="shieldCheckmarkOutline" />
            <span>Data pendaftaran diproses secara aman.</span>
          </div>

          <div class="copyright">
            © 2026 Sehat Lestari Online
          </div>

        </section>

      </div>
    </ion-content>
  </ion-page>
</template>

<script setup lang="ts">
import { reactive, ref } from 'vue';
import { useRouter } from 'vue-router';

import {
  IonPage,
  IonContent,
  IonInput,
  IonButton,
  IonIcon
} from '@ionic/vue';

import {
  leafOutline,
  peopleOutline,
  heartOutline,
  heart,
  handLeftOutline,
  giftOutline,
  personOutline,
  mailOutline,
  lockClosedOutline,
  eyeOutline,
  eyeOffOutline,
  arrowForwardOutline,
  alertCircleOutline,
  shieldCheckmarkOutline,
  checkmarkCircleOutline
} from 'ionicons/icons';

import { registerUser } from '../services/authService';

const router = useRouter();

const form = reactive({
  nama: '',
  email: '',
  password: '',
  password_confirmation: ''
});

const loading = ref(false);
const success = ref('');
const error = ref('');

const showPassword = ref(false);
const showConfirmation = ref(false);

async function register() {
  success.value = '';
  error.value = '';

  if (
    !form.nama.trim() ||
    !form.email.trim() ||
    !form.password ||
    !form.password_confirmation
  ) {
    error.value = 'Semua kolom wajib diisi.';
    return;
  }

  if (form.password !== form.password_confirmation) {
    error.value = 'Konfirmasi password tidak sama.';
    return;
  }

  loading.value = true;

  try {
    const response = await registerUser({ ...form });

    success.value =
      response?.message || 'Pendaftaran berhasil. Silakan login.';

    setTimeout(() => {
      router.push('/login');
    }, 1200);

  } catch (err: any) {
    const validationErrors = err.response?.data?.errors;

    if (validationErrors) {
      error.value = Object.values(validationErrors)
        .flat()
        .join(' ');
    } else {
      error.value =
        err.response?.data?.message ||
        'Pendaftaran gagal. Silakan coba lagi.';
    }

  } finally {
    loading.value = false;
  }
}
</script>

<style scoped>
.register-content {
  --background: #ffffff;
}

.register-wrapper {
  min-height: 100%;
  display: flex;
  flex-direction: column;
}

/* HERO */

.hero-section {
  position: relative;
  overflow: hidden;
  background: linear-gradient(145deg, #087a43, #075c36);
  color: white;
  padding: 25px 24px 30px;
  border-radius: 0 0 32px 32px;
}

.decoration {
  position: absolute;
  border-radius: 50%;
  background: rgba(255, 255, 255, 0.07);
}

.decoration-one {
  width: 220px;
  height: 220px;
  top: -100px;
  right: -70px;
}

.decoration-two {
  width: 150px;
  height: 150px;
  bottom: -90px;
  left: -50px;
}

.brand {
  position: relative;
  z-index: 1;
  display: flex;
  align-items: center;
  gap: 12px;
}

.brand-logo {
  width: 45px;
  height: 45px;
  border-radius: 14px;
  background: rgba(255, 255, 255, 0.17);
  display: flex;
  align-items: center;
  justify-content: center;
}

.brand-logo ion-icon {
  font-size: 27px;
  color: white;
}

.brand h2 {
  font-size: 18px;
  font-weight: 800;
  margin: 0;
}

.brand p {
  font-size: 10px;
  margin: 4px 0 0;
  opacity: 0.8;
}

.hero-content {
  position: relative;
  z-index: 1;
  text-align: center;
  max-width: 390px;
  margin: 22px auto 0;
}

.hero-image {
  width: 155px;
  height: 125px;
  margin: 0 auto 16px;
  position: relative;
  display: flex;
  justify-content: center;
  align-items: center;
}

.image-circle {
  width: 112px;
  height: 112px;
  border-radius: 50%;
  background: rgba(255, 255, 255, 0.15);
  border: 1px solid rgba(255, 255, 255, 0.25);
  display: flex;
  align-items: center;
  justify-content: center;
}

.image-circle ion-icon {
  font-size: 65px;
  color: #d8f5df;
}

.floating-icon {
  position: absolute;
  width: 39px;
  height: 39px;
  border-radius: 13px;
  background: white;
  color: #16834a;
  display: flex;
  align-items: center;
  justify-content: center;
  box-shadow: 0 5px 15px rgba(0, 0, 0, 0.12);
}

.floating-icon ion-icon {
  font-size: 21px;
}

.icon-one {
  top: 0;
  left: 4px;
}

.icon-two {
  top: 8px;
  right: 0;
}

.icon-three {
  bottom: 0;
  right: 20px;
}

.hero-content h1 {
  font-size: 23px;
  line-height: 1.3;
  font-weight: 800;
  margin: 0 0 9px;
}

.hero-content p {
  max-width: 310px;
  margin: auto;
  font-size: 12px;
  line-height: 1.7;
  opacity: 0.85;
}

.hero-footer {
  position: relative;
  z-index: 1;
  display: flex;
  justify-content: center;
  align-items: center;
  gap: 7px;
  margin-top: 23px;
  font-size: 11px;
  opacity: 0.85;
}

/* FORM */

.form-section {
  width: 100%;
  max-width: 480px;
  padding: 30px 25px 22px;
  margin: 0 auto;
}

.form-heading {
  margin-bottom: 23px;
}

.welcome-label {
  color: #16834a;
  font-size: 10px;
  font-weight: 800;
  letter-spacing: 1.5px;
}

.form-heading h2 {
  color: #183b2a;
  font-size: 23px;
  font-weight: 800;
  margin: 9px 0;
}

.form-heading p {
  color: #819087;
  font-size: 12px;
  line-height: 1.6;
  margin: 0;
}

/* INPUT */

.form-group {
  margin-bottom: 16px;
}

.form-group label {
  display: block;
  color: #294a38;
  font-size: 12px;
  font-weight: 700;
  margin-bottom: 9px;
}

.input-wrapper {
  display: flex;
  align-items: center;
  min-height: 52px;
  padding: 0 13px;
  border: 1px solid #dce9df;
  border-radius: 12px;
  background: #f9fcfa;
  transition: 0.2s;
}

.input-wrapper:focus-within {
  border-color: #16834a;
  box-shadow: 0 0 0 3px rgba(22, 131, 74, 0.08);
}

.input-icon {
  font-size: 19px;
  color: #16834a;
  margin-right: 10px;
  flex-shrink: 0;
}

.input-wrapper ion-input {
  --color: #234632;
  --placeholder-color: #a0ada4;
  --placeholder-opacity: 1;
  font-size: 13px;
}

.password-toggle {
  border: none;
  background: transparent;
  color: #819087;
  font-size: 19px;
  padding: 7px;
  cursor: pointer;
}

/* BUTTON */

.register-button {
  --background: #16834a;
  --background-hover: #116b3c;
  --background-activated: #105f36;
  --border-radius: 12px;
  --box-shadow: 0 6px 15px rgba(22, 131, 74, 0.2);
  height: 51px;
  margin-top: 22px;
  font-size: 13px;
  font-weight: 700;
  text-transform: none;
}

/* MESSAGE */

.error-message,
.success-message {
  display: flex;
  align-items: flex-start;
  gap: 8px;
  padding: 12px;
  border-radius: 10px;
  font-size: 11px;
  line-height: 1.5;
  margin-top: 12px;
}

.error-message {
  background: #fff1f0;
  border: 1px solid #ffd8d5;
  color: #c0392b;
}

.success-message {
  background: #eaf8ef;
  border: 1px solid #ccebd6;
  color: #16834a;
}

.error-message ion-icon,
.success-message ion-icon {
  font-size: 17px;
  flex-shrink: 0;
}

/* LOGIN LINK */

.login-section {
  display: flex;
  justify-content: center;
  align-items: center;
  flex-wrap: wrap;
  gap: 5px;
  margin-top: 22px;
  font-size: 12px;
}

.login-section p {
  color: #849188;
  margin: 0;
}

.login-section a {
  color: #16834a;
  font-weight: 800;
  text-decoration: none;
}

/* FOOTER */

.security-info {
  display: flex;
  justify-content: center;
  align-items: center;
  gap: 6px;
  margin-top: 25px;
  color: #849188;
  font-size: 10px;
}

.security-info ion-icon {
  color: #16834a;
  font-size: 16px;
}

.copyright {
  text-align: center;
  color: #a4afa7;
  font-size: 10px;
  margin-top: 20px;
  padding-bottom: 10px;
}

/* RESPONSIVE */

@media (min-width: 768px) {
  .register-wrapper {
    min-height: 100%;
    flex-direction: row;
    align-items: stretch;
  }

  .hero-section {
    width: 50%;
    min-height: 100vh;
    border-radius: 0 35px 35px 0;
    display: flex;
    flex-direction: column;
    justify-content: center;
    padding: 40px;
  }

  .hero-content {
    margin-top: 45px;
  }

  .hero-image {
    transform: scale(1.2);
    margin-bottom: 35px;
  }

  .hero-content h1 {
    font-size: 30px;
  }

  .hero-content p {
    font-size: 14px;
  }

  .hero-footer {
    margin-top: 45px;
  }

  .form-section {
    width: 50%;
    max-width: 500px;
    align-self: center;
    padding: 40px;
  }
}
</style>
