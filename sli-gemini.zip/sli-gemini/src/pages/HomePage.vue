
<template>
  <ion-page>
    <AppHeader title="Sehat Lestari" />

    <ion-content class="home-content">
      <!-- HERO -->
      <section class="hero">
        <div class="hero-content">
          <span class="hero-label">SEHAT LESTARI ONLINE</span>

          <h1>
            Bersama Berbagi,
            <span>Menebar Kebaikan</span>
          </h1>

          <p>
            Salurkan kepedulian melalui zakat, donasi,
            dan program pemberdayaan masyarakat.
          </p>

          <ion-button
            color="light"
            class="hero-button"
            @click="goTo('/campaign')"
          >
            Mulai Berdonasi
            <ion-icon slot="end" :icon="arrowForwardOutline" />
          </ion-button>
        </div>

        <div class="hero-decoration">
          <ion-icon :icon="heartOutline" />
        </div>
      </section>

      <!-- LAYANAN -->
      <section class="section">
        <div class="section-heading">
          <div>
            <h2>Layanan Kami</h2>
            <p>Kemudahan berbagi dalam satu aplikasi</p>
          </div>
        </div>

        <div class="service-grid">
          <button class="service-item" @click="goTo('/campaign')">
            <div class="service-icon green">
              <ion-icon :icon="heartOutline" />
            </div>
            <span>Donasi</span>
          </button>

          <button class="service-item" @click="goTo('/zakat')">
            <div class="service-icon orange">
              <ion-icon :icon="calculatorOutline" />
            </div>
            <span>Hitung Zakat</span>
          </button>

          <button class="service-item" @click="goTo('/realisasi')">
            <div class="service-icon blue">
              <ion-icon :icon="documentTextOutline" />
            </div>
            <span>Realisasi</span>
          </button>

          <button class="service-item" @click="goTo('/profil')">
            <div class="service-icon purple">
              <ion-icon :icon="businessOutline" />
            </div>
            <span>Profil Yayasan</span>
          </button>
        </div>
      </section>

      <!-- CAMPAIGN -->
      <section class="section campaign-section">
        <div class="section-heading campaign-heading">
          <div>
            <h2>Campaign Pilihan</h2>
            <p>Program kebaikan yang membutuhkan dukungan</p>
          </div>

          <button class="see-all" @click="goTo('/campaign')">
            Lihat Semua
            <ion-icon :icon="chevronForwardOutline" />
          </button>
        </div>

        <div v-if="loading" class="state-box">
          <ion-spinner name="crescent" color="success" />
          <p>Sedang mengambil data campaign...</p>
        </div>

        <div v-else-if="error" class="state-box">
          <ion-icon :icon="alertCircleOutline" color="danger" />
          <p>{{ error }}</p>
          <ion-button size="small" color="success" @click="loadCampaigns">
            Muat Ulang
          </ion-button>
        </div>

        <div v-else-if="campaigns.length === 0" class="state-box">
          <ion-icon :icon="heartOutline" />
          <p>Belum ada campaign yang tersedia.</p>
        </div>

        <div v-else class="campaign-list">
          <CampaignCard
            v-for="campaign in campaigns"
            :key="campaign.id"
            :id="campaign.id"
            :title="campaign.title"
            :description="campaign.description"
            :target-dana="campaign.targetDana"
            :status="campaign.status"
            :deadline="campaign.deadline"
            :image="campaign.image"
          />
        </div>
      </section>

      <!-- AJAKAN -->
      <section class="invitation">
        <div class="invitation-icon">
          <ion-icon :icon="peopleOutline" />
        </div>

        <h2>Kebaikan Dimulai dari Kita</h2>
        <p>
          Setiap kontribusi memiliki arti bagi mereka yang membutuhkan.
          Mari tumbuh bersama dalam kepedulian.
        </p>

        <ion-button
          expand="block"
          color="success"
          @click="goTo('/campaign')"
        >
          Jelajahi Program
        </ion-button>
      </section>

      <div class="bottom-space"></div>
    </ion-content>

    <!-- BOTTOM NAVIGATION -->
    <ion-footer class="ion-no-border">
      <ion-tab-bar>
        <ion-tab-button selected>
          <ion-icon :icon="homeOutline" />
          <ion-label>Beranda</ion-label>
        </ion-tab-button>

        <ion-tab-button @click="goTo('/campaign')">
          <ion-icon :icon="heartOutline" />
          <ion-label>Campaign</ion-label>
        </ion-tab-button>

        <ion-tab-button @click="goTo('/zakat')">
          <ion-icon :icon="calculatorOutline" />
          <ion-label>Zakat</ion-label>
        </ion-tab-button>

        <ion-tab-button @click="goTo('/profil')">
          <ion-icon :icon="personOutline" />
          <ion-label>Profil</ion-label>
        </ion-tab-button>
      </ion-tab-bar>
    </ion-footer>
  </ion-page>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue';
import { useRouter } from 'vue-router';
import api from '@/services/api';

import AppHeader from '@/components/AppHeader.vue';
import CampaignCard from '@/components/CampaignCard.vue';

import {
  IonPage,
  IonContent,
  IonButton,
  IonIcon,
  IonSpinner,
  IonFooter,
  IonTabBar,
  IonTabButton,
  IonLabel
} from '@ionic/vue';

import {
  arrowForwardOutline,
  heartOutline,
  calculatorOutline,
  documentTextOutline,
  businessOutline,
  chevronForwardOutline,
  alertCircleOutline,
  peopleOutline,
  homeOutline,
  personOutline
} from 'ionicons/icons';

interface Campaign {
  id: number;
  title: string;
  description: string;
  targetDana: number;
  status: string;
  deadline: string;
  image: string;
}

const router = useRouter();

const campaigns = ref<Campaign[]>([]);
const loading = ref(false);
const error = ref('');

const extractList = (response: any): any[] => {
  let data = response;

  for (let i = 0; i < 5; i++) {
    if (Array.isArray(data)) return data;

    if (!data || typeof data !== 'object') return [];

    if (Array.isArray(data.campaigns)) return data.campaigns;

    if (Array.isArray(data.data)) return data.data;

    data = data.data;
  }

  return [];
};

const mapCampaign = (item: any): Campaign => ({
  id: Number(item.id),
  title:
    item.judul ??
    item.title ??
    item.nama_campaign ??
    'Campaign tanpa judul',

  description:
    item.deskripsi ??
    item.description ??
    '',

  targetDana: Number(
    item.target_dana ??
    item.targetDana ??
    item.target ??
    0
  ),

  status: String(item.status ?? 'Aktif'),

  deadline:
    item.batas_waktu ??
    item.deadline ??
    item.tanggal_selesai ??
    '',

  image:
    item.foto ??
    item.gambar ??
    item.image ??
    item.thumbnail ??
    item.foto_campaign ??
    ''
});

const loadCampaigns = async () => {
  loading.value = true;
  error.value = '';

  try {
    const response = await api.get('/campaigns');

    console.log('RESPONS API HOME:', response.data);

    campaigns.value = extractList(response.data)
      .map(mapCampaign)
      .filter((item) => item.id > 0)
      .slice(0, 3);

    console.log('DATA CAMPAIGN HOME:', campaigns.value);
  } catch (err: any) {
    console.error('ERROR API HOME:', err.response?.data || err.message);

    error.value = err.response
      ? `Gagal mengambil data campaign (${err.response.status}).`
      : 'Tidak dapat terhubung ke server. Periksa koneksi internet.';
  } finally {
    loading.value = false;
  }
};

const goTo = (path: string) => {
  router.push(path);
};

onMounted(() => {
  loadCampaigns();
});
</script>

<style scoped>
.home-content {
  --background: #f6f9f7;
}

.hero {
  position: relative;
  overflow: hidden;
  margin: 14px;
  padding: 25px 21px;
  min-height: 265px;
  border-radius: 24px;
  background: linear-gradient(135deg, #14532d 0%, #16834a 65%, #26a45e 100%);
  color: #ffffff;
}

.hero-content {
  position: relative;
  z-index: 2;
  max-width: 290px;
}

.hero-label {
  display: inline-block;
  font-size: 10px;
  letter-spacing: 1.6px;
  font-weight: 800;
  color: #d4f5dc;
}

.hero h1 {
  font-size: 27px;
  line-height: 1.25;
  font-weight: 800;
  margin: 13px 0 10px;
}

.hero h1 span {
  color: #c8f2d2;
}

.hero p {
  font-size: 12px;
  line-height: 1.7;
  color: #e1f4e6;
  margin: 0;
}

.hero-button {
  margin: 17px 0 0;
  --border-radius: 12px;
  --color: #14532d;
  font-size: 12px;
  font-weight: 800;
}

.hero-decoration {
  position: absolute;
  right: -27px;
  bottom: -40px;
  width: 165px;
  height: 165px;
  border-radius: 50%;
  background: rgba(255, 255, 255, 0.10);
  display: flex;
  justify-content: center;
  align-items: center;
}

.hero-decoration ion-icon {
  font-size: 85px;
  color: rgba(255, 255, 255, 0.28);
}

.section {
  padding: 17px 17px 8px;
}

.section-heading {
  margin-bottom: 17px;
}

.section-heading h2 {
  margin: 0 0 5px;
  color: #183c29;
  font-size: 18px;
  font-weight: 800;
}

.section-heading p {
  margin: 0;
  color: #89968e;
  font-size: 11px;
}

.service-grid {
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 8px;
}

.service-item {
  padding: 0;
  border: 0;
  background: transparent;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 8px;
  color: #53645a;
  font-size: 10px;
  font-weight: 700;
  text-align: center;
}

.service-icon {
  width: 54px;
  height: 54px;
  border-radius: 17px;
  display: flex;
  align-items: center;
  justify-content: center;
}

.service-icon ion-icon {
  font-size: 25px;
}

.service-icon.green {
  color: #16834a;
  background: #e3f4e8;
}

.service-icon.orange {
  color: #d97706;
  background: #fff1dc;
}

.service-icon.blue {
  color: #2874c7;
  background: #e5f0ff;
}

.service-icon.purple {
  color: #8653c7;
  background: #f0e8ff;
}

.campaign-section {
  padding-top: 25px;
}

.campaign-heading {
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 8px;
}

.see-all {
  border: 0;
  background: transparent;
  color: #16834a;
  font-size: 11px;
  font-weight: 800;
  white-space: nowrap;
  display: flex;
  align-items: center;
  gap: 3px;
}

.campaign-list {
  display: flex;
  flex-direction: column;
  gap: 17px;
}

.state-box {
  min-height: 150px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 10px;
  color: #829087;
  font-size: 12px;
  text-align: center;
}

.state-box > ion-icon {
  font-size: 35px;
}

.invitation {
  margin: 24px 17px 10px;
  padding: 22px 18px;
  border-radius: 20px;
  background: #eaf6ed;
  text-align: center;
}

.invitation-icon {
  margin: 0 auto 10px;
  width: 52px;
  height: 52px;
  border-radius: 17px;
  background: #d4edda;
  color: #16834a;
  display: flex;
  align-items: center;
  justify-content: center;
}

.invitation-icon ion-icon {
  font-size: 27px;
}

.invitation h2 {
  color: #14532d;
  font-size: 17px;
  font-weight: 800;
  margin: 0 0 8px;
}

.invitation p {
  color: #6b8072;
  font-size: 11px;
  line-height: 1.7;
  margin: 0 0 15px;
}

.invitation ion-button {
  --border-radius: 12px;
  font-size: 12px;
  font-weight: 700;
}

.bottom-space {
  height: 20px;
}

ion-tab-bar {
  --background: #ffffff;
  --border: 1px solid #edf1ee;
  height: 63px;
  padding-bottom: env(safe-area-inset-bottom);
}

ion-tab-button {
  --color: #9aa79e;
  --color-selected: #16834a;
  font-size: 10px;
  font-weight: 600;
}

ion-tab-button ion-icon {
  font-size: 21px;
}
</style>
