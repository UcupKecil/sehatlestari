
import api from './api';
import type { ZakatData } from '@/interfaces/Zakat';

// ===============================
// INTERFACE ZAKAT
// ===============================

export type { ZakatData };

// ===============================
// MENGAMBIL PARAMETER ZAKAT
// ===============================

export const getZakatParameter = async () => {
  const response = await api.get('/zakat/parameter');

  return response.data;
};

// ===============================
// MENGHITUNG ZAKAT
// ===============================

export const hitungZakat = async (data: ZakatData) => {
  const response = await api.post('/zakat/hitung', data);

  return response.data;
};

// ===============================
// CONTOH PERHITUNGAN ZAKAT
// ===============================

export const contohZakat: ZakatData = {
  jenis_zakat: 'Zakat Profesi',
  total_harta: 10000000
};
