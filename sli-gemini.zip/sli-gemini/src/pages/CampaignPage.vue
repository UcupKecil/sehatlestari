
<template>
  <ion-page>
    <AppHeader title="Campaign" :show-home="true" />

    <ion-content class="campaign-content">
      <section class="page-intro">
        <span class="eyebrow">PROGRAM KEBAIKAN</span>
        <h1>Salurkan Kepedulianmu</h1>
        <p>
          Temukan program yang ingin kamu dukung.
          Bersama kita hadirkan manfaat bagi sesama.
        </p>
      </section>

      <!-- SEARCH -->
      <div class="search-wrapper">
        <ion-searchbar
          v-model="search"
          placeholder="Cari program kebaikan..."
          :debounce="200"
          class="custom-search"
        />
      </div>

      <!-- FILTER -->
      <div class="filter-wrapper">
        <ion-segment v-model="selectedFilter" class="custom-segment">
          <ion-segment-button value="Semua">
            <ion-label>Semua</ion-label>
          </ion-segment-button>

          <ion-segment-button value="Aktif">
            <ion-label>Aktif</ion-label>
          </ion-segment-button>

          <ion-segment-button value="Selesai">
            <ion-label>Selesai</ion-label>
          </ion-segment-button>
        </ion-segment>
      </div>

      <!-- JUMLAH CAMPAIGN -->
      <div class="result-heading">
        <h2>Daftar Campaign</h2>
        <span>{{ filteredCampaigns.length }} program</span>
      </div>

      <!-- LOADING -->
      <div v-if="loading" class="state-box">
        <ion-spinner name="crescent" color="success" />
        <p>Memuat daftar campaign...</p>
      </div>

      <!-- ERROR -->
      <div v-else-if="error" class="state-box">
        <ion-icon :icon="alertCircleOutline" color="danger" />
        <p>{{ error }}</p>
        <ion-button color="success" size="small" @click="loadCampaigns">
          Coba Lagi
        </ion-button>
      </div>

      <!-- EMPTY -->
      <div v-else-if="filteredCampaigns.length === 0" class="state-box">
        <ion-icon :icon="searchOutline" />
        <h3>Campaign tidak ditemukan</h3>
        <p>Coba kata kunci atau filter yang berbeda.</p>
      </div>

      <!-- CAMPAIGN LIST -->
      <div v-else class="campaign-list">
        <CampaignCard
          v-for="campaign in filteredCampaigns"
          :key="campaign.id"
          :id="campaign.id"
          :title="campaign.title"
          :description="campaign.description"
          :target-dana="campaign.targetDana"
          :status="campaign.status"
          :deadline="campaign.deadline"
          :image="campaign.image"
        />
      </div>

      <div class="bottom-space"></div>
    </ion-content>

    <!-- BOTTOM NAVIGATION -->
    <ion-footer class="ion-no-border">
      <ion-tab-bar>
        <ion-tab-button @click="goTo('/home')">
          <ion-icon :icon="homeOutline" />
          <ion-label>Beranda</ion-label>
        </ion-tab-button>

        <ion-tab-button selected>
          <ion-icon :icon="heartOutline" />
          <ion-label>Campaign</ion-label>
        </ion-tab-button>

        <ion-tab-button @click="goTo('/zakat')">
          <ion-icon :icon="calculatorOutline" />
          <ion-label>Zakat</ion-label>
        </ion-tab-button>

        <ion-tab-button @click="goTo('/profil')">
          <ion-icon :icon="personOutline" />
          <ion-label>Profil</ion-label>
        </ion-tab-button>
      </ion-tab-bar>
    </ion-footer>
  </ion-page>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue';
import { useRouter } from 'vue-router';
import api from '@/services/api';

import AppHeader from '@/components/AppHeader.vue';
import CampaignCard from '@/components/CampaignCard.vue';

import {
  IonPage,
  IonContent,
  IonSearchbar,
  IonSegment,
  IonSegmentButton,
  IonLabel,
  IonSpinner,
  IonIcon,
  IonButton,
  IonFooter,
  IonTabBar,
  IonTabButton
} from '@ionic/vue';

import {
  alertCircleOutline,
  searchOutline,
  homeOutline,
  heartOutline,
  calculatorOutline,
  personOutline
} from 'ionicons/icons';

interface Campaign {
  id: number;
  title: string;
  description: string;
  targetDana: number;
  status: string;
  deadline: string;
  image: string;
}

const router = useRouter();

const campaigns = ref<Campaign[]>([]);
const loading = ref(false);
const error = ref('');
const search = ref('');
const selectedFilter = ref('Semua');

const extractList = (response: any): any[] => {
  let data = response;

  for (let i = 0; i < 5; i++) {
    if (Array.isArray(data)) return data;

    if (!data || typeof data !== 'object') return [];

    if (Array.isArray(data.campaigns)) return data.campaigns;

    if (Array.isArray(data.data)) return data.data;

    data = data.data;
  }

  return [];
};

const mapCampaign = (item: any): Campaign => ({
  id: Number(item.id),

  title:
    item.judul ??
    item.title ??
    item.nama_campaign ??
    'Campaign tanpa judul',

  description:
    item.deskripsi ??
    item.description ??
    '',

  targetDana: Number(
    item.target_dana ??
    item.targetDana ??
    item.target ??
    0
  ),

  status: String(item.status ?? 'Aktif'),

  deadline:
    item.batas_waktu ??
    item.deadline ??
    item.tanggal_selesai ??
    '',

  image:
    item.foto ??
    item.gambar ??
    item.image ??
    item.thumbnail ??
    item.foto_campaign ??
    ''
});

const loadCampaigns = async () => {
  loading.value = true;
  error.value = '';

  try {
    const response = await api.get('/campaigns');

    console.log('RESPONS API CAMPAIGN:', response.data);

    campaigns.value = extractList(response.data)
      .map(mapCampaign)
      .filter((item) => item.id > 0);

    console.log('DATA CAMPAIGN:', campaigns.value);
  } catch (err: any) {
    console.error('ERROR API CAMPAIGN:', err.response?.data || err.message);

    error.value = err.response
      ? `Gagal mengambil data campaign (${err.response.status}).`
      : 'Tidak dapat terhubung ke server.';
  } finally {
    loading.value = false;
  }
};

const filteredCampaigns = computed(() => {
  const keyword = search.value.toLowerCase().trim();

  return campaigns.value.filter((item) => {
    const matchesSearch =
      item.title.toLowerCase().includes(keyword) ||
      item.description.toLowerCase().includes(keyword);

    const status = item.status.toLowerCase();

    const matchesStatus =
      selectedFilter.value === 'Semua' ||
      status === selectedFilter.value.toLowerCase();

    return matchesSearch && matchesStatus;
  });
});

const goTo = (path: string) => {
  router.push(path);
};

onMounted(() => {
  loadCampaigns();
});
</script>

<style scoped>
.campaign-content {
  --background: #f6f9f7;
}

.page-intro {
  padding: 25px 19px 12px;
}

.eyebrow {
  color: #16834a;
  font-size: 10px;
  font-weight: 800;
  letter-spacing: 1.5px;
}

.page-intro h1 {
  color: #14532d;
  font-size: 25px;
  line-height: 1.3;
  font-weight: 800;
  margin: 9px 0;
}

.page-intro p {
  color: #829087;
  font-size: 12px;
  line-height: 1.7;
  margin: 0;
}

.search-wrapper {
  padding: 8px 13px 5px;
}

.custom-search {
  --background: #ffffff;
  --border-radius: 14px;
  --box-shadow: 0 3px 12px rgba(24, 70, 43, 0.05);
  --placeholder-color: #9ba79f;
  --icon-color: #16834a;
  padding: 0;
}

.filter-wrapper {
  padding: 9px 17px 18px;
}

.custom-segment {
  --background: #e9f2eb;
  border-radius: 12px;
  min-height: 42px;
}

ion-segment-button {
  --indicator-color: #16834a;
  --color: #75847a;
  --color-checked: #ffffff;
  min-height: 37px;
  font-size: 11px;
  font-weight: 700;
  text-transform: none;
}

.result-heading {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 19px 14px;
}

.result-heading h2 {
  color: #183c29;
  font-size: 16px;
  font-weight: 800;
  margin: 0;
}

.result-heading span {
  color: #16834a;
  background: #e5f4e9;
  border-radius: 20px;
  padding: 6px 10px;
  font-size: 10px;
  font-weight: 700;
}

.campaign-list {
  padding: 0 15px;
  display: flex;
  flex-direction: column;
  gap: 17px;
}

.state-box {
  min-height: 230px;
  padding: 20px;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  gap: 10px;
  color: #819087;
  font-size: 12px;
  text-align: center;
}

.state-box > ion-icon {
  font-size: 42px;
}

.state-box h3 {
  color: #385443;
  font-size: 15px;
  font-weight: 700;
  margin: 0;
}

.state-box p {
  margin: 0;
  line-height: 1.6;
}

.bottom-space {
  height: 24px;
}

ion-tab-bar {
  --background: #ffffff;
  --border: 1px solid #edf1ee;
  height: 63px;
  padding-bottom: env(safe-area-inset-bottom);
}

ion-tab-button {
  --color: #9aa79e;
  --color-selected: #16834a;
  font-size: 10px;
  font-weight: 600;
}

ion-tab-button ion-icon {
  font-size: 21px;
}
</style>
