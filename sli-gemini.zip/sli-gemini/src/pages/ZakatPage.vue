
<template>
  <ion-page>
    <ion-header>
      <ion-toolbar color="primary">
        <ion-title>Kalkulator Zakat</ion-title>
      </ion-toolbar>
    </ion-header>

    <ion-content class="ion-padding">
      <h2>Hitung Zakat Anda</h2>
      <p>Masukkan jenis zakat dan jumlah harta untuk melakukan perhitungan.</p>

      <ion-spinner v-if="loadingParameter" />

      <ion-card v-if="parameter">
        <ion-card-content>
          <strong>Informasi Parameter Zakat</strong>
          <pre>{{ JSON.stringify(parameter, null, 2) }}</pre>
        </ion-card-content>
      </ion-card>

      <form @submit.prevent="hitung">
        <ion-item>
          <ion-label position="stacked">Jenis Zakat</ion-label>
          <ion-select
            v-model="form.jenis_zakat"
            placeholder="Pilih jenis zakat"
            required
          >
            <ion-select-option value="Zakat Profesi">
              Zakat Profesi
            </ion-select-option>
            <ion-select-option value="Zakat Maal">
              Zakat Maal
            </ion-select-option>
          </ion-select>
        </ion-item>

        <ion-item>
          <ion-label position="stacked">Total Harta (Rp)</ion-label>
          <ion-input
            v-model.number="form.total_harta"
            type="number"
            min="0"
            required
          />
        </ion-item>

        <ion-button
          type="submit"
          expand="block"
          class="ion-margin-top"
          :disabled="loading"
        >
          {{ loading ? 'Menghitung...' : 'Hitung Zakat' }}
        </ion-button>
      </form>

      <ion-card v-if="hasil">
        <ion-card-header>
          <ion-card-title>Hasil Perhitungan</ion-card-title>
        </ion-card-header>
        <ion-card-content>
          <pre>{{ JSON.stringify(hasil, null, 2) }}</pre>
        </ion-card-content>
      </ion-card>

      <ion-text color="danger" v-if="error">
        <p>{{ error }}</p>
      </ion-text>
    </ion-content>
  </ion-page>
</template>

<script setup lang="ts">
import { onMounted, reactive, ref } from 'vue';
import {
  IonPage, IonHeader, IonToolbar, IonTitle, IonContent,
  IonItem, IonLabel, IonSelect, IonSelectOption, IonInput,
  IonButton, IonCard, IonCardHeader, IonCardTitle,
  IonCardContent, IonSpinner, IonText
} from '@ionic/vue';
import {
  getZakatParameter,
  hitungZakat
} from '../services/zakatService';

const form = reactive({
  jenis_zakat: 'Zakat Profesi',
  total_harta: 0
});

const parameter = ref<any>(null);
const hasil = ref<any>(null);
const loading = ref(false);
const loadingParameter = ref(false);
const error = ref('');

onMounted(async () => {
  loadingParameter.value = true;

  try {
    parameter.value = await getZakatParameter();
  } catch (err: any) {
    error.value =
      err.response?.data?.message || 'Parameter zakat gagal dimuat.';
  } finally {
    loadingParameter.value = false;
  }
});

async function hitung() {
  error.value = '';
  hasil.value = null;

  if (form.total_harta <= 0) {
    error.value = 'Total harta harus lebih besar dari nol.';
    return;
  }

  loading.value = true;

  try {
    hasil.value = await hitungZakat({ ...form });
  } catch (err: any) {
    error.value =
      err.response?.data?.message || 'Perhitungan zakat gagal.';
  } finally {
    loading.value = false;
  }
}
</script>

<style scoped>
pre {
  white-space: pre-wrap;
  overflow-wrap: anywhere;
  font-size: 13px;
}
</style>
