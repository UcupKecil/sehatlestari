
<template>
  <div class="loading-container">
    <div class="loading-circle">
      <ion-spinner :name="spinnerName" :color="color" />
    </div>

    <h3>{{ message }}</h3>
    <p>Mohon tunggu sebentar...</p>
  </div>
</template>

<script setup lang="ts">
import { IonSpinner } from '@ionic/vue';

export type SpinnerType =
  | 'crescent'
  | 'bubbles'
  | 'circles'
  | 'circular'
  | 'dots'
  | 'lines'
  | 'lines-small'
  | 'lines-sharp'
  | 'lines-sharp-small';

withDefaults(defineProps<{
  message?: string;
  color?: string;
  spinnerName?: SpinnerType;
}>(), {
  message: 'Memuat data',
  color: 'success',
  spinnerName: 'crescent'
});
</script>

<style scoped>
.loading-container {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 55px 20px;
  text-align: center;
}

.loading-circle {
  width: 65px;
  height: 65px;
  border-radius: 20px;
  background: #e7f5ed;
  display: flex;
  align-items: center;
  justify-content: center;
}

ion-spinner {
  width: 32px;
  height: 32px;
}

h3 {
  font-size: 15px;
  color: #176b4b;
  margin-top: 15px;
}

p {
  color: #999;
  font-size: 12px;
}
</style>
