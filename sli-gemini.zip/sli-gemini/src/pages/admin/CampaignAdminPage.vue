
<template>
  <ion-page>
    <ion-header>
      <ion-toolbar class="green-toolbar">
        <ion-buttons slot="start">
          <ion-back-button default-href="/admin/dashboard" />
        </ion-buttons>
        <ion-title>Kelola Campaign</ion-title>
        <ion-buttons slot="end">
          <ion-button @click="loadCampaigns">
            <ion-icon :icon="refreshOutline" />
          </ion-button>
        </ion-buttons>
      </ion-toolbar>
    </ion-header>

    <ion-content class="ion-padding">
      <div class="page-container">
        <div class="page-heading">
          <div>
            <h2>Daftar Campaign</h2>
            <p>Kelola seluruh kegiatan penggalangan dana.</p>
          </div>
          <ion-button class="add-button" @click="openCreateModal">
            <ion-icon :icon="addOutline" slot="start" />
            Tambah Campaign
          </ion-button>
        </div>

        <!-- RINGKASAN -->
        <div class="summary-grid">
          <div class="summary-card">
            <span>Total Campaign</span>
            <strong>{{ totalCampaign }}</strong>
          </div>
          <div class="summary-card active">
            <span>Aktif</span>
            <strong>{{ countStatus('Aktif') }}</strong>
          </div>
          <div class="summary-card inactive">
            <span>Nonaktif</span>
            <strong>{{ countStatus('Nonaktif') }}</strong>
          </div>
          <div class="summary-card finished">
            <span>Selesai</span>
            <strong>{{ countStatus('Selesai') }}</strong>
          </div>
        </div>

        <!-- FILTER -->
        <div class="filter-panel">
          <div class="filter-title">
            <div>
              <h3>Filter Campaign</h3>
              <p>Cari dan saring data campaign berdasarkan status.</p>
            </div>
            <ion-button fill="outline" class="reset-button" @click="resetFilter">
              <ion-icon :icon="refreshOutline" slot="start" />
              Reset Filter
            </ion-button>
          </div>

          <div class="filter-controls">
            <ion-searchbar
              v-model="search"
              placeholder="Cari judul campaign..."
              class="custom-search"
              :debounce="300"
            />

            <ion-select
              v-model="filterStatus"
              interface="popover"
              placeholder="Pilih Status"
              class="status-select"
            >
              <ion-select-option value="Semua">Semua Status</ion-select-option>
              <ion-select-option value="Aktif">Aktif</ion-select-option>
              <ion-select-option value="Nonaktif">Nonaktif</ion-select-option>
              <ion-select-option value="Selesai">Selesai</ion-select-option>
            </ion-select>
          </div>
        </div>

        <!-- TABEL -->
        <div class="table-panel">
          <div class="table-heading">
            <div>
              <h3>Data Campaign</h3>
              <p>
                {{ filteredCampaigns.length }} data ditampilkan
                dari {{ totalCampaign }} campaign
              </p>
            </div>
          </div>

          <div v-if="loading" class="loading-state">
            <ion-spinner name="crescent" />
            <p>Memuat data campaign...</p>
          </div>

          <div v-else-if="filteredCampaigns.length === 0" class="empty-state">
            <ion-icon :icon="documentTextOutline" />
            <h3>Campaign tidak ditemukan</h3>
            <p>Belum ada data yang sesuai dengan pencarian atau filter.</p>
          </div>

          <div v-else class="table-scroll">
            <table class="campaign-table">
              <thead>
                <tr>
                  <th>No.</th>
                  <th>Judul Campaign</th>
                  <th>Kategori Dana</th>
                  <th>Target Dana</th>
                  <th>Tanggal Mulai</th>
                  <th>Batas Waktu</th>
                  <th>Status</th>
                  <th>Aksi</th>
                </tr>
              </thead>
              <tbody>
                <tr v-for="(item, index) in filteredCampaigns" :key="item.id">
                  <td data-label="No.">
                    {{ (currentPage - 1) * perPage + index + 1 }}
                  </td>
                  <td data-label="Judul Campaign" class="campaign-name">
                    {{ item.judul }}
                  </td>
                  <td data-label="Kategori Dana">
                    {{ getCategoryName(item) }}
                  </td>
                  <td data-label="Target Dana" class="money">
                    {{ formatRupiah(item.target_dana) }}
                  </td>
                  <td data-label="Tanggal Mulai">
                    {{ formatDate(item.tanggal_mulai) }}
                  </td>
                  <td data-label="Batas Waktu">
                    {{ formatDate(item.batas_waktu) }}
                  </td>
                  <td data-label="Status">
                    <span
                      class="status-badge"
                      :class="{
                        'status-aktif': item.status === 'Aktif',
                        'status-nonaktif':
                          item.status === 'Nonaktif' ||
                          item.status === 'Non Aktif',
                        'status-selesai': item.status === 'Selesai'
                      }"
                    >
                      {{ item.status }}
                    </span>
                  </td>
                  <td data-label="Aksi">
                    <div class="action-buttons">
                      <ion-button
                        fill="clear"
                        color="primary"
                        size="small"
                        title="Kelola Realisasi"
                        @click="openRealisasi(item)"
                      >
                        <ion-icon :icon="receiptOutline" />
                      </ion-button>

                      <ion-button
                        fill="clear"
                        color="success"
                        size="small"
                        title="Edit Campaign"
                        @click="openEditModal(item)"
                      >
                        <ion-icon :icon="createOutline" />
                      </ion-button>

                      <ion-button
                        fill="clear"
                        color="danger"
                        size="small"
                        title="Hapus Campaign"
                        @click="confirmDelete(item)"
                      >
                        <ion-icon :icon="trashOutline" />
                      </ion-button>
                    </div>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>

          <div class="pagination">
            <span>Halaman {{ currentPage }} dari {{ totalPages }}</span>
            <div class="pagination-buttons">
              <ion-button
                fill="outline"
                size="small"
                :disabled="currentPage <= 1 || loading"
                @click="changePage(currentPage - 1)"
              >
                Sebelumnya
              </ion-button>
              <ion-button
                fill="outline"
                size="small"
                :disabled="currentPage >= totalPages || loading"
                @click="changePage(currentPage + 1)"
              >
                Berikutnya
              </ion-button>
            </div>
          </div>
        </div>
      </div>

      <!-- MODAL TAMBAH / EDIT -->
      <ion-modal
        :is-open="showModal"
        @didDismiss="closeModal"
        class="campaign-modal"
      >
        <ion-header>
          <ion-toolbar class="green-toolbar">
            <ion-title>
              {{ isEdit ? 'Edit Campaign' : 'Tambah Campaign' }}
            </ion-title>
            <ion-buttons slot="end">
              <ion-button @click="closeModal">Tutup</ion-button>
            </ion-buttons>
          </ion-toolbar>
        </ion-header>

        <ion-content class="ion-padding">
          <div class="form-container">
            <!-- JUDUL -->
            <ion-item>
              <ion-label position="stacked">Judul Campaign</ion-label>
              <ion-input
                v-model="form.judul"
                placeholder="Masukkan judul campaign"
              />
            </ion-item>

            <!-- KATEGORI -->
            <ion-item>
              <ion-label position="stacked">Kategori Dana</ion-label>
              <ion-select
                v-model="form.kategori_dana_id"
                interface="popover"
                placeholder="Pilih kategori dana"
              >
                <ion-select-option
                  v-for="kategori in kategoriDana"
                  :key="kategori.id"
                  :value="kategori.id"
                >
                  {{ getCategoryLabel(kategori) }}
                </ion-select-option>
              </ion-select>
            </ion-item>

            <!-- TIPE PROGRAM -->
            <ion-item>
              <ion-label position="stacked">Tipe Program</ion-label>
              <ion-select
                v-model="form.tipe_program"
                interface="popover"
                placeholder="Pilih tipe program"
              >
                <ion-select-option value="Campaign_Online">Campaign Online</ion-select-option>
                <ion-select-option value="Kegiatan_Internal">Kegiatan Internal</ion-select-option>
                <ion-select-option value="Hybrid">Hybrid</ion-select-option>
              </ion-select>
            </ion-item>

            <!-- TARGET DANA -->
            <ion-item>
              <ion-label position="stacked">Target Dana (Rp)</ion-label>
              <ion-input
                :value="targetDisplay"
                inputmode="numeric"
                placeholder="Contoh: 10.000.000"
                @ionInput="handleTargetInput"
              />
            </ion-item>

            <!-- TANGGAL MULAI -->
            <ion-item button detail @click="openDatePicker('tanggal_mulai')">
              <ion-label position="stacked">Tanggal Mulai</ion-label>
              <ion-input
                :value="formatDate(form.tanggal_mulai)"
                readonly
                placeholder="Pilih tanggal mulai"
              />
              <ion-icon :icon="calendarOutline" slot="end" />
            </ion-item>

            <!-- BATAS WAKTU -->
            <ion-item button detail @click="openDatePicker('batas_waktu')">
              <ion-label position="stacked">Batas Waktu</ion-label>
              <ion-input
                :value="formatDate(form.batas_waktu)"
                readonly
                placeholder="Pilih batas waktu"
              />
              <ion-icon :icon="calendarOutline" slot="end" />
            </ion-item>

            <!-- LOKASI -->
            <ion-item>
              <ion-label position="stacked">Lokasi / Alamat Kegiatan</ion-label>
              <ion-textarea
                v-model="form.lokasi"
                :auto-grow="true"
                :rows="2"
                placeholder="Masukkan alamat atau lokasi kegiatan"
              />
            </ion-item>

            <!-- FOTO UTAMA -->
            <div class="custom-form-group">
              <label class="form-label">Foto Utama Campaign</label>

              <div v-if="fotoUtamaPreview" class="foto-utama-preview">
                <img :src="fotoUtamaPreview" alt="Foto utama campaign" />
              </div>

              <div v-else class="foto-utama-placeholder">
                Belum ada foto utama
              </div>

              <input
                ref="fotoUtamaInput"
                type="file"
                accept="image/jpeg,image/png,image/webp"
                @change="handleFotoUtama"
              />
              <small class="upload-info">JPG, PNG, WEBP · Maksimal 5 MB</small>
            </div>

            <!-- DESKRIPSI QUILL -->
            <div class="custom-form-group">
              <label class="form-label">Deskripsi Campaign</label>

              <div class="quill-wrapper">
                <QuillEditor
                  v-model:content="form.deskripsi"
                  content-type="html"
                  theme="snow"
                  :options="quillOptions"
                />
              </div>
            </div>

            <!-- SIMPAN -->
            <ion-button
              expand="block"
              class="save-button"
              :disabled="saving"
              @click="saveCampaign"
            >
              <ion-spinner v-if="saving" name="crescent" />
              <span v-else>
                {{ isEdit ? 'Simpan Perubahan' : 'Simpan Campaign' }}
              </span>
            </ion-button>
          </div>
        </ion-content>
      </ion-modal>

      <!-- MODAL KALENDER -->
      <ion-modal
        :is-open="showDatePicker"
        @didDismiss="showDatePicker = false"
        class="date-modal"
      >
        <ion-header>
          <ion-toolbar class="green-toolbar">
            <ion-title>Pilih Tanggal</ion-title>
            <ion-buttons slot="end">
              <ion-button @click="showDatePicker = false">Tutup</ion-button>
            </ion-buttons>
          </ion-toolbar>
        </ion-header>

        <ion-content class="ion-padding">
          <ion-datetime
            presentation="date"
            :value="dateValue"
            @ionChange="handleDateChange"
            show-default-buttons
            done-text="Pilih"
            cancel-text="Batal"
          />
        </ion-content>
      </ion-modal>

      <!-- KONFIRMASI HAPUS -->
      <ion-alert
        :is-open="showDeleteAlert"
        header="Hapus Campaign"
        :message="`Apakah Anda yakin ingin menghapus campaign ${selectedCampaign?.judul || ''}?`"
        :buttons="deleteAlertButtons"
        @didDismiss="showDeleteAlert = false"
      />

      <!-- TOAST -->
      <ion-toast
        :is-open="toastOpen"
        :message="toastMessage"
        :duration="2500"
        :color="toastColor"
        position="top"
        @didDismiss="toastOpen = false"
      />
    </ion-content>
  </ion-page>
</template>

<script setup lang="ts">
import { ref, computed, onMounted, onBeforeUnmount } from 'vue';
import { useRouter } from 'vue-router';

import {
  IonPage,
  IonHeader,
  IonToolbar,
  IonTitle,
  IonContent,
  IonButtons,
  IonBackButton,
  IonButton,
  IonIcon,
  IonSearchbar,
  IonSelect,
  IonSelectOption,
  IonSpinner,
  IonModal,
  IonItem,
  IonLabel,
  IonInput,
  IonTextarea,
  IonDatetime,
  IonAlert,
  IonToast
} from '@ionic/vue';

import {
  addOutline,
  refreshOutline,
  documentTextOutline,
  createOutline,
  trashOutline,
  calendarOutline,
  receiptOutline,
  cloudUploadOutline
} from 'ionicons/icons';

import { QuillEditor } from '@vueup/vue-quill';
import '@vueup/vue-quill/dist/vue-quill.snow.css';

import api from '@/services/api';

import {
  createCampaign,
  updateCampaign,
  deleteCampaign
} from '@/services/adminService';

import type {
  Campaign,
  KategoriDana,
  PhotoPreview
} from '@/interfaces/Campaign';

/* =========================
   STATE
========================= */

const router = useRouter();

const campaigns = ref<Campaign[]>([]);
const kategoriDana = ref<KategoriDana[]>([]);

const loading = ref(false);
const saving = ref(false);

const search = ref('');
const filterStatus = ref('Semua');

const currentPage = ref(1);
const perPage = 10;
const totalPages = ref(1);
const totalCampaign = ref(0);

const showModal = ref(false);
const showDatePicker = ref(false);
const showDeleteAlert = ref(false);

const isEdit = ref(false);
const selectedCampaign = ref<Campaign | null>(null);

const selectedDateField = ref<'tanggal_mulai' | 'batas_waktu'>(
  'tanggal_mulai'
);

const dateValue = ref<string>();

const form = ref({
  id: null as number | null,
  judul: '',
  kategori_dana_id: null as number | null,
  target_dana: 0,
  tanggal_mulai: '',
  batas_waktu: '',
  lokasi: '',
  deskripsi: '',
  tipe_program: ''
});

const targetDisplay = ref('');

const toastOpen = ref(false);
const toastMessage = ref('');
const toastColor = ref('success');

/* =========================
   QUILL EDITOR
========================= */

const quillOptions = {
  theme: 'snow',
  placeholder: 'Tuliskan deskripsi campaign...',
  modules: {
    toolbar: [
      [{ header: [1, 2, 3, false] }],
      ['bold', 'italic', 'underline', 'strike'],
      [{ color: [] }, { background: [] }],
      [{ list: 'ordered' }, { list: 'bullet' }],
      [{ align: [] }],
      ['blockquote', 'link'],
      ['clean']
    ]
  }
};

/* =========================
   FOTO UTAMA
========================= */

const fotoUtamaInput = ref<HTMLInputElement | null>(null);
const fotoUtamaPreview = ref<string | null>(null);
const fotoUtamaFile = ref<File | null>(null);

const API_BASE_URL = 'https://sehatlestariindonesia.vps-m.com';

const getFotoUrl = (foto: string | null | undefined): string => {
  if (!foto) return '';

  if (/^https?:\/\//i.test(foto)) {
    return foto;
  }

  const filename = foto.split('/').pop();

  return `https://sehatlestariindonesia.vps-m.com/storage/campaigns/${filename}`;
};

const handleFotoUtama = (event: Event) => {
  const input = event.target as HTMLInputElement;
  const file = input.files?.[0];

  if (!file) return;

  if (!['image/jpeg', 'image/png', 'image/webp'].includes(file.type)) {
    showToast('Format foto harus JPG, PNG, atau WEBP.', 'warning');
    input.value = '';
    return;
  }

  if (file.size > 5 * 1024 * 1024) {
    showToast('Ukuran foto maksimal 5 MB.', 'warning');
    input.value = '';
    return;
  }

  if (fotoUtamaPreview.value?.startsWith('blob:')) {
    URL.revokeObjectURL(fotoUtamaPreview.value);
  }

  fotoUtamaFile.value = file;
  fotoUtamaPreview.value = URL.createObjectURL(file);
};

const clearFotoUtama = () => {
  if (fotoUtamaPreview.value?.startsWith('blob:')) {
    URL.revokeObjectURL(fotoUtamaPreview.value);
  }

  fotoUtamaPreview.value = null;
  fotoUtamaFile.value = null;

  if (fotoUtamaInput.value) {
    fotoUtamaInput.value.value = '';
  }
};

onBeforeUnmount(() => {
  clearFotoUtama();
});

/* =========================
   TOAST
========================= */

const showToast = (message: string, color = 'success') => {
  toastMessage.value = message;
  toastColor.value = color;
  toastOpen.value = true;
};

/* =========================
   KELOLA REALISASI
========================= */

const openRealisasi = (item: Campaign) => {
  router.push({
    name: 'AdminRealisasiCampaign',
    params: {
      campaignId: item.id
    }
  });
};

/* =========================
   EKSTRAK PAGINATION LARAVEL
========================= */

const extractCampaignData = (response: any) => {
  const root = response?.data;
  const paginator = root?.data;

  if (Array.isArray(paginator?.data)) {
    return {
      items: paginator.data,
      total: Number(paginator.total ?? paginator.data.length),
      lastPage: Number(paginator.last_page ?? 1),
      currentPage: Number(paginator.current_page ?? 1),
      perPage: Number(paginator.per_page ?? 10)
    };
  }

  if (Array.isArray(paginator)) {
    return {
      items: paginator,
      total: paginator.length,
      lastPage: 1,
      currentPage: 1,
      perPage: paginator.length || 10
    };
  }

  if (Array.isArray(root?.campaigns)) {
    return {
      items: root.campaigns,
      total: root.campaigns.length,
      lastPage: 1,
      currentPage: 1,
      perPage: root.campaigns.length || 10
    };
  }

  return {
    items: [],
    total: 0,
    lastPage: 1,
    currentPage: 1,
    perPage: 10
  };
};

/* =========================
   LOAD CAMPAIGN
========================= */

const loadCampaigns = async () => {
  loading.value = true;

  try {
    const response = await api.get('/admin/campaigns', {
      params: { page: currentPage.value }
    });

    const result = extractCampaignData(response);

    campaigns.value = result.items;
    totalCampaign.value = result.total;
    totalPages.value = result.lastPage;
    currentPage.value = result.currentPage;
  } catch (error: any) {
    console.error('ERROR CAMPAIGN:', error);

    campaigns.value = [];
    totalCampaign.value = 0;
    totalPages.value = 1;

    showToast(
      error.response?.data?.message || 'Gagal mengambil data campaign.',
      'danger'
    );
  } finally {
    loading.value = false;
  }
};

/* =========================
   LOAD KATEGORI
========================= */

const loadKategoriDana = async () => {
  try {
    const response = await api.get('/kategori-dana/list');
    const data = response.data?.data;

    kategoriDana.value = Array.isArray(data) ? data : [];
  } catch (error) {
    console.error('ERROR KATEGORI:', error);
    kategoriDana.value = [];
    showToast('Kategori dana gagal dimuat.', 'danger');
  }
};

const getCategoryLabel = (kategori: KategoriDana) => {
  return (
    kategori.nama_kategori ||
    kategori.nama ||
    kategori.kategori ||
    `Kategori ${kategori.id}`
  );
};

const getCategoryName = (item: Campaign) => {
  const kategori = item.kategori_dana || item.kategoriDana;

  if (kategori) return getCategoryLabel(kategori);

  const found = kategoriDana.value.find(
    k => Number(k.id) === Number(item.kategori_dana_id)
  );

  return found ? getCategoryLabel(found) : `ID ${item.kategori_dana_id}`;
};

/* =========================
   FILTER
========================= */

const filteredCampaigns = computed(() => {
  const keyword = search.value.toLowerCase().trim();

  return campaigns.value.filter(item => {
    const matchSearch = (item.judul || '')
      .toLowerCase()
      .includes(keyword);

    const status = (item.status || '').toLowerCase();

    const matchStatus =
      filterStatus.value === 'Semua' ||
      status === filterStatus.value.toLowerCase() ||
      (filterStatus.value === 'Nonaktif' && status === 'non aktif');

    return matchSearch && matchStatus;
  });
});

const countStatus = (status: string) => {
  return campaigns.value.filter(item => {
    const value = (item.status || '').toLowerCase();

    if (status === 'Nonaktif') {
      return value === 'nonaktif' || value === 'non aktif';
    }

    return value === status.toLowerCase();
  }).length;
};

/* =========================
   FORMAT RUPIAH
========================= */

const formatRupiah = (
  value: number | string | null | undefined
) => {
  const nominal = Number(value || 0);

  if (nominal >= 1_000_000_000) {
    return `Rp${(nominal / 1_000_000_000).toLocaleString('id-ID', {
      maximumFractionDigits: 2
    })} M`;
  }

  if (nominal >= 1_000_000) {
    return `Rp${(nominal / 1_000_000).toLocaleString('id-ID', {
      maximumFractionDigits: 2
    })} jt`;
  }

  if (nominal >= 1_000) {
    return `Rp${(nominal / 1_000).toLocaleString('id-ID', {
      maximumFractionDigits: 2
    })} rb`;
  }

  return `Rp${nominal.toLocaleString('id-ID')}`;
};

/* =========================
   FORMAT TANGGAL
========================= */

const formatDate = (value: string | null | undefined) => {
  if (!value) return '-';

  const date = new Date(`${value.substring(0, 10)}T00:00:00`);

  if (isNaN(date.getTime())) return '-';

  return new Intl.DateTimeFormat('id-ID', {
    day: '2-digit',
    month: 'short',
    year: '2-digit'
  })
    .format(date)
    .replace(/\./g, '');
};

/* =========================
   RESET FORM
========================= */

const resetForm = () => {
  clearFotoUtama();

  form.value = {
    id: null,
    judul: '',
    kategori_dana_id: null,
    target_dana: 0,
    tanggal_mulai: '',
    batas_waktu: '',
    lokasi: '',
    deskripsi: '',
    tipe_program: ''
  };

  targetDisplay.value = '';

};

/* =========================
   TAMBAH CAMPAIGN
========================= */

const openCreateModal = async () => {
  isEdit.value = false;
  resetForm();

  await loadKategoriDana();

  showModal.value = true;
};

/* =========================
   EDIT CAMPAIGN
========================= */

const openEditModal = (item: Campaign) => {
  isEdit.value = true;

  form.value = {
    id: item.id,
    judul: item.judul || '',
    kategori_dana_id: item.kategori_dana_id || null,
    target_dana: Number(item.target_dana) || 0,
    tanggal_mulai: item.tanggal_mulai || '',
    batas_waktu: item.batas_waktu || '',
    lokasi: item.lokasi || '',
    deskripsi: item.deskripsi || '',
    tipe_program: item.tipe_program || ''
  };

  targetDisplay.value = form.value.target_dana
    ? new Intl.NumberFormat('id-ID').format(form.value.target_dana)
    : '';

  clearFotoUtama();
  fotoUtamaPreview.value = getFotoUrl(item.foto_utama);

  showModal.value = true;
};

/* =========================
   TUTUP MODAL
========================= */

const closeModal = () => {
  showModal.value = false;
  showDatePicker.value = false;
  clearFotoUtama();
};

/* =========================
   INPUT TARGET DANA
========================= */

const handleTargetInput = (event: any) => {
  const raw = String(event.detail.value || '').replace(/\D/g, '');

  form.value.target_dana = Number(raw) || 0;

  targetDisplay.value = raw
    ? new Intl.NumberFormat('id-ID').format(Number(raw))
    : '';
};

/* =========================
   KALENDER
========================= */

const openDatePicker = (
  field: 'tanggal_mulai' | 'batas_waktu'
) => {
  selectedDateField.value = field;

  dateValue.value = form.value[field]
    ? `${form.value[field]}T00:00:00`
    : new Date().toISOString();

  showDatePicker.value = true;
};

const handleDateChange = (event: any) => {
  const value = event.detail.value;

  if (value) {
    form.value[selectedDateField.value] = String(value).substring(0, 10);
  }
};

/* =========================
   SIMPAN CAMPAIGN
========================= */

const saveCampaign = async () => {
  const plainDescription = form.value.deskripsi
    .replace(/<[^>]*>/g, '')
    .replace(/&nbsp;/g, ' ')
    .trim();

  if (
    !form.value.judul.trim() ||
    !form.value.kategori_dana_id ||
    !form.value.tanggal_mulai ||
    !plainDescription
  ) {
    showToast('Mohon lengkapi data campaign.', 'warning');
    return;
  }

  if (
    form.value.batas_waktu &&
    form.value.batas_waktu < form.value.tanggal_mulai
  ) {
    showToast(
      'Batas waktu tidak boleh sebelum tanggal mulai.',
      'warning'
    );
    return;
  }

  saving.value = true;

  /*
   * Gunakan FormData karena data berisi file foto.
   * Deskripsi Quill dikirim sebagai HTML.
   */
  const payload = new FormData();

  payload.append('judul', form.value.judul);
  payload.append(
    'kategori_dana_id',
    String(form.value.kategori_dana_id)
  );
  payload.append('target_dana', String(form.value.target_dana));
  payload.append('tanggal_mulai', form.value.tanggal_mulai);
  payload.append('batas_waktu', form.value.batas_waktu || '');
  payload.append('lokasi', form.value.lokasi || '');
  payload.append('deskripsi', form.value.deskripsi);
  payload.append('tipe_program', form.value.tipe_program);

  // foto_utama adalah satu file gambar, bukan array foto_utama[].
  // Jika edit tanpa memilih file baru, foto lama tetap dipertahankan backend.
  if (fotoUtamaFile.value) {
    payload.append('foto_utama', fotoUtamaFile.value);
  }

  try {
    if (isEdit.value && form.value.id) {
      /*
       * Laravel menerima multipart update melalui POST
       * dengan method spoofing _method=PUT.
       */
      payload.append('_method', 'PUT');

      await updateCampaign(form.value.id, payload as any);

      showToast('Campaign berhasil diperbarui.');
    } else {
      await createCampaign(payload as any);

      showToast('Campaign berhasil ditambahkan.');
    }

    closeModal();
    currentPage.value = 1;

    await loadCampaigns();
  } catch (error: any) {
    console.error('ERROR SIMPAN CAMPAIGN:', error);

    const validationErrors = error.response?.data?.errors;

    if (validationErrors) {
      const firstError = Object.values(validationErrors)
        .flat()
        .at(0);

      showToast(
        String(firstError || 'Periksa kembali data campaign.'),
        'danger'
      );
    } else {
      showToast(
        error.response?.data?.message || 'Campaign gagal disimpan.',
        'danger'
      );
    }
  } finally {
    saving.value = false;
  }
};

/* =========================
   HAPUS CAMPAIGN
========================= */

const confirmDelete = (item: Campaign) => {
  selectedCampaign.value = item;
  showDeleteAlert.value = true;
};

const deleteAlertButtons = [
  {
    text: 'Batal',
    role: 'cancel'
  },
  {
    text: 'Hapus',
    role: 'destructive',
    handler: async () => {
      if (!selectedCampaign.value) return;

      try {
        await deleteCampaign(selectedCampaign.value.id);

        showToast('Campaign berhasil dihapus.');

        if (
          campaigns.value.length === 1 &&
          currentPage.value > 1
        ) {
          currentPage.value--;
        }

        await loadCampaigns();
      } catch (error: any) {
        console.error('ERROR HAPUS CAMPAIGN:', error);

        showToast(
          error.response?.data?.message || 'Gagal menghapus campaign.',
          'danger'
        );
      }
    }
  }
];

/* =========================
   PAGINATION
========================= */

const changePage = async (page: number) => {
  if (
    page < 1 ||
    page > totalPages.value ||
    loading.value
  ) {
    return;
  }

  currentPage.value = page;
  await loadCampaigns();
};

/* =========================
   RESET FILTER
========================= */

const resetFilter = () => {
  search.value = '';
  filterStatus.value = 'Semua';
  currentPage.value = 1;
};

/* =========================
   LOAD AWAL
========================= */

onMounted(async () => {
  await Promise.all([
    loadCampaigns(),
    loadKategoriDana()
  ]);
});
</script>

<style scoped>
.green-toolbar {
  --background: #16834a;
  --color: #ffffff;
}

.green-toolbar ion-title {
  color: #ffffff;
  font-weight: 700;
}

.page-container {
  max-width: 1400px;
  margin: auto;
}

.page-heading {
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 12px;
  margin-bottom: 22px;
}

.page-heading h2 {
  margin: 0;
  font-size: 22px;
  font-weight: 750;
  color: #174b35;
}

.page-heading p,
.filter-title p,
.table-heading p {
  margin: 5px 0 0;
  color: #718579;
  font-size: 12px;
}

.add-button {
  --background: #16834a;
  --background-hover: #116b3b;
  --color: #ffffff;
  --border-radius: 10px;
  font-weight: 650;
  text-transform: none;
}

.summary-grid {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 13px;
  margin-bottom: 20px;
}

.summary-card {
  padding: 17px;
  border: 1px solid #e1eee5;
  border-radius: 13px;
  background: #ffffff;
}

.summary-card span {
  display: block;
  font-size: 12px;
  color: #718579;
}

.summary-card strong {
  display: block;
  margin-top: 8px;
  color: #174b35;
  font-size: 25px;
}

.summary-card.active {
  background: #effaf2;
  border-color: #d5eddd;
}

.summary-card.inactive {
  background: #fff8ed;
  border-color: #f4e5cc;
}

.summary-card.finished {
  background: #f0f7f2;
  border-color: #dcebe0;
}

.filter-panel,
.table-panel {
  background: #ffffff;
  border: 1px solid #e3ede6;
  border-radius: 14px;
  margin-bottom: 19px;
  overflow: hidden;
}

.filter-panel {
  padding: 18px;
}

.filter-title,
.table-heading {
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 12px;
}

.filter-title h3,
.table-heading h3 {
  margin: 0;
  font-size: 15px;
  font-weight: 750;
  color: #174b35;
}

.reset-button {
  --color: #16834a;
  --border-color: #b9d9c4;
  --background: #f3faf5;
  --background-hover: #e5f4e9;
  --border-radius: 9px;
  font-size: 12px;
  font-weight: 650;
  text-transform: none;
  min-height: 36px;
}

.filter-controls {
  display: grid;
  grid-template-columns: minmax(0, 1fr) 230px;
  gap: 13px;
  margin-top: 16px;
  align-items: center;
}

.custom-search {
  --background: #f3f8f4;
  --color: #244b35;
  --placeholder-color: #718579;
  --icon-color: #16834a;
  --clear-button-color: #16834a;
  --border-radius: 10px;
  --box-shadow: none;
  padding: 0;
  border: 1px solid #dcebe0;
}

.status-select {
  width: 100%;
  min-height: 46px;
  background: #f3f8f4;
  border: 1px solid #dcebe0;
  border-radius: 10px;
  padding: 0 12px;
  color: #244b35;
  font-size: 13px;
  font-weight: 600;
  --placeholder-color: #718579;
  --highlight-color: #16834a;
}

.table-heading {
  padding: 18px;
  border-bottom: 1px solid #e8f0ea;
}

.table-scroll {
  width: 100%;
  overflow-x: auto;
}

.campaign-table {
  width: 100%;
  table-layout: fixed;
  border-collapse: collapse;
  font-size: 12px;
}

.campaign-table th {
  padding: 14px 10px;
  background: #edf6ef;
  color: #315b40;
  text-align: left;
  font-weight: 750;
  border-bottom: 1px solid #dcebe0;
}

.campaign-table td {
  padding: 14px 10px;
  border-bottom: 1px solid #edf2ee;
  color: #52665a;
  vertical-align: middle;
  overflow-wrap: anywhere;
}

.campaign-table tbody tr:hover {
  background: #f6fbf7;
}

.campaign-table th:first-child,
.campaign-table td:first-child {
  width: 5%;
  text-align: center;
}

.campaign-table th:nth-child(2) {
  width: 20%;
}

.campaign-table th:nth-child(3) {
  width: 15%;
}

.campaign-table th:nth-child(4) {
  width: 13%;
}

.campaign-table th:nth-child(5),
.campaign-table th:nth-child(6) {
  width: 11%;
}

.campaign-table th:nth-child(7) {
  width: 10%;
}

.campaign-table th:nth-child(8) {
  width: 15%;
}

.campaign-name {
  color: #24533a !important;
  font-weight: 650;
}

.money {
  font-weight: 650;
}

.status-badge {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  padding: 5px 12px;
  border-radius: 20px;
  font-size: 12px;
  font-weight: 600;
  white-space: nowrap;
}

.status-aktif {
  background: #fff3cd;
  color: #856404;
  border: 1px solid #ffe69c;
}

.status-nonaktif {
  background: #f8d7da;
  color: #842029;
  border: 1px solid #f1aeb5;
}

.status-selesai {
  background: #d1e7dd;
  color: #0f5132;
  border: 1px solid #a3cfbb;
}

.action-buttons {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 1px;
  white-space: nowrap;
}

.action-buttons ion-button {
  --padding-start: 4px;
  --padding-end: 4px;
  margin: 0;
  min-width: 27px;
}

.pagination {
  padding: 16px 18px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 10px;
  color: #718579;
  font-size: 12px;
  border-top: 1px solid #e8f0ea;
}

.pagination-buttons {
  display: flex;
  gap: 8px;
}

.pagination-buttons ion-button {
  --color: #16834a;
  --border-color: #b9d9c4;
  --border-radius: 8px;
  font-size: 11px;
  text-transform: none;
}

.loading-state,
.empty-state {
  padding: 45px 15px;
  text-align: center;
  color: #718579;
}

.loading-state ion-spinner {
  width: 30px;
  height: 30px;
  color: #16834a;
}

.empty-state ion-icon {
  font-size: 40px;
  color: #8eae98;
}

.empty-state h3 {
  color: #315b40;
  font-size: 15px;
}

.form-container {
  max-width: 700px;
  margin: auto;
}

.form-container ion-item {
  --padding-start: 0;
  --highlight-color-focused: #16834a;
  margin-bottom: 10px;
}

.form-container ion-label {
  font-size: 13px;
  font-weight: 600;
  color: #315b40;
}

.custom-form-group {
  margin-top: 20px;
  margin-bottom: 18px;
}

.form-label {
  display: block;
  margin-bottom: 10px;
  color: #315b40;
  font-size: 13px;
  font-weight: 700;
}

/* UPLOAD FOTO */

.upload-area {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 30px 15px;
  border: 2px dashed #a9cdb4;
  border-radius: 13px;
  background: #f6fbf7;
  cursor: pointer;
  transition: 0.2s ease;
  text-align: center;
}

.upload-area:hover,
.upload-area.is-dragging {
  background: #eaf7ee;
  border-color: #16834a;
}

.upload-area ion-icon {
  font-size: 38px;
  color: #16834a;
}

.upload-area h4 {
  margin: 10px 0 5px;
  color: #24533a;
  font-size: 14px;
}

.upload-area p {
  margin: 0 0 8px;
  color: #718579;
  font-size: 12px;
}

.upload-area small,
.upload-info {
  color: #819187;
  font-size: 11px;
}

.photo-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(110px, 1fr));
  gap: 12px;
  margin-top: 15px;
}

.photo-preview {
  position: relative;
  height: 110px;
  overflow: hidden;
  border-radius: 10px;
  border: 1px solid #dcebe0;
  background: #f3f8f4;
}

.photo-preview img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.remove-photo {
  position: absolute;
  top: 5px;
  right: 5px;
  width: 25px;
  height: 25px;
  border: 0;
  border-radius: 50%;
  background: #dc3545;
  color: white;
  font-size: 19px;
  line-height: 1;
  cursor: pointer;
}

.upload-info {
  margin-top: 8px;
}

/* FOTO UTAMA */

.foto-utama-preview {
  width: 100%;
  max-width: 320px;
  height: 210px;
  overflow: hidden;
  border: 1px solid #dcebe0;
  border-radius: 12px;
  background: #f3f8f4;
  margin-bottom: 12px;
}

.foto-utama-preview img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  display: block;
}

.foto-utama-placeholder {
  width: 100%;
  max-width: 320px;
  height: 150px;
  display: flex;
  align-items: center;
  justify-content: center;
  border: 1px dashed #a9cdb4;
  border-radius: 12px;
  background: #f6fbf7;
  color: #718579;
  margin-bottom: 12px;
}

/* QUILL EDITOR */

.quill-wrapper {
  overflow: hidden;
  border: 1px solid #dcebe0;
  border-radius: 10px;
  background: white;
}

.quill-wrapper :deep(.ql-toolbar.ql-snow) {
  border: 0;
  border-bottom: 1px solid #dcebe0;
  background: #f6fbf7;
}

.quill-wrapper :deep(.ql-container.ql-snow) {
  border: 0;
  font-family: inherit;
  font-size: 14px;
}

.quill-wrapper :deep(.ql-editor) {
  min-height: 180px;
  color: #244b35;
  line-height: 1.6;
}

.quill-wrapper :deep(.ql-editor.ql-blank::before) {
  color: #9aaa9f;
  font-style: normal;
}

.quill-wrapper :deep(.ql-toolbar button:hover),
.quill-wrapper :deep(.ql-toolbar button.ql-active) {
  color: #16834a;
}

.save-button {
  margin-top: 22px;
  --background: #16834a;
  --background-hover: #116b3b;
  --border-radius: 10px;
  height: 46px;
  font-weight: 700;
  text-transform: none;
}

.date-modal {
  --height: auto;
  --max-height: 90%;
  --border-radius: 18px;
  align-items: center;
}

.date-modal ion-datetime {
  margin: auto;
  --ion-color-primary: #16834a;
}

ion-content {
  --background: #f5f8f6;
}

ion-modal {
  --background: #f8faf9;
}

ion-item {
  --background: #ffffff;
  --color: #244b35;
}

@media (max-width: 900px) {
  .campaign-table {
    font-size: 11px;
  }

  .campaign-table th,
  .campaign-table td {
    padding: 11px 7px;
  }

  .campaign-table th:nth-child(3),
  .campaign-table td:nth-child(3) {
    display: none;
  }

  .campaign-table th:nth-child(2) {
    width: 27%;
  }
}

@media (max-width: 600px) {
  .page-heading {
    align-items: stretch;
    flex-direction: column;
  }

  .page-heading .add-button {
    width: 100%;
    margin: 0;
  }

  .summary-grid {
    grid-template-columns: repeat(2, 1fr);
    gap: 10px;
  }

  .summary-card {
    padding: 13px;
  }

  .summary-card strong {
    font-size: 22px;
  }

  .filter-panel {
    padding: 14px;
  }

  .filter-title {
    align-items: flex-start;
  }

  .filter-controls {
    grid-template-columns: 1fr;
    gap: 10px;
  }

  .status-select {
    min-height: 45px;
  }

  .campaign-table {
    table-layout: auto;
    width: 100%;
    font-size: 11px;
  }

  .campaign-table th,
  .campaign-table td {
    padding: 10px 5px;
  }

  .campaign-table th:nth-child(3),
  .campaign-table td:nth-child(3),
  .campaign-table th:nth-child(5),
  .campaign-table td:nth-child(5),
  .campaign-table th:nth-child(6),
  .campaign-table td:nth-child(6) {
    display: none;
  }

  .campaign-table th:first-child,
  .campaign-table td:first-child {
    width: 30px;
  }

  .campaign-table th:nth-child(2) {
    width: 38%;
  }

  .campaign-table th:nth-child(4) {
    width: 22%;
  }

  .campaign-table th:nth-child(7) {
    width: 17%;
  }

  .campaign-table th:nth-child(8) {
    width: 100px;
  }

  .campaign-name {
    min-width: 0;
    font-size: 11px;
  }

  .money {
    font-size: 10px;
  }

  .status-badge {
    padding: 5px 7px;
    font-size: 9px;
  }

  .action-buttons {
    gap: 0;
  }

  .action-buttons ion-button {
    --padding-start: 2px;
    --padding-end: 2px;
    margin: 0;
    min-width: 27px;
  }

  .pagination {
    align-items: stretch;
    flex-direction: column;
  }

  .pagination-buttons {
    width: 100%;
  }

  .pagination-buttons ion-button {
    flex: 1;
  }

  .reset-button {
    font-size: 11px;
  }

  .photo-grid {
    grid-template-columns: repeat(3, 1fr);
  }
}
</style>
