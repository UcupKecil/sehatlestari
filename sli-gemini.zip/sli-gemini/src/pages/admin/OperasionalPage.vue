
<template>
  <ion-page>
    <!-- HEADER SAMA SEPERTI REALISASI -->
    <ion-header>
      <ion-toolbar class="green-toolbar">
        <ion-buttons slot="start">
          <ion-back-button default-href="/admin/dashboard" />
        </ion-buttons>

        <ion-title>Kelola Operasional</ion-title>

        <ion-buttons slot="end">
          <ion-button :disabled="loading" @click="loadData">
            <ion-icon
              :icon="refreshOutline"
              :class="{ spinning: loading }"
            />
          </ion-button>
        </ion-buttons>
      </ion-toolbar>
    </ion-header>

    <ion-content :fullscreen="true" class="operasional-content">
      <main class="page-container">

        <section class="page-heading">
          <div>
            <span class="eyebrow">PENGELOLAAN DANA</span>
            <h1>Pengeluaran Operasional</h1>
            <p>Kelola dan pantau penggunaan dana operasional yayasan.</p>
          </div>

          <button class="add-button" @click="openTambah">
            <ion-icon :icon="addOutline" />
            <span>Tambah Pengeluaran</span>
          </button>
        </section>

        <div v-if="success" class="alert-success">
          <ion-icon :icon="checkmarkCircleOutline" />
          {{ success }}
        </div>

        <div v-if="error" class="alert-error">
          <ion-icon :icon="alertCircleOutline" />
          {{ error }}
        </div>

        <section class="stats-grid">
          <div class="stat-card">
            <div class="stat-icon green">
              <ion-icon :icon="receiptOutline" />
            </div>
            <div>
              <span>Total Pengeluaran</span>
              <strong>{{ totalData }}</strong>
              <small>Transaksi operasional</small>
            </div>
          </div>

          <div class="stat-card">
            <div class="stat-icon orange">
              <ion-icon :icon="walletOutline" />
            </div>
            <div>
              <span>Total Nominal</span>
              <strong>{{ formatRupiah(totalNominal) }}</strong>
              <small>Pengeluaran yang dimuat</small>
            </div>
          </div>
        </section>

        <section class="data-card">
          <div class="card-heading">
            <div>
              <h2>Daftar Pengeluaran</h2>
              <p>Data pengeluaran operasional yayasan</p>
            </div>
          </div>

          <div class="filter-area">
  <div class="search-box">
    <ion-icon :icon="searchOutline" />

    <input
      v-model="search"
      type="text"
      placeholder="Cari pengeluaran..."
    />

    <button
      v-if="search"
      type="button"
      class="clear-search"
      @click="search = ''"
    >
      <ion-icon :icon="closeOutline" />
    </button>
  </div>

  <select v-model="sortDate" class="sort-select">
    <option value="newest">Tanggal terbaru</option>
    <option value="oldest">Tanggal terlama</option>
  </select>

  <button class="reset-button" @click="resetFilter">
    <ion-icon :icon="refreshOutline" />
    Reset
  </button>
</div>

          <div v-if="loading" class="loading-state">
            <ion-spinner name="crescent" />
            <span>Memuat data operasional...</span>
          </div>

          <div v-else class="table-wrapper">
            <table>
              <thead>
                <tr>
                  <th class="col-number">No.</th>
                  <th class="col-description">Pengeluaran</th>
                  <th class="col-category">Kategori</th>
                  <th class="col-account">Rekening Kas</th>
                  <th class="col-amount">Jumlah</th>
                  <th class="col-date">Tanggal</th>
                  <th class="col-action">Aksi</th>
                </tr>
              </thead>

              <tbody>
                <tr
                  v-for="(item, index) in filteredData"
                  :key="item.id"
                >
                  <td class="number-cell col-number">
                    {{ index + 1 }}
                  </td>

                  <td class="col-description">
                    <div class="main-cell">
                      <strong>{{ item.nama_pengeluaran }}</strong>
                      <small>{{ item.keterangan }}</small>
                    </div>
                  </td>

                  <td class="col-category">
                    <span class="category-badge">
                      {{ getKategoriName(item) }}
                    </span>
                  </td>

                  <td class="col-account">
                    <span class="rekening-text">
                      {{ getRekeningName(item) }}
                    </span>
                  </td>

                  <td class="amount-cell col-amount">
                    {{ formatRupiah(item.jumlah) }}
                  </td>

                  <td class="date-cell col-date">
                    {{ formatDate(item.tanggal_pengeluaran) }}
                  </td>

                  <td class="col-action">
                    <div class="action-buttons">
                      <button
                        class="action-button edit"
                        title="Edit"
                        @click="openEdit(item)"
                      >
                        <ion-icon :icon="createOutline" />
                      </button>

                      <button
                        class="action-button delete"
                        title="Hapus"
                        @click="confirmDelete(item)"
                      >
                        <ion-icon :icon="trashOutline" />
                      </button>
                    </div>
                  </td>
                </tr>

                <tr v-if="filteredData.length === 0">
                  <td colspan="7" class="empty-cell">
                    <ion-icon :icon="fileTrayOutline" />
                    <strong>Data tidak ditemukan</strong>
                    <span>
                      Belum ada data yang sesuai dengan pencarian.
                    </span>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>

          <div class="pagination">
            <span>Halaman {{ currentPage }} dari {{ lastPage }}</span>

            <div class="pagination-actions">
              <button
                :disabled="currentPage <= 1 || loading"
                @click="changePage(currentPage - 1)"
              >
                <ion-icon :icon="chevronBackOutline" />
              </button>

              <button
                :disabled="currentPage >= lastPage || loading"
                @click="changePage(currentPage + 1)"
              >
                <ion-icon :icon="chevronForwardOutline" />
              </button>
            </div>
          </div>
        </section>
      </main>

      <!-- MODAL FORM -->
      <div
        v-if="showModal"
        class="modal-overlay"
        @click.self="closeModal"
      >
        <div class="modal-card">

          <div class="modal-header">
            <div>
              <span>PENGELOLAAN DANA</span>
              <h2>
                {{ editId ? 'Edit Pengeluaran' : 'Tambah Pengeluaran' }}
              </h2>
            </div>

            <button class="close-button" @click="closeModal">
              <ion-icon :icon="closeOutline" />
            </button>
          </div>

          <form @submit.prevent="simpan" class="modal-form">

            <div class="form-group">
              <label>Kategori Operasional <span>*</span></label>

              <select
                v-model="form.kategori_operasional_id"
                required
                :disabled="loadingOptions"
              >
                <option :value="0" disabled>
                  {{
                    loadingOptions
                      ? 'Memuat kategori...'
                      : 'Pilih kategori operasional'
                  }}
                </option>

                <option
                  v-for="kategori in kategoriList"
                  :key="kategori.id"
                  :value="Number(kategori.id)"
                >
                  {{ getKategoriOptionName(kategori) }}
                </option>
              </select>
            </div>

            <div class="form-group">
              <label>Rekening Kas <span>*</span></label>

              <select
                v-model="form.rekening_kas_id"
                required
                :disabled="loadingOptions"
              >
                <option :value="0" disabled>
                  {{
                    loadingOptions
                      ? 'Memuat rekening...'
                      : 'Pilih rekening kas'
                  }}
                </option>

                <option
                  v-for="rekening in rekeningList"
                  :key="rekening.id"
                  :value="Number(rekening.id)"
                >
                  {{ getRekeningOptionName(rekening) }}
                </option>
              </select>
            </div>

            <div class="form-group">
              <label>Jumlah Pengeluaran <span>*</span></label>

              <div class="currency-input">
                <span>Rp</span>
                <input
                  :value="jumlahDisplay"
                  type="text"
                  inputmode="numeric"
                  placeholder="Masukkan jumlah pengeluaran"
                  @input="handleJumlahInput"
                  required
                />
              </div>

              <small class="input-hint">
                Masukkan nominal dalam Rupiah.
              </small>
            </div>

            <div class="form-group">
              <label>Tanggal Pengeluaran <span>*</span></label>

              <button
                type="button"
                class="date-input"
                @click="showDatePicker = true"
              >
                <span
                  :class="{
                    'placeholder-date': !form.tanggal_pengeluaran
                  }"
                >
                  {{
                    form.tanggal_pengeluaran
                      ? formatDateLong(form.tanggal_pengeluaran)
                      : 'Pilih tanggal pengeluaran'
                  }}
                </span>

                <ion-icon :icon="calendarOutline" />
              </button>
            </div>

            <div class="form-group">
              <label>Keterangan <span>*</span></label>

              <textarea
                v-model="form.keterangan"
                rows="4"
                maxlength="1000"
                placeholder="Jelaskan keperluan pengeluaran secara lengkap..."
                required
              />

              <small class="input-hint">
                {{ form.keterangan.length }}/1000 karakter
              </small>
            </div>

            <!-- UPLOAD GAMBAR -->
            <div class="form-group">
              <label>Bukti Transaksi</label>

              <input
                ref="fileInput"
                type="file"
                accept=".jpg,.jpeg,.png,.webp,image/jpeg,image/png,image/webp"
                class="hidden-file-input"
                @change="handleImageChange"
              />

              <div
                v-if="!previewUrl"
                class="upload-area"
                @click="triggerFileInput"
              >
                <div class="upload-icon">
                  <ion-icon :icon="cloudUploadOutline" />
                </div>

                <strong>Unggah Bukti Transaksi</strong>
                <span>Klik untuk memilih gambar</span>
                <small>JPG, JPEG, PNG, WEBP • Maksimal 5 MB</small>
              </div>

              <div v-else class="image-preview">
                <img
                  :src="previewUrl"
                  alt="Pratinjau bukti transaksi"
                />

                <div class="image-info">
                  <strong>
                    {{ selectedFile?.name || 'Bukti transaksi tersimpan' }}
                  </strong>

                  <span>
                    {{
                      selectedFile
                        ? formatFileSize(selectedFile.size)
                        : 'Gambar sebelumnya'
                    }}
                  </span>
                </div>

                <div class="image-actions">
                  <button
                    type="button"
                    class="image-change-button"
                    @click="triggerFileInput"
                  >
                    <ion-icon :icon="cameraOutline" />
                    Ganti
                  </button>

                  <button
                    type="button"
                    class="image-remove-button"
                    @click="removeImage"
                  >
                    <ion-icon :icon="trashOutline" />
                    Hapus
                  </button>
                </div>
              </div>

              <small v-if="imageError" class="image-error">
                {{ imageError }}
              </small>
            </div>

            <div v-if="formError" class="form-error">
              {{ formError }}
            </div>

            <div class="modal-actions">
              <button
                type="submit"
                class="save-button"
                :disabled="
                  saving ||
                  loadingOptions ||
                  !kategoriList.length ||
                  !rekeningList.length
                "
              >
                <ion-spinner v-if="saving" name="crescent" />

                <span>
                  {{
                    saving
                      ? 'Menyimpan...'
                      : editId
                        ? 'Simpan Perubahan'
                        : 'Simpan Pengeluaran'
                  }}
                </span>
              </button>
            </div>

          </form>
        </div>
      </div>

      <!-- POPUP KALENDER -->
      <ion-modal
        :is-open="showDatePicker"
        class="calendar-modal"
        @didDismiss="showDatePicker = false"
      >
        <div class="calendar-container">
          <div class="calendar-header">
            <div>
              <span>PILIH TANGGAL</span>
              <h3>Tanggal Pengeluaran</h3>
            </div>

            <button
              type="button"
              class="calendar-close"
              @click="showDatePicker = false"
            >
              <ion-icon :icon="closeOutline" />
            </button>
          </div>

          <ion-datetime
            presentation="date"
            locale="id-ID"
            :value="form.tanggal_pengeluaran || undefined"
            :max="today"
            @ionChange="handleDateChange"
          />

          <div class="calendar-footer">
            <button
              type="button"
              class="calendar-cancel"
              @click="showDatePicker = false"
            >
              Tutup
            </button>
          </div>
        </div>
      </ion-modal>

      <!-- BOTTOM NAVIGATION DIHAPUS -->

    </ion-content>
  </ion-page>
</template>

<script setup lang="ts">
import {
  ref,
  reactive,
  computed,
  onMounted,
  onBeforeUnmount
} from 'vue';

import {
  IonPage,
  IonHeader,
  IonToolbar,
  IonButtons,
  IonBackButton,
  IonTitle,
  IonContent,
  IonIcon,
  IonSpinner,
  IonModal,
  IonDatetime,
  alertController
} from '@ionic/vue';

import {
  refreshOutline,
  addOutline,
  receiptOutline,
  walletOutline,
  searchOutline,
  checkmarkCircleOutline,
  alertCircleOutline,
  createOutline,
  trashOutline,
  closeOutline,
  fileTrayOutline,
  chevronBackOutline,
  chevronForwardOutline,
  calendarOutline,
  cloudUploadOutline,
  cameraOutline
} from 'ionicons/icons';

import {
  getOperasional,
  getOperasionalDetail,
  createOperasional,
  updateOperasional,
  deleteOperasional,
  getKategoriOperasional,
  getRekeningKas
} from '../../services/adminService';

const dataList = ref<any[]>([]);
const kategoriList = ref<any[]>([]);
const rekeningList = ref<any[]>([]);

const loading = ref(false);
const loadingOptions = ref(false);
const saving = ref(false);

const showModal = ref(false);
const showDatePicker = ref(false);
const editId = ref<number | null>(null);

const success = ref('');
const error = ref('');
const formError = ref('');
const imageError = ref('');

const search = ref('');
const sortDate = ref('newest');

const currentPage = ref(1);
const lastPage = ref(1);
const perPage = ref(10);
const totalData = ref(0);

const jumlahDisplay = ref('');
const selectedFile = ref<File | null>(null);
const previewUrl = ref('');
const fileInput = ref<HTMLInputElement | null>(null);
const oldImagePath = ref('');

const today = new Date().toISOString().slice(0, 10);

const form = reactive({
  kategori_operasional_id: 0,
  rekening_kas_id: 0,
  jumlah: 0,
  tanggal_pengeluaran: '',
  keterangan: '',
  bukti_transaksi: ''
});

function extractList(result: any): any[] {
  const candidates = [
    result?.data?.data?.data,
    result?.data?.data,
    result?.data?.kategori,
    result?.data?.rekening,
    result?.data,
    result?.kategori,
    result?.rekening,
    result
  ];

  return candidates.find((item) => Array.isArray(item)) || [];
}

function unwrapDetail(result: any): any {
  return (
    result?.data?.data ??
    result?.data?.operasional ??
    result?.data ??
    result?.operasional ??
    result
  );
}

function getKategoriOptionName(item: any): string {
  return (
    item?.nama_kategori ??
    item?.nama ??
    item?.kategori ??
    item?.kategori_operasional ??
    item?.jenis_operasional ??
    'Nama kategori belum tersedia'
  );
}

function getRekeningOptionName(item: any): string {
  const nama =
    item?.nama_rekening ??
    item?.nama_rekening_kas ??
    item?.nama_bank ??
    item?.nama ??
    item?.rekening ??
    item?.bank;

  const nomor =
    item?.nomor_rekening ??
    item?.no_rekening ??
    item?.nomor ??
    '';

  if (nama && nomor) return `${nama} • ${nomor}`;

  return nama || 'Nama rekening belum tersedia';
}

function getKategoriName(item: any): string {
  const relation =
    item?.kategori_operasional ??
    item?.kategoriOperasional;

  if (relation) return getKategoriOptionName(relation);

  const found = kategoriList.value.find(
    (kategori) =>
      Number(kategori.id) ===
      Number(item.kategori_operasional_id)
  );

  return found
    ? getKategoriOptionName(found)
    : 'Kategori tidak tersedia';
}

function getRekeningName(item: any): string {
  const relation =
    item?.rekening_kas ??
    item?.rekeningKas;

  if (relation) return getRekeningOptionName(relation);

  const found = rekeningList.value.find(
    (rekening) =>
      Number(rekening.id) ===
      Number(item.rekening_kas_id)
  );

  return found
    ? getRekeningOptionName(found)
    : 'Rekening tidak tersedia';
}

// FORMAT RUPIAH RINGKAS
function formatRupiah(value: any): string {
  const nominal = Number(value || 0);

  if (nominal >= 1000000000) {
    return `Rp${new Intl.NumberFormat('id-ID', {
      maximumFractionDigits: 1
    }).format(nominal / 1000000000)} M`;
  }

  if (nominal >= 1000000) {
    return `Rp${new Intl.NumberFormat('id-ID', {
      maximumFractionDigits: 1
    }).format(nominal / 1000000)} Jt`;
  }

  if (nominal >= 1000) {
    return `Rp${new Intl.NumberFormat('id-ID', {
      maximumFractionDigits: 1
    }).format(nominal / 1000)} Rb`;
  }

  return new Intl.NumberFormat('id-ID', {
    style: 'currency',
    currency: 'IDR',
    maximumFractionDigits: 0
  }).format(nominal);
}

// FORMAT INPUT RUPIAH
function handleJumlahInput(event: Event) {
  const input = event.target as HTMLInputElement;
  const angka = input.value.replace(/\D/g, '');

  form.jumlah = angka ? Number(angka) : 0;

  jumlahDisplay.value = angka
    ? new Intl.NumberFormat('id-ID').format(Number(angka))
    : '';
}

// FORMAT TANGGAL TABEL
function formatDate(value: any): string {
  if (!value) return '-';

  const date = new Date(
    `${String(value).slice(0, 10)}T00:00:00`
  );

  if (Number.isNaN(date.getTime())) return String(value);

  return new Intl.DateTimeFormat('id-ID', {
    day: '2-digit',
    month: 'short',
    year: '2-digit'
  }).format(date);
}

// FORMAT TANGGAL FORM
function formatDateLong(value: string): string {
  if (!value) return '';

  const date = new Date(
    `${value.slice(0, 10)}T00:00:00`
  );

  if (Number.isNaN(date.getTime())) return value;

  return new Intl.DateTimeFormat('id-ID', {
    day: '2-digit',
    month: 'long',
    year: 'numeric'
  }).format(date);
}

function handleDateChange(event: CustomEvent) {
  const value = (event.detail as any)?.value;

  if (value) {
    form.tanggal_pengeluaran = String(value).slice(0, 10);
  }

  showDatePicker.value = false;
}

// FORMAT UKURAN FILE
function formatFileSize(size: number): string {
  if (size < 1024 * 1024) {
    return `${(size / 1024).toFixed(0)} KB`;
  }

  return `${(size / (1024 * 1024)).toFixed(2)} MB`;
}

function getExistingImageUrl(
  path: string | null | undefined
): string {
  if (!path) return '';

  if (
    path.startsWith('http://') ||
    path.startsWith('https://')
  ) {
    return path;
  }

  const cleanPath = path
    .replace(/^\/+/, '')
    .replace(/^storage\//, '');

  return `https://sehatlestariindonesia.vps-m.com/storage/${cleanPath}`;
}

// UPLOAD GAMBAR
function triggerFileInput() {
  fileInput.value?.click();
}

function handleImageChange(event: Event) {
  const input = event.target as HTMLInputElement;
  const originalFile = input.files?.[0];

  imageError.value = '';

  if (!originalFile) return;

  const extension = originalFile.name
    .split('.')
    .pop()
    ?.toLowerCase();

  const mimeTypes: Record<string, string> = {
    jpg: 'image/jpeg',
    jpeg: 'image/jpeg',
    png: 'image/png',
    webp: 'image/webp'
  };

  if (!extension || !mimeTypes[extension]) {
    imageError.value =
      'Format gambar harus JPG, JPEG, PNG, atau WEBP.';

    input.value = '';
    return;
  }

  if (originalFile.size > 5 * 1024 * 1024) {
    imageError.value =
      'Ukuran gambar maksimal 5 MB.';

    input.value = '';
    return;
  }

  if (previewUrl.value.startsWith('blob:')) {
    URL.revokeObjectURL(previewUrl.value);
  }

  const imageFile = new File(
    [originalFile],
    originalFile.name,
    {
      type: mimeTypes[extension],
      lastModified: originalFile.lastModified
    }
  );

  selectedFile.value = imageFile;
  previewUrl.value = URL.createObjectURL(imageFile);

  console.log('File upload:', {
    name: imageFile.name,
    type: imageFile.type,
    size: imageFile.size
  });

  input.value = '';
}

function removeImage() {
  if (previewUrl.value.startsWith('blob:')) {
    URL.revokeObjectURL(previewUrl.value);
  }

  selectedFile.value = null;
  previewUrl.value = '';
  oldImagePath.value = '';
  form.bukti_transaksi = '';

  if (fileInput.value) {
    fileInput.value.value = '';
  }
}

// FILTER DATA
const filteredData = computed(() => {
  let result = [...dataList.value];

  const keyword = search.value.toLowerCase().trim();

  if (keyword) {
    result = result.filter((item) => {
      const text = [
        item.nama_pengeluaran,
        item.keterangan,
        item.kode_pengeluaran,
        getKategoriName(item),
        getRekeningName(item)
      ]
        .join(' ')
        .toLowerCase();

      return text.includes(keyword);
    });
  }

  result.sort((a, b) => {
    const dateA = new Date(
      a.tanggal_pengeluaran || 0
    ).getTime();

    const dateB = new Date(
      b.tanggal_pengeluaran || 0
    ).getTime();

    return sortDate.value === 'newest'
      ? dateB - dateA
      : dateA - dateB;
  });

  return result;
});

const totalNominal = computed(() => {
  return dataList.value.reduce(
    (total, item) =>
      total + Number(item.jumlah || 0),
    0
  );
});

// MEMUAT DATA
async function loadData() {
  loading.value = true;
  error.value = '';

  try {
    const [
      operasionalResult,
      kategoriResult,
      rekeningResult
    ] = await Promise.all([
      getOperasional(),
      getKategoriOperasional(),
      getRekeningKas()
    ]);

    dataList.value = extractList(operasionalResult);
    kategoriList.value = extractList(kategoriResult);
    rekeningList.value = extractList(rekeningResult);

    const pagination =
      operasionalResult?.data?.data ??
      operasionalResult?.data ??
      {};

    totalData.value = Number(
      pagination?.total ?? dataList.value.length
    );

    currentPage.value = Number(
      pagination?.current_page ?? 1
    );

    lastPage.value = Number(
      pagination?.last_page ?? 1
    );

    perPage.value = Number(
      pagination?.per_page ?? 10
    );

  } catch (err: any) {
    error.value =
      err?.response?.data?.message ||
      'Gagal memuat data operasional.';
  } finally {
    loading.value = false;
  }
}

// PAGINATION
async function changePage(page: number) {
  if (page < 1 || page > lastPage.value) return;

  loading.value = true;
  error.value = '';

  try {
    const result = await getOperasional(page);

    dataList.value = extractList(result);

    const pagination =
      result?.data?.data ??
      result?.data ??
      {};

    currentPage.value = Number(
      pagination?.current_page ?? page
    );

    lastPage.value = Number(
      pagination?.last_page ?? lastPage.value
    );

    totalData.value = Number(
      pagination?.total ?? totalData.value
    );

  } catch (err: any) {
    error.value =
      err?.response?.data?.message ||
      'Gagal memuat halaman data.';
  } finally {
    loading.value = false;
  }
}

function resetFilter() {
  search.value = '';
  sortDate.value = 'newest';
}

// RESET FORM
function resetForm() {
  form.kategori_operasional_id = 0;
  form.rekening_kas_id = 0;
  form.jumlah = 0;
  form.tanggal_pengeluaran = '';
  form.keterangan = '';
  form.bukti_transaksi = '';

  jumlahDisplay.value = '';
  selectedFile.value = null;
  imageError.value = '';
  oldImagePath.value = '';

  if (previewUrl.value.startsWith('blob:')) {
    URL.revokeObjectURL(previewUrl.value);
  }

  previewUrl.value = '';

  if (fileInput.value) {
    fileInput.value.value = '';
  }
}

// TAMBAH
function openTambah() {
  editId.value = null;
  formError.value = '';

  resetForm();

  showModal.value = true;
}

// EDIT
async function openEdit(item: any) {
  editId.value = Number(item.id);
  formError.value = '';

  resetForm();

  showModal.value = true;

  try {
    const result = await getOperasionalDetail(
      Number(item.id)
    );

    const detail = unwrapDetail(result);

    form.kategori_operasional_id = Number(
      detail.kategori_operasional_id ??
      item.kategori_operasional_id ??
      0
    );

    form.rekening_kas_id = Number(
      detail.rekening_kas_id ??
      item.rekening_kas_id ??
      0
    );

    form.jumlah = Number(
      detail.jumlah ?? item.jumlah ?? 0
    );

    jumlahDisplay.value = form.jumlah
      ? new Intl.NumberFormat('id-ID').format(form.jumlah)
      : '';

    form.tanggal_pengeluaran = String(
      detail.tanggal_pengeluaran ??
      item.tanggal_pengeluaran ??
      ''
    ).slice(0, 10);

    form.keterangan =
      detail.keterangan ??
      item.keterangan ??
      '';

    form.bukti_transaksi =
      detail.bukti_transaksi ??
      item.bukti_transaksi ??
      '';

    oldImagePath.value = form.bukti_transaksi;

    if (oldImagePath.value) {
      previewUrl.value = getExistingImageUrl(
        oldImagePath.value
      );
    }

  } catch (err: any) {
    formError.value =
      err?.response?.data?.message ||
      'Gagal mengambil detail pengeluaran.';
  }
}

// TUTUP MODAL
function closeModal() {
  if (saving.value) return;

  showModal.value = false;
  showDatePicker.value = false;
  formError.value = '';

  if (previewUrl.value.startsWith('blob:')) {
    URL.revokeObjectURL(previewUrl.value);
  }
}

// SIMPAN
async function simpan() {
  formError.value = '';
  imageError.value = '';

  if (!form.kategori_operasional_id) {
    formError.value =
      'Silakan pilih kategori operasional.';
    return;
  }

  if (!form.rekening_kas_id) {
    formError.value =
      'Silakan pilih rekening kas.';
    return;
  }

  if (Number(form.jumlah) <= 0) {
    formError.value =
      'Jumlah pengeluaran harus lebih dari nol.';
    return;
  }

  if (!form.tanggal_pengeluaran) {
    formError.value =
      'Tanggal pengeluaran wajib diisi.';
    return;
  }

  if (!form.keterangan.trim()) {
    formError.value = 'Keterangan wajib diisi.';
    return;
  }

  const payload = new FormData();

  payload.append(
    'kategori_operasional_id',
    String(form.kategori_operasional_id)
  );

  payload.append(
    'rekening_kas_id',
    String(form.rekening_kas_id)
  );

  payload.append(
    'jumlah',
    String(form.jumlah)
  );

  payload.append(
    'tanggal_pengeluaran',
    form.tanggal_pengeluaran
  );

  payload.append(
    'keterangan',
    form.keterangan.trim()
  );

  if (selectedFile.value) {
    payload.append(
      'bukti_transaksi',
      selectedFile.value,
      selectedFile.value.name
    );
  }

  console.log('Data FormData:');

  payload.forEach((value, key) => {
    if (value instanceof File) {
      console.log(key, {
        name: value.name,
        type: value.type,
        size: value.size
      });
    } else {
      console.log(key, value);
    }
  });

  saving.value = true;

  try {
    if (editId.value) {
      await updateOperasional(
        editId.value,
        payload as any
      );

      success.value =
        'Pengeluaran berhasil diperbarui.';

    } else {
      await createOperasional(payload as any);

      success.value =
        'Pengeluaran berhasil ditambahkan.';
    }

    showModal.value = false;

    await loadData();

  } catch (err: any) {
    formError.value =
      err?.response?.data?.message ||
      'Gagal menyimpan data pengeluaran.';

    const validationErrors =
      err?.response?.data?.errors;

    if (validationErrors) {
      formError.value = Object.values(validationErrors)
        .flat()
        .join(' ');
    }

  } finally {
    saving.value = false;
  }
}

// KONFIRMASI HAPUS
async function confirmDelete(item: any) {
  const alert = await alertController.create({
    header: 'Hapus Pengeluaran?',
    message: `Data "${item.keterangan || 'pengeluaran ini'}" akan dihapus.`,
    buttons: [
      {
        text: 'Batal',
        role: 'cancel'
      },
      {
        text: 'Hapus',
        role: 'destructive',
        handler: () => {
          hapus(Number(item.id));
        }
      }
    ]
  });

  await alert.present();
}

// HAPUS
async function hapus(id: number) {
  error.value = '';

  try {
    await deleteOperasional(id);

    success.value =
      'Pengeluaran berhasil dihapus.';

    await loadData();

  } catch (err: any) {
    error.value =
      err?.response?.data?.message ||
      'Gagal menghapus pengeluaran.';
  }
}

onMounted(() => {
  loadData();
});

onBeforeUnmount(() => {
  if (previewUrl.value.startsWith('blob:')) {
    URL.revokeObjectURL(previewUrl.value);
  }
});
</script>

<style scoped>
/* HEADER */
.green-toolbar {
  --background: #16834a;
  --color: #ffffff;
  --border-color: transparent;
}

.green-toolbar ion-title {
  color: #ffffff;
  font-weight: 700;
}

.green-toolbar ion-back-button,
.green-toolbar ion-button {
  --color: #ffffff;
}

.spinning {
  animation: spin 1s linear infinite;
}

@keyframes spin {
  to {
    transform: rotate(360deg);
  }
}

/* CONTENT */
.operasional-content {
  --background: #f5f8f6;
  --padding-bottom: 24px;

  overflow: auto;
  scrollbar-width: none;
  -ms-overflow-style: none;
}

.operasional-content::part(scroll) {
  scrollbar-width: none;
  -ms-overflow-style: none;
}

.operasional-content::part(scroll)::-webkit-scrollbar {
  display: none;
  width: 0;
  height: 0;
}

.page-container {
  max-width: 1250px;
  margin: 0 auto;
  padding: 30px 24px 40px;
}

.page-heading {
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 20px;
  margin-bottom: 25px;
}

.eyebrow {
  color: #16834a;
  font-size: 10px;
  font-weight: 800;
  letter-spacing: 1.5px;
}

.page-heading h1 {
  color: #244b35;
  font-size: 27px;
  font-weight: 800;
  margin: 7px 0;
}

.page-heading p {
  color: #819087;
  font-size: 13px;
  margin: 0;
}

.add-button,
.save-button {
  border: 0;
  background: #16834a;
  color: white;
  border-radius: 10px;
  padding: 12px 17px;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  font-size: 13px;
  font-weight: 700;
}

.add-button ion-icon {
  font-size: 18px;
}

/* ALERT */
.alert-success,
.alert-error {
  padding: 12px 15px;
  border-radius: 10px;
  display: flex;
  align-items: center;
  gap: 9px;
  margin-bottom: 15px;
  font-size: 13px;
}

.alert-success {
  background: #e7f5ec;
  color: #16834a;
}

.alert-error {
  background: #fff0ef;
  color: #c43b35;
}

/* STATISTIK */
.stats-grid {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 16px;
  margin-bottom: 22px;
}

.stat-card {
  display: flex;
  align-items: center;
  gap: 15px;
  background: #ffffff;
  border: 1px solid #e8efe9;
  border-radius: 14px;
  padding: 19px;
  box-shadow: 0 3px 12px rgba(35, 80, 50, 0.035);
  min-width: 0;
}

.stat-icon {
  width: 46px;
  height: 46px;
  border-radius: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 23px;
  flex-shrink: 0;
}

.stat-icon.green {
  color: #16834a;
  background: #e7f5ec;
}

.stat-icon.orange {
  color: #d58a25;
  background: #fff4e4;
}

.stat-card span,
.stat-card small {
  display: block;
  color: #819087;
  font-size: 11px;
}

.stat-card strong {
  display: block;
  color: #244b35;
  font-size: 21px;
  margin: 5px 0;
  overflow-wrap: anywhere;
}

.stat-card small {
  font-size: 10px;
}

/* DATA CARD */
.data-card {
  background: #ffffff;
  border: 1px solid #e8efe9;
  border-radius: 15px;
  padding: 22px;
  box-shadow: 0 3px 12px rgba(35, 80, 50, 0.035);
}

.card-heading h2 {
  color: #244b35;
  font-size: 17px;
  font-weight: 800;
  margin: 0 0 5px;
}

.card-heading p {
  color: #89978e;
  font-size: 12px;
  margin: 0;
}

/* FILTER DAN PENCARIAN */
.filter-area {
  display: flex;
  align-items: center;
  gap: 10px;
  margin: 20px 0;
}

.search-box {
  flex: 1;
  min-width: 180px;
  height: 42px;
  display: flex;
  align-items: center;
  gap: 10px;
  border: 1px solid #e3ebe5;
  border-radius: 10px;
  padding: 0 13px;
  background: #ffffff;
  color: #829187;
  transition: border-color 0.2s, box-shadow 0.2s;
}

.search-box:focus-within {
  border-color: #16834a;
  box-shadow: 0 0 0 3px rgba(22, 131, 74, 0.08);
}

.search-box > ion-icon {
  flex-shrink: 0;
  font-size: 18px;
  color: #829187;
}

.search-box input {
  flex: 1;
  min-width: 0;
  height: 100%;
  border: 0;
  outline: none;
  color: #244b35;
  background: transparent;
  font-family: inherit;
  font-size: 13px;
}

.search-box input::placeholder {
  color: #a6b1aa;
}

.clear-search {
  width: 25px;
  height: 25px;
  flex-shrink: 0;
  border: 0;
  border-radius: 6px;
  background: #f0f5f1;
  color: #819087;
  display: flex;
  align-items: center;
  justify-content: center;
}

.clear-search ion-icon {
  font-size: 15px;
}

.sort-select {
  height: 42px;
  border: 1px solid #e3ebe5;
  border-radius: 10px;
  background: #ffffff;
  color: #52675a;
  padding: 0 12px;
  font-family: inherit;
  font-size: 12px;
}

.reset-button {
  height: 42px;
  padding: 0 13px;
  border: 1px solid #e3ebe5;
  background: #ffffff;
  color: #61766a;
  border-radius: 10px;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
  font-family: inherit;
  font-size: 12px;
}

/* LOADING */
.loading-state {
  min-height: 180px;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 10px;
  color: #819087;
  font-size: 13px;
}

.loading-state ion-spinner {
  color: #16834a;
}

/* TABEL */
.table-wrapper {
  width: 100%;
  max-width: 100%;
  overflow-x: auto;
  overflow-y: hidden;
  scrollbar-width: none;
  -ms-overflow-style: none;
}

.table-wrapper::-webkit-scrollbar {
  display: none;
  width: 0;
  height: 0;
}

table {
  width: 100%;
  min-width: 850px;
  border-collapse: collapse;
  table-layout: auto;
  text-align: left;
}

thead {
  background: #f5f8f6;
}

th {
  color: #718278;
  font-size: 11px;
  font-weight: 700;
  padding: 13px 12px;
  white-space: nowrap;
}

td {
  padding: 14px 12px;
  border-bottom: 1px solid #edf1ee;
  color: #52675a;
  font-size: 12px;
  vertical-align: middle;
}

.number-cell {
  color: #98a69d;
  width: 45px;
}

.main-cell strong {
  display: block;
  max-width: 230px;
  color: #244b35;
  font-size: 12px;
  line-height: 1.5;
}

.main-cell small {
  display: block;
  color: #99a69e;
  font-size: 10px;
  margin-top: 4px;
}

.category-badge {
  display: inline-block;
  background: #e7f5ec;
  color: #16834a;
  border-radius: 7px;
  padding: 6px 9px;
  font-size: 10px;
  font-weight: 700;
}

.rekening-text {
  color: #52675a;
  white-space: nowrap;
}

.amount-cell {
  color: #16834a;
  font-weight: 800;
  white-space: nowrap;
}

.date-cell {
  white-space: nowrap;
}

/* TOMBOL AKSI */
.action-buttons {
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  flex-wrap: nowrap;
  gap: 4px;
}

.action-button {
  flex: 0 0 auto;
  width: 25px;
  height: 25px;
  border: 0;
  border-radius: 8px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 15px;
}

.action-button.edit {
  background: #e7f5ec;
  color: #16834a;
}

.action-button.delete {
  background: #fff0ef;
  color: #d14b45;
}

/* DATA KOSONG */
.empty-cell {
  height: 160px;
  text-align: center;
  color: #94a198;
}

.empty-cell ion-icon {
  display: block;
  margin: 0 auto 8px;
  font-size: 26px;
}

.empty-cell strong,
.empty-cell span {
  display: block;
}

.empty-cell strong {
  color: #52675a;
  margin-bottom: 5px;
}

.empty-cell span {
  font-size: 11px;
}

/* PAGINATION */
.pagination {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  padding-top: 17px;
  color: #87958c;
  font-size: 11px;
}

.pagination-actions {
  display: flex;
  gap: 7px;
}

.pagination-actions button {
  width: 32px;
  height: 32px;
  border: 1px solid #e3ebe5;
  border-radius: 8px;
  background: white;
  color: #16834a;
}

.pagination-actions button:disabled {
  color: #c1cbc4;
  background: #f7f9f7;
}

/* MODAL */
.modal-overlay {
  position: fixed;
  inset: 0;
  z-index: 1000;
  background: rgba(21, 42, 29, 0.48);
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 20px;
}

.modal-card {
  width: 100%;
  max-width: 520px;
  max-height: 92vh;
  overflow-y: auto;
  overflow-x: hidden;
  background: #ffffff;
  border-radius: 17px;
  box-shadow: 0 15px 50px rgba(0, 0, 0, 0.15);
  scrollbar-width: none;
  -ms-overflow-style: none;
}

.modal-card::-webkit-scrollbar {
  display: none;
}

.modal-header {
  background: #16834a;
  color: #ffffff;
  padding: 20px 23px;
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.modal-header span {
  font-size: 9px;
  letter-spacing: 1.3px;
  opacity: 0.8;
  font-weight: 700;
}

.modal-header h2 {
  font-size: 18px;
  margin: 5px 0 0;
  font-weight: 800;
}

.close-button {
  width: 34px;
  height: 34px;
  border: 0;
  border-radius: 9px;
  background: rgba(255, 255, 255, 0.17);
  color: white;
  font-size: 21px;
  display: flex;
  align-items: center;
  justify-content: center;
}

.modal-form {
  padding: 22px;
}

.form-group {
  margin-bottom: 17px;
}

.form-group label {
  display: block;
  color: #365541;
  font-size: 12px;
  font-weight: 700;
  margin-bottom: 8px;
}

.form-group label span {
  color: #d64b45;
}

.form-group input,
.form-group select,
.form-group textarea {
  display: block;
  width: 100%;
  min-height: 43px;
  border: 1px solid #dfe9e2;
  border-radius: 9px;
  padding: 10px 12px;
  color: #244b35;
  background: #ffffff;
  outline: none;
  font-family: inherit;
  font-size: 12px;
  box-sizing: border-box;
}

.form-group textarea {
  resize: vertical;
  min-height: 105px;
  line-height: 1.6;
}

.form-group input:focus,
.form-group select:focus,
.form-group textarea:focus {
  border-color: #16834a;
  box-shadow: 0 0 0 3px rgba(22, 131, 74, 0.08);
}

.form-group input::placeholder,
.form-group textarea::placeholder {
  color: #a6b1aa;
}

.form-group select:disabled {
  background: #f5f8f6;
  color: #9ba89f;
}

.input-hint {
  display: block;
  color: #99a69e;
  font-size: 10px;
  margin-top: 6px;
}

/* INPUT RUPIAH */
.currency-input {
  display: flex;
  align-items: center;
  min-height: 43px;
  border: 1px solid #dfe9e2;
  border-radius: 9px;
  overflow: hidden;
}

.currency-input:focus-within {
  border-color: #16834a;
  box-shadow: 0 0 0 3px rgba(22, 131, 74, 0.08);
}

.currency-input > span {
  padding: 0 12px;
  color: #16834a;
  font-weight: 800;
  font-size: 13px;
}

.currency-input input {
  border: 0;
  box-shadow: none !important;
  border-radius: 0;
  min-width: 0;
}

/* INPUT TANGGAL */
.date-input {
  width: 100%;
  min-height: 43px;
  border: 1px solid #dfe9e2;
  border-radius: 9px;
  background: #ffffff;
  padding: 0 12px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  color: #244b35;
  font-family: inherit;
  font-size: 12px;
  text-align: left;
}

.date-input ion-icon {
  color: #16834a;
  font-size: 19px;
}

.placeholder-date {
  color: #a6b1aa;
}

/* UPLOAD GAMBAR */
.hidden-file-input {
  display: none !important;
}

.upload-area {
  min-height: 155px;
  border: 1.5px dashed #b9d7c2;
  border-radius: 12px;
  background: #f8fbf9;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  padding: 18px;
  text-align: center;
  transition: 0.2s;
}

.upload-area:hover {
  border-color: #16834a;
  background: #f1f8f3;
}

.upload-icon {
  width: 43px;
  height: 43px;
  border-radius: 12px;
  background: #e7f5ec;
  color: #16834a;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 23px;
  margin-bottom: 10px;
}

.upload-area strong {
  color: #365541;
  font-size: 12px;
}

.upload-area span {
  color: #819087;
  font-size: 11px;
  margin-top: 5px;
}

.upload-area small {
  color: #a0ada4;
  font-size: 10px;
  margin-top: 7px;
}

.image-preview {
  border: 1px solid #e2ebe5;
  border-radius: 11px;
  overflow: hidden;
  background: #ffffff;
}

.image-preview img {
  display: block;
  width: 100%;
  max-height: 230px;
  object-fit: contain;
  background: #f5f8f6;
}

.image-info {
  padding: 10px 12px 5px;
}

.image-info strong,
.image-info span {
  display: block;
  overflow-wrap: anywhere;
}

.image-info strong {
  color: #365541;
  font-size: 11px;
}

.image-info span {
  color: #99a69e;
  font-size: 10px;
  margin-top: 4px;
}

.image-actions {
  display: flex;
  gap: 8px;
  padding: 9px 12px 12px;
}

.image-change-button,
.image-remove-button {
  flex: 1;
  min-height: 35px;
  border: 0;
  border-radius: 8px;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
  font-size: 11px;
  font-weight: 700;
}

.image-change-button {
  background: #e7f5ec;
  color: #16834a;
}

.image-remove-button {
  background: #fff0ef;
  color: #c43b35;
}

.image-error {
  display: block;
  color: #c43b35;
  font-size: 11px;
  margin-top: 7px;
}

.form-error {
  color: #c43b35;
  background: #fff0ef;
  padding: 11px;
  border-radius: 8px;
  font-size: 12px;
  margin-bottom: 14px;
}

.modal-actions {
  padding-top: 5px;
}

.save-button {
  width: 100%;
  min-height: 44px;
}

.save-button:disabled {
  opacity: 0.65;
}

/* KALENDER */
.calendar-modal {
  --width: 350px;
  --height: auto;
  --border-radius: 16px;
}

.calendar-container {
  background: #ffffff;
  padding: 18px;
}

.calendar-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 5px 4px 12px;
}

.calendar-header span {
  color: #16834a;
  font-size: 9px;
  letter-spacing: 1.2px;
  font-weight: 800;
}

.calendar-header h3 {
  color: #244b35;
  font-size: 17px;
  margin: 5px 0 0;
}

.calendar-close {
  width: 32px;
  height: 32px;
  border: 0;
  border-radius: 8px;
  background: #f0f5f1;
  color: #52705c;
  font-size: 19px;
}

.calendar-container ion-datetime {
  --background: #ffffff;
  --title-color: #244b35;
  --wheel-highlight-background: #e7f5ec;
  width: 100%;
  color: #244b35;
}

.calendar-footer {
  display: flex;
  justify-content: flex-end;
  padding-top: 10px;
}

.calendar-cancel {
  border: 0;
  border-radius: 8px;
  background: #e7f5ec;
  color: #16834a;
  padding: 9px 18px;
  font-size: 12px;
  font-weight: 700;
}

/* RESPONSIVE */
@media (max-width: 700px) {
  .page-container {
    padding: 23px 14px 30px;
  }

  .page-heading {
    align-items: flex-start;
    flex-direction: column;
    gap: 14px;
  }

  .page-heading h1 {
    font-size: 22px;
  }

  .add-button {
    width: 100%;
  }

  .stats-grid {
    gap: 10px;
  }

  .stat-card {
    padding: 13px 10px;
    gap: 9px;
  }

  .stat-icon {
    width: 36px;
    height: 36px;
    font-size: 19px;
  }

  .stat-card span {
    font-size: 10px;
  }

  .stat-card strong {
    font-size: 16px;
  }

  .stat-card small {
    font-size: 9px;
  }

  .data-card {
    padding: 15px 12px;
  }

  .filter-area {
  flex-direction: column;
  align-items: stretch;
  gap: 9px;
}

.search-box,
.sort-select,
.reset-button {
  width: 100%;
  box-sizing: border-box;
}

.search-box {
  min-height: 42px;
}

.reset-button {
  justify-content: center;
}

  .modal-overlay {
    padding: 0;
    align-items: stretch;
    overflow: hidden;
  }

  .modal-card {
    width: 100%;
    max-width: none;
    height: 100%;
    max-height: 100%;
    border-radius: 0;
    overflow-y: auto;
    overflow-x: hidden;
  }

  .modal-header {
    padding: 20px;
  }

  .modal-form {
    padding: 20px;
    padding-bottom: 30px;
  }

  .calendar-modal {
    --width: calc(100% - 28px);
    --height: auto;
  }

  .table-wrapper {
    overflow-x: hidden;
  }

  table {
    width: 100%;
    min-width: 0;
    table-layout: fixed;
  }

  /* Sembunyikan rekening kas di HP */
  .col-account {
    display: none !important;
  }

  /* Pembagian lebar kolom */
  .col-number {
    width: 8%;
  }

  .col-description {
    width: 29%;
  }

  .col-category {
    width: 19%;
  }

  .col-amount {
    width: 18%;
  }

  .col-date {
    width: 16%;
  }

  .col-action {
    width: 10%;
  }

  /* Ukuran teks tabel */
  th,
  td {
    padding: 10px 3px;
    font-size: 9px;
    overflow-wrap: anywhere;
    white-space: normal;
  }

  .main-cell {
    min-width: 0;
    max-width: 100%;
  }

  .main-cell strong {
    max-width: 100%;
    font-size: 9px;
    font-weight: 600;
    -webkit-line-clamp: 2;
    line-clamp: 2;
  }

  .main-cell small {
    max-width: 100%;
    font-size: 8px;
    -webkit-line-clamp: 2;
    line-clamp: 2;
  }

  .category-badge {
    max-width: 100%;
    padding: 4px;
    font-size: 8px;
    -webkit-line-clamp: 2;
    line-clamp: 2;
  }

  .rekening-text {
    -webkit-line-clamp: 2;
    line-clamp: 2;
  }

  .amount-cell,
  .date-cell {
    white-space: normal;
    overflow-wrap: anywhere;
  }

  .action-buttons {
    flex-direction: row;
    flex-wrap: nowrap;
    gap: 4px;
  }

  .action-button {
    width: 25px;
    height: 25px;
    font-size: 12px;
  }
}

/* BATAS TEKS MAKSIMAL 2 BARIS */
.main-cell strong,
.main-cell small,
.rekening-text,
.category-badge {
  display: -webkit-box;
  -webkit-box-orient: vertical;
  -webkit-line-clamp: 2;
  line-clamp: 2;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: normal;
  overflow-wrap: anywhere;
  word-break: break-word;
}

/* HP LAYAR KECIL */
@media (max-width: 380px) {
  th,
  td {
    padding: 8px 2px;
    font-size: 8px;
  }

  .main-cell strong {
    font-size: 8px;
  }

  .main-cell small {
    font-size: 7px;
  }

  .category-badge {
    font-size: 7px;
    padding: 3px;
  }

  .action-buttons {
    flex-direction: row;
    flex-wrap: nowrap;
    gap: 2px;
  }

  .action-button {
    width: 22px;
    height: 22px;
  }
}
</style>
