import api from './api';

// ===============================
// MUSTAHIK
// ===============================

export const getMustahikDetail = async (id: number) => {
  const response = await api.get(`/admin/mustahik/${id}`);
  return response.data;
};

export const getMustahik = async () => {
  const response = await api.get('/mustahik');
  return response.data;
};

export const getCampaigns = async () => {
  const response = await api.get('/admin/campaigns');
  return response.data;
};

export const createMustahik = async (data: Record<string, unknown>) => {
  const response = await api.post('/admin/mustahik/store', data);
  return response.data;
};

export const updateMustahik = async (
  id: number,
  data: Record<string, unknown>
) => {
  const response = await api.put(`/admin/mustahik/${id}`, data);
  return response.data;
};

export const deleteMustahik = async (id: number) => {
  const response = await api.delete(`/admin/mustahik/${id}`);
  return response.data;
};


// ===============================
// REALISASI
// ===============================

export const getRealisasi = async () => {
  const response = await api.get('/realisasi');
  return response.data;
};

export const getRealisasiDetail = async (id: number) => {
  const response = await api.get(`/realisasi/${id}`);
  return response.data;
};

export const createRealisasi = async (
  data: FormData | Record<string, unknown>
) => {
  const response = await api.post('/admin/realisasi/store', data);
  return response.data;
};

export const updateRealisasi = async (
  id: number,
  data: FormData | Record<string, unknown>
) => {
  if (data instanceof FormData) {
    const payload = new FormData();

    data.forEach((value, key) => {
      payload.append(key, value);
    });

    payload.append('_method', 'PUT');

    const response = await api.post(
      `/admin/realisasi/${id}`,
      payload
    );

    return response.data;
  }

  const response = await api.put(`/admin/realisasi/${id}`, data);
  return response.data;
};

export const deleteRealisasi = async (id: number) => {
  const response = await api.delete(`/admin/realisasi/${id}`);
  return response.data;
};


// ===============================
// OPERASIONAL
// ===============================

export const getOperasional = async (page = 1) => {
  try {
    const response = await api.get('/admin/operasional', {
      params: { page },
    });

    console.log('RESPONS OPERASIONAL:', response.data);

    return response.data;
  } catch (error: any) {
    console.error('ERROR GET OPERASIONAL:', {
      message: error.message,
      status: error.response?.status,
      data: error.response?.data,
      url: error.config?.url,
    });

    throw error;
  }
};

export const getKategoriOperasional = async () => {
  const response = await api.get('/admin/kategori-operasional');
  return response.data;
};

export const getRekeningKas = async () => {
  const response = await api.get('/admin/rekening-kas');
  return response.data;
};

export const getOperasionalDetail = async (id: number) => {
  const response = await api.get(`/admin/operasional/${id}`);
  return response.data;
};

export const createOperasional = async (
  data: FormData | Record<string, unknown>
) => {
  const response = await api.post(
    '/admin/operasional/store',
    data
  );

  return response.data;
};

export const updateOperasional = async (
  id: number,
  data: FormData | Record<string, unknown>
) => {
  if (data instanceof FormData) {
    const payload = new FormData();

    data.forEach((value, key) => {
      payload.append(key, value);
    });

    payload.append('_method', 'PUT');

    const response = await api.post(
      `/admin/operasional/${id}`,
      payload
    );

    return response.data;
  }

  const response = await api.put(
    `/admin/operasional/${id}`,
    data
  );

  return response.data;
};

export const deleteOperasional = async (id: number) => {
  const response = await api.delete(`/admin/operasional/${id}`);
  return response.data;
};


// ===============================
// CAMPAIGN ADMIN
// ===============================


// ===============================
// CAMPAIGN ADMIN
// ===============================

export const createCampaign = async (
  data: FormData
) => {
  const response = await api.post(
    '/admin/campaigns/store',
    data
  );

  return response.data;
};

export const updateCampaign = async (
  id: number,
  data: FormData
) => {
  const payload = new FormData();

  data.forEach((value, key) => {
    if (key !== '_method') {
      payload.append(key, value);
    }
  });

  payload.append('_method', 'PUT');

  const response = await api.post(
    `/admin/campaigns/${id}`,
    payload
  );

  return response.data;
};

export const deleteCampaign = async (id: number) => {
  const response = await api.delete(
    `/admin/campaigns/${id}`
  );

  return response.data;
};







// ===============================
// PROFIL YAYASAN
// ===============================

export const updateProfilYayasan = async (
  id: number,
  data: Record<string, unknown>
) => {
  const response = await api.put(
    `/admin/yayasan/profil/${id}`,
    data
  );

  return response.data;
};