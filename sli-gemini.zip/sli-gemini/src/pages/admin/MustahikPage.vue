
<template>
  <ion-page>
    <!-- HEADER -->
    <ion-header>
      <ion-toolbar class="green-toolbar">
        <ion-buttons slot="start">
          <ion-back-button default-href="/admin/dashboard" />
        </ion-buttons>

        <ion-title>Kelola Mustahik</ion-title>

        <ion-buttons slot="end">
          <ion-button :disabled="loading" @click="loadMustahik">
            <ion-icon :icon="refreshOutline" :class="{ spinning: loading }" />
          </ion-button>
        </ion-buttons>
      </ion-toolbar>
    </ion-header>

    <ion-content class="mustahik-content ion-padding">
      <div class="page-heading">
        <div>
          <h1>Data Mustahik</h1>
          <p>Kelola data penerima manfaat zakat dan bantuan</p>
        </div>

        <ion-button class="add-button" @click="bukaTambah">
          <ion-icon :icon="addOutline" slot="start" />
          Tambah Mustahik
        </ion-button>
      </div>

      <!-- RINGKASAN -->
      <div class="summary-grid">
        <div class="summary-card">
          <div class="summary-icon total-icon">
            <ion-icon :icon="peopleOutline" />
          </div>
          <div>
            <span>Total Mustahik</span>
            <h3>{{ totalData }}</h3>
          </div>
        </div>

        <div class="summary-card">
          <div class="summary-icon fakir-icon">
            <ion-icon :icon="heartOutline" />
          </div>
          <div>
            <span>Data di Halaman Ini</span>
            <h3>{{ mustahikList.length }}</h3>
          </div>
        </div>
      </div>

      <!-- DAFTAR MUSTAHIK -->
      <div class="content-card">
        <div class="table-heading">
          <div>
            <h2>Daftar Mustahik</h2>
            <p>Data mustahik yang terdaftar dalam sistem</p>
          </div>
        </div>

        <!-- FILTER DAN PENCARIAN -->
        <div class="filter-panel">
          <ion-searchbar
            v-model="search"
            placeholder="Cari nama, NIK, alamat, atau HP..."
            class="custom-search"
            :debounce="150"
            animated
          />

          <select
            v-model="filterKategori"
            class="category-filter"
            aria-label="Filter kategori asnaf"
          >
            <option value="Semua">Semua Asnaf</option>
            <option value="Fakir">Fakir</option>
            <option value="Miskin">Miskin</option>
            <option value="Amil">Amil</option>
            <option value="Muallaf">Muallaf</option>
            <option value="Riqab">Riqab</option>
            <option value="Gharim">Gharim</option>
            <option value="Fisabilillah">Fisabilillah</option>
            <option value="Ibnu Sabil">Ibnu Sabil</option>
          </select>

          <ion-button fill="outline" class="reset-button" @click="resetFilter">
            Reset
          </ion-button>
        </div>

        <!-- LOADING -->
        <div v-if="loading" class="loading-area">
          <ion-spinner name="crescent" color="success" />
          <p>Memuat data mustahik...</p>
        </div>

        <!-- TABEL -->
        <div v-else class="table-container">
          <table class="mustahik-table">
            <thead>
              <tr>
                <th class="col-no">No.</th>
                <th class="col-name">Nama</th>
                <th class="col-address">Alamat</th>
                <th class="col-phone">No. HP</th>
                <th class="col-asnaf">Kategori Asnaf</th>
                <th class="col-action">Aksi</th>
              </tr>
            </thead>

            <tbody>
              <tr v-for="(item, index) in filteredMustahik" :key="item.id">
                <td class="col-no">
                  {{ (currentPage - 1) * perPage + index + 1 }}
                </td>

                <td>
                  <div class="name-cell">
                    <strong>{{ item.nama || '-' }}</strong>
                    <small>NIK: {{ item.nik || '-' }}</small>
                  </div>
                </td>

                <td class="address-cell">{{ item.alamat || '-' }}</td>
                <td class="phone-cell">{{ item.no_telp || '-' }}</td>

                <td>
                  <span class="asnaf-badge">
                    {{ item.kategori_asnaf || '-' }}
                  </span>
                </td>

                <td class="col-action">
                  <div class="action-buttons">
                    <ion-button
                      fill="clear"
                      class="edit-button"
                      @click="bukaEdit(item)"
                      title="Edit"
                    >
                      <ion-icon :icon="createOutline" />
                    </ion-button>

                    <ion-button
                      fill="clear"
                      class="delete-button"
                      @click="konfirmasiHapus(item)"
                      title="Hapus"
                    >
                      <ion-icon :icon="trashOutline" />
                    </ion-button>
                  </div>
                </td>
              </tr>

              <tr v-if="filteredMustahik.length === 0">
                <td colspan="6" class="empty-state">
                  <ion-icon :icon="documentTextOutline" />
                  <strong>Data tidak ditemukan</strong>
                  <span>Silakan ubah kata kunci atau filter pencarian.</span>
                </td>
              </tr>
            </tbody>
          </table>
        </div>

        <!-- PAGINATION -->
        <div class="pagination-area">
          <div class="pagination-info">
            Menampilkan
            <strong>{{ startData }}</strong>
            -
            <strong>{{ endData }}</strong>
            dari
            <strong>{{ totalData }}</strong>
            data
          </div>

          <div class="pagination-controls">
            <ion-button
              fill="outline"
              class="page-button"
              :disabled="currentPage <= 1 || loading"
              @click="changePage(currentPage - 1)"
            >
              <ion-icon :icon="chevronBackOutline" />
            </ion-button>

            <ion-button
              v-for="page in visiblePages"
              :key="page"
              fill="outline"
              class="page-number-button"
              :class="{ 'active-page': page === currentPage }"
              :disabled="loading"
              @click="changePage(page)"
            >
              {{ page }}
            </ion-button>

            <ion-button
              fill="outline"
              class="page-button"
              :disabled="currentPage >= totalPages || loading"
              @click="changePage(currentPage + 1)"
            >
              <ion-icon :icon="chevronForwardOutline" />
            </ion-button>
          </div>
        </div>
      </div>

      <!-- MODAL TAMBAH DAN EDIT -->
      <ion-modal
        :is-open="modalOpen"
        @didDismiss="tutupModal"
        class="mustahik-modal"
        :backdrop-dismiss="!loading"
      >
        <ion-header>
          <ion-toolbar class="green-toolbar">
            <ion-title>
              {{ editId ? 'Edit Mustahik' : 'Tambah Mustahik' }}
            </ion-title>

            <ion-buttons slot="end">
              <ion-button
                fill="clear"
                class="modal-close-button"
                @click="tutupModal"
                :disabled="loading"
                aria-label="Tutup modal"
              >
                <ion-icon :icon="closeOutline" />
              </ion-button>
            </ion-buttons>
          </ion-toolbar>
        </ion-header>

        <ion-content class="modal-content ion-padding">
          <div class="modal-inner">
            <div class="modal-heading">
              <h2>
                {{ editId ? 'Perbarui Data Mustahik' : 'Formulir Mustahik Baru' }}
              </h2>
              <p>
                {{
                  editId
                    ? 'Silakan perbarui informasi mustahik.'
                    : 'Lengkapi informasi berikut untuk mendaftarkan mustahik.'
                }}
              </p>
            </div>

            <form @submit.prevent="simpan">
              <div class="form-grid">
                <!-- NAMA: HANYA HURUF DAN SPASI -->
                <ion-item class="custom-input" lines="none">
                  <ion-label position="stacked">
                    Nama Lengkap <span>*</span>
                  </ion-label>
                  <ion-input
                    :value="form.nama"
                    type="text"
                    placeholder="Masukkan nama lengkap"
                    required
                    @ionInput="handleNameInput"
                  />
                </ion-item>

                <!-- NIK: HANYA ANGKA -->
                <ion-item class="custom-input" lines="none">
                  <ion-label position="stacked">
                    NIK <span>*</span>
                  </ion-label>
                  <ion-input
                    :value="form.nik"
                    type="text"
                    inputmode="numeric"
                    placeholder="Masukkan NIK"
                    required
                    @ionInput="handleNikInput"
                  />
                </ion-item>

                <!-- DROPDOWN KATEGORI ASNAF -->
                <div class="asnaf-form-field">
                  <label class="asnaf-form-label" for="kategori-asnaf">
                    Kategori Asnaf <span>*</span>
                  </label>

                  <select
                    id="kategori-asnaf"
                    v-model="form.kategori_asnaf"
                    class="category-filter form-category-filter"
                    required
                  >
                    <option value="" disabled>Pilih kategori</option>
                    <option value="Fakir">Fakir</option>
                    <option value="Miskin">Miskin</option>
                    <option value="Amil">Amil</option>
                    <option value="Muallaf">Muallaf</option>
                    <option value="Riqab">Riqab</option>
                    <option value="Gharim">Gharim</option>
                    <option value="Fisabilillah">Fisabilillah</option>
                    <option value="Ibnu Sabil">Ibnu Sabil</option>
                  </select>
                </div>

                <!-- NOMOR HP: HANYA ANGKA -->
                <ion-item class="custom-input" lines="none">
                  <ion-label position="stacked">Nomor Telepon</ion-label>
                  <ion-input
                    :value="form.no_telp"
                    type="tel"
                    inputmode="numeric"
                    placeholder="Masukkan nomor telepon"
                    @ionInput="handlePhoneInput"
                  />
                </ion-item>
              </div>

              <ion-item class="custom-input textarea-input" lines="none">
                <ion-label position="stacked">
                  Alamat Lengkap <span>*</span>
                </ion-label>
                <ion-textarea
                  v-model="form.alamat"
                  placeholder="Masukkan alamat lengkap"
                  :auto-grow="true"
                  required
                />
              </ion-item>

              <ion-item class="custom-input textarea-input" lines="none">
                <ion-label position="stacked">Keterangan</ion-label>
                <ion-textarea
                  v-model="form.keterangan"
                  placeholder="Tambahkan keterangan jika diperlukan"
                  :auto-grow="true"
                />
              </ion-item>

              <div class="modal-actions">
                <ion-button type="submit" class="save-button" :disabled="loading">
                  {{
                    loading
                      ? 'Menyimpan...'
                      : editId
                        ? 'Update Mustahik'
                        : 'Simpan Mustahik'
                  }}
                </ion-button>
              </div>
            </form>
          </div>
        </ion-content>
      </ion-modal>

      <!-- KONFIRMASI HAPUS -->
      <ion-alert
        :is-open="deleteAlertOpen"
        header="Hapus Mustahik"
        :message="`Apakah Anda yakin ingin menghapus data ${selectedMustahik?.nama || 'ini'}?`"
        :buttons="deleteAlertButtons"
        @didDismiss="deleteAlertOpen = false"
      />

      <!-- TOAST -->
      <ion-toast
        :is-open="toastOpen"
        :message="toastMessage"
        :color="toastColor"
        :duration="2800"
        position="top"
        @didDismiss="toastOpen = false"
      />
    </ion-content>
  </ion-page>
</template>

<script setup lang="ts">
import { ref, reactive, computed, onMounted } from 'vue';

import {
  IonPage,
  IonHeader,
  IonToolbar,
  IonTitle,
  IonContent,
  IonButton,
  IonIcon,
  IonSearchbar,
  IonSpinner,
  IonModal,
  IonButtons,
  IonBackButton,
  IonItem,
  IonLabel,
  IonInput,
  IonTextarea,
  IonToast,
  IonAlert
} from '@ionic/vue';

import {
  addOutline,
  peopleOutline,
  heartOutline,
  refreshOutline,
  createOutline,
  trashOutline,
  documentTextOutline,
  chevronBackOutline,
  chevronForwardOutline,
  closeOutline
} from 'ionicons/icons';

import api from '@/services/api';

import {
  createMustahik,
  updateMustahik,
  deleteMustahik
} from '@/services/adminService';

import type { Mustahik } from '@/interfaces/Mustahik';

const mustahikList = ref<Mustahik[]>([]);

const loading = ref(false);
const modalOpen = ref(false);

const currentPage = ref(1);
const totalPages = ref(1);
const totalData = ref(0);
const perPage = ref(10);

const search = ref('');
const filterKategori = ref('Semua');

const editId = ref<number | null>(null);

const toastOpen = ref(false);
const toastMessage = ref('');
const toastColor = ref<'success' | 'danger'>('success');

const deleteAlertOpen = ref(false);
const selectedMustahik = ref<Mustahik | null>(null);

const form = reactive({
  nama: '',
  nik: '',
  kategori_asnaf: 'Fakir',
  alamat: '',
  no_telp: '',
  keterangan: ''
});

// EKSTRAK DATA PAGINATION LARAVEL
function extractMustahikData(response: any) {
  const root = response?.data;
  const paginator = root?.data;

  if (Array.isArray(paginator?.data)) {
    return {
      items: paginator.data,
      total: Number(paginator.total ?? paginator.data.length),
      currentPage: Number(paginator.current_page ?? 1),
      lastPage: Number(paginator.last_page ?? 1),
      perPage: Number(paginator.per_page ?? 10)
    };
  }

  if (Array.isArray(paginator)) {
    return {
      items: paginator,
      total: paginator.length,
      currentPage: 1,
      lastPage: 1,
      perPage: paginator.length || 10
    };
  }

  return {
    items: [],
    total: 0,
    currentPage: 1,
    lastPage: 1,
    perPage: 10
  };
}

// NOTIFIKASI
function showToast(
  message: string,
  color: 'success' | 'danger' = 'success'
) {
  toastMessage.value = message;
  toastColor.value = color;
  toastOpen.value = false;

  setTimeout(() => {
    toastOpen.value = true;
  }, 50);
}

// AMBIL DATA MUSTAHIK
async function loadMustahik() {
  loading.value = true;

  try {
    const response = await api.get('/mustahik', {
      params: {
        page: currentPage.value
      }
    });

    const result = extractMustahikData(response);

    mustahikList.value = result.items;
    totalData.value = result.total;
    totalPages.value = result.lastPage;
    currentPage.value = result.currentPage;
    perPage.value = result.perPage;

  } catch (err: any) {
    console.error('ERROR MUSTAHIK:', err);
    console.error('DETAIL ERROR:', err.response?.data);

    mustahikList.value = [];
    totalData.value = 0;
    totalPages.value = 1;

    showToast(
      err.response?.data?.message || 'Gagal mengambil data mustahik.',
      'danger'
    );
  } finally {
    loading.value = false;
  }
}

// FILTER DATA PADA HALAMAN AKTIF
const filteredMustahik = computed(() => {
  const keyword = search.value.toLowerCase().trim();

  return mustahikList.value.filter((item) => {
    const nama = (item.nama || '').toLowerCase();
    const nik = (item.nik || '').toLowerCase();
    const alamat = (item.alamat || '').toLowerCase();
    const telepon = (item.no_telp || '').toLowerCase();

    const matchSearch =
      nama.includes(keyword) ||
      nik.includes(keyword) ||
      alamat.includes(keyword) ||
      telepon.includes(keyword);

    const matchKategori =
      filterKategori.value === 'Semua' ||
      (item.kategori_asnaf || '').toLowerCase() ===
        filterKategori.value.toLowerCase();

    return matchSearch && matchKategori;
  });
});

// INFORMASI RENTANG DATA
const startData = computed(() => {
  if (mustahikList.value.length === 0) return 0;

  return (currentPage.value - 1) * perPage.value + 1;
});

const endData = computed(() => {
  if (mustahikList.value.length === 0) return 0;

  return Math.min(
    (currentPage.value - 1) * perPage.value + mustahikList.value.length,
    totalData.value
  );
});

// NOMOR HALAMAN YANG DITAMPILKAN
const visiblePages = computed(() => {
  const pages: number[] = [];

  const start = Math.max(1, currentPage.value - 2);
  const end = Math.min(totalPages.value, start + 4);
  const adjustedStart = Math.max(1, end - 4);

  for (let page = adjustedStart; page <= end; page++) {
    pages.push(page);
  }

  return pages;
});

// RESET FILTER
function resetFilter() {
  search.value = '';
  filterKategori.value = 'Semua';
}

// PAGINATION
async function changePage(page: number) {
  if (page < 1 || page > totalPages.value || loading.value) return;

  currentPage.value = page;
  await loadMustahik();
}

// ==================================================
// VALIDASI INPUT LANGSUNG PADA KOMPONEN IONIC
// ==================================================

// NAMA: HANYA HURUF DAN SPASI
function handleNameInput(event: CustomEvent) {
  const input = event.target as HTMLIonInputElement;
  const rawValue = String(input.value ?? '');

  const cleanValue = rawValue.replace(/[^a-zA-ZÀ-ÿ\s]/g, '');

  input.value = cleanValue;
  form.nama = cleanValue;
}

// NIK: HANYA ANGKA 0-9
function handleNikInput(event: CustomEvent) {
  const input = event.target as HTMLIonInputElement;
  const rawValue = String(input.value ?? '');

  const cleanValue = rawValue.replace(/[^0-9]/g, '');

  input.value = cleanValue;
  form.nik = cleanValue;
}

// NOMOR HP: HANYA ANGKA 0-9
function handlePhoneInput(event: CustomEvent) {
  const input = event.target as HTMLIonInputElement;
  const rawValue = String(input.value ?? '');

  const cleanValue = rawValue.replace(/[^0-9]/g, '');

  input.value = cleanValue;
  form.no_telp = cleanValue;
}

// RESET FORM
function resetForm() {
  editId.value = null;

  form.nama = '';
  form.nik = '';
  form.kategori_asnaf = 'Fakir';
  form.alamat = '';
  form.no_telp = '';
  form.keterangan = '';
}

// BUKA MODAL TAMBAH
function bukaTambah() {
  resetForm();
  modalOpen.value = true;
}

// BUKA MODAL EDIT
function bukaEdit(item: Mustahik) {
  editId.value = item.id;

  form.nama = item.nama || '';
  form.nik = item.nik || '';
  form.kategori_asnaf = item.kategori_asnaf || 'Fakir';
  form.alamat = item.alamat || '';
  form.no_telp = (item.no_telp || '').replace(/[^0-9]/g, '');
  form.keterangan = item.keterangan || '';

  modalOpen.value = true;
}

// TUTUP MODAL
function tutupModal() {
  if (loading.value) return;

  modalOpen.value = false;
  resetForm();
}

// SIMPAN TAMBAH / EDIT
async function simpan() {
  if (
    !form.nama.trim() ||
    !form.nik.trim() ||
    !form.alamat.trim()
  ) {
    showToast('Nama, NIK, dan alamat wajib diisi.', 'danger');
    return;
  }

  // VALIDASI NAMA
  if (!/^[a-zA-ZÀ-ÿ\s]+$/.test(form.nama.trim())) {
    showToast('Nama hanya boleh berisi huruf dan spasi.', 'danger');
    return;
  }

  // VALIDASI NIK
  if (!/^[0-9]+$/.test(form.nik)) {
    showToast('NIK hanya boleh berisi angka 0-9.', 'danger');
    return;
  }

  // VALIDASI NOMOR HP
  if (form.no_telp && !/^[0-9]+$/.test(form.no_telp)) {
    showToast('Nomor HP hanya boleh berisi angka 0-9.', 'danger');
    return;
  }

  if (!form.kategori_asnaf) {
    showToast('Kategori Asnaf wajib dipilih.', 'danger');
    return;
  }

  const isEdit = editId.value !== null;
  const id = editId.value;

  loading.value = true;

  try {
    const payload = {
      ...form,
      nama: form.nama.trim(),
      nik: form.nik.trim(),
      alamat: form.alamat.trim(),
      no_telp: form.no_telp.replace(/[^0-9]/g, '')
    };

    if (isEdit && id !== null) {
      await updateMustahik(id, payload);
      showToast('Data mustahik berhasil diperbarui.');
    } else {
      await createMustahik(payload);
      showToast('Data mustahik berhasil ditambahkan.');
    }

    modalOpen.value = false;
    resetForm();

    if (!isEdit) {
      currentPage.value = 1;
    }

    await loadMustahik();

  } catch (err: any) {
    console.error('ERROR SIMPAN MUSTAHIK:', err);
    console.error('DETAIL ERROR:', err.response?.data);

    showToast(
      err.response?.data?.message || 'Gagal menyimpan data mustahik.',
      'danger'
    );
  } finally {
    loading.value = false;
  }
}

// KONFIRMASI HAPUS
function konfirmasiHapus(item: Mustahik) {
  selectedMustahik.value = item;
  deleteAlertOpen.value = true;
}

const deleteAlertButtons = [
  {
    text: 'Batal',
    role: 'cancel',
    handler: () => {
      deleteAlertOpen.value = false;
    }
  },
  {
    text: 'Hapus',
    role: 'destructive',
    handler: () => {
      hapusMustahik();
    }
  }
];

// HAPUS DATA
async function hapusMustahik() {
  if (!selectedMustahik.value) return;

  const id = selectedMustahik.value.id;

  loading.value = true;

  try {
    await deleteMustahik(id);

    deleteAlertOpen.value = false;
    showToast('Data mustahik berhasil dihapus.');

    if (mustahikList.value.length === 1 && currentPage.value > 1) {
      currentPage.value--;
    }

    await loadMustahik();

  } catch (err: any) {
    console.error('ERROR HAPUS MUSTAHIK:', err);

    showToast(
      err.response?.data?.message || 'Gagal menghapus data mustahik.',
      'danger'
    );
  } finally {
    loading.value = false;
    selectedMustahik.value = null;
  }
}

onMounted(() => {
  loadMustahik();
});
</script>

<style scoped>
/* DASAR HALAMAN */
ion-content.mustahik-content {
  --background: #f5f8f6;
  --padding-bottom: 30px;
}

/* HEADER */
.green-toolbar {
  --background: #16834a;
  --color: #ffffff;
  --border-color: transparent;
}

.green-toolbar ion-title {
  color: #ffffff;
  font-weight: 700;
}

.green-toolbar ion-back-button,
.green-toolbar ion-button {
  --color: #ffffff;
}

/* ANIMASI REFRESH */
.spinning {
  animation: spin 1s linear infinite;
}

@keyframes spin {
  to {
    transform: rotate(360deg);
  }
}

.page-heading {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 14px;
  margin: 8px 0 20px;
}

.page-heading h1 {
  margin: 0 0 6px;
  color: #174c30;
  font-size: 23px;
  font-weight: 750;
}

.page-heading p {
  margin: 0;
  color: #718579;
  font-size: 13px;
}

.add-button {
  --background: #16834a;
  --background-hover: #116b3b;
  --border-radius: 9px;
  --box-shadow: none;
  font-size: 12px;
  font-weight: 650;
  text-transform: none;
  white-space: nowrap;
}

/* RINGKASAN */
.summary-grid {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 14px;
  margin-bottom: 18px;
}

.summary-card {
  display: flex;
  align-items: center;
  gap: 13px;
  padding: 17px;
  background: #ffffff;
  border: 1px solid #e5eee8;
  border-radius: 13px;
  box-shadow: 0 3px 12px rgba(27, 74, 46, 0.035);
}

.summary-icon {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 42px;
  height: 42px;
  border-radius: 12px;
  font-size: 21px;
}

.total-icon {
  background: #e0f2e6;
  color: #16834a;
}

.fakir-icon {
  background: #fff3dc;
  color: #bd8425;
}

.summary-card span {
  color: #78877e;
  font-size: 11px;
}

.summary-card h3 {
  margin: 4px 0 0;
  color: #244b35;
  font-size: 22px;
  font-weight: 750;
}

/* KONTEN TABEL */
.content-card {
  padding: 20px;
  background: #ffffff;
  border: 1px solid #e5eee8;
  border-radius: 15px;
  box-shadow: 0 3px 12px rgba(27, 74, 46, 0.045);
}

.table-heading {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  margin-bottom: 17px;
}

.table-heading h2 {
  margin: 0 0 5px;
  color: #244b35;
  font-size: 17px;
  font-weight: 700;
}

.table-heading p {
  margin: 0;
  color: #819087;
  font-size: 12px;
}

/* FILTER DAN PENCARIAN */
.filter-panel {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 12px;
  margin-bottom: 17px;
  border: 1px solid #e0ebe3;
  border-radius: 12px;
  background: #f5f9f6;
  min-width: 0;
}

.custom-search {
  flex: 1;
  min-width: 0;
  width: 100%;
  padding: 0;
  --background: #ffffff;
  --color: #244b35;
  --placeholder-color: #829188;
  --icon-color: #16834a;
  --border-radius: 10px;
  border: 1px solid #dce9df;
  border-radius: 10px;
}

/* DROPDOWN FILTER DAN FORM */
.category-filter {
  flex: 0 0 180px;
  width: 180px;
  height: 42px;
  min-height: 42px;
  min-width: 0;
  border: 1px solid #e3ebe5;
  border-radius: 10px;
  background: #ffffff;
  color: #52675a;
  padding: 0 12px;
  font-family: inherit;
  font-size: 12px;
  box-sizing: border-box;
  outline: none;
  cursor: pointer;
  transition: border-color 0.2s ease;
}

.category-filter:focus {
  border-color: #16834a;
}

/* DROPDOWN KATEGORI DI FORM */
.asnaf-form-field {
  display: flex;
  flex-direction: column;
  align-items: stretch;
  gap: 7px;
  min-width: 0;
  margin-bottom: 12px;
  padding: 12px;
  background: #ffffff;
  border: 1px solid #dce9df;
  border-radius: 10px;
  box-sizing: border-box;
}

.asnaf-form-label {
  display: block;
  color: #486b55;
  font-size: 12px;
  font-weight: 650;
}

.asnaf-form-label span {
  color: #dc3545;
}

.form-category-filter {
  flex: none;
  width: 100%;
  height: 42px;
  min-height: 42px;
  font-size: 13px;
}

.reset-button {
  --color: #16834a;
  --border-color: #b8d9c3;
  --border-radius: 9px;
  height: 42px;
  margin: 0;
  font-size: 11px;
  text-transform: none;
}

.loading-area {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  min-height: 190px;
  gap: 12px;
  color: #718579;
  font-size: 12px;
}

/* TABEL */
.table-container {
  width: 100%;
  overflow-x: auto;
  border: 1px solid #e7eee9;
  border-radius: 10px;
  scrollbar-width: none;
  -ms-overflow-style: none;
}

.table-container::-webkit-scrollbar {
  display: none;
}

.mustahik-table {
  width: 100%;
  border-collapse: collapse;
  table-layout: fixed;
}

.mustahik-table thead {
  background: #eff7f1;
}

.mustahik-table th {
  padding: 13px 10px;
  color: #42634d;
  font-size: 11px;
  font-weight: 750;
  text-align: left;
  white-space: nowrap;
}

.mustahik-table td {
  padding: 13px 10px;
  color: #52645a;
  font-size: 12px;
  border-top: 1px solid #edf1ee;
  overflow-wrap: anywhere;
  vertical-align: middle;
}

.mustahik-table tbody tr:hover {
  background: #f8fbf9;
}

.col-no {
  width: 48px;
  text-align: center !important;
}

.col-name {
  width: 21%;
}

.col-address {
  width: 25%;
}

.col-phone {
  width: 15%;
}

.col-asnaf {
  width: 16%;
}

.col-action {
  width: 90px;
  text-align: center !important;
}

.name-cell {
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.name-cell strong {
  color: #244b35;
  font-size: 12px;
  font-weight: 650;
}

.name-cell small {
  color: #89978e;
  font-size: 10px;
  font-variant-numeric: tabular-nums;
}

.address-cell {
  line-height: 1.5;
}

.phone-cell {
  font-variant-numeric: tabular-nums;
  white-space: nowrap;
}

.asnaf-badge {
  display: inline-flex;
  padding: 5px 10px;
  border-radius: 20px;
  background: #e8f4eb;
  color: #267345;
  font-size: 10px;
  font-weight: 650;
  white-space: nowrap;
}

.action-buttons {
  display: flex;
  justify-content: center;
  gap: 2px;
}

.action-buttons ion-button {
  --padding-start: 5px;
  --padding-end: 5px;
  margin: 0;
  height: 34px;
  font-size: 17px;
}

.edit-button {
  --color: #16834a;
}

.delete-button {
  --color: #dc3545;
}

.empty-state {
  height: 170px;
  text-align: center !important;
  color: #84938a !important;
}

.empty-state ion-icon {
  display: block;
  margin: 0 auto 8px;
  font-size: 27px;
  color: #a5b6aa;
}

.empty-state strong,
.empty-state span {
  display: block;
}

.empty-state strong {
  color: #52645a;
  margin-bottom: 5px;
}

.empty-state span {
  font-size: 11px;
}

/* PAGINATION */
.pagination-area {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  padding-top: 17px;
}

.pagination-info {
  color: #819087;
  font-size: 11px;
}

.pagination-info strong {
  color: #42634d;
}

.pagination-controls {
  display: flex;
  align-items: center;
  gap: 5px;
}

.page-button,
.page-number-button {
  --color: #16834a;
  --border-color: #c9dfcf;
  --border-radius: 8px;
  min-width: 34px;
  height: 34px;
  margin: 0;
  font-size: 11px;
}

.active-page {
  --background: #16834a;
  --color: #ffffff;
  --border-color: #16834a;
}

/* MODAL DESKTOP */
.mustahik-modal {
  --width: 650px;
  --max-width: 95%;
  --height: auto;
  --max-height: 90%;
  --border-radius: 16px;
  --background: #f5f8f6;
}

.modal-content {
  --background: #f5f8f6;
  --padding-bottom: 25px;
}

.modal-inner {
  width: 100%;
  max-width: 620px;
  margin: 0 auto;
}

.modal-close-button {
  --color: #ffffff;
  font-size: 23px;
}

.modal-heading {
  margin: 5px 0 20px;
}

.modal-heading h2 {
  margin: 0 0 6px;
  color: #174c30;
  font-size: 20px;
  font-weight: 750;
}

.modal-heading p {
  margin: 0;
  color: #819087;
  font-size: 12px;
  line-height: 1.5;
}

.form-grid {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 0 13px;
}

/* INPUT FORM */
.custom-input {
  --background: #ffffff;
  --color: #244b35;
  --padding-start: 12px;
  --inner-padding-end: 12px;
  --min-height: 68px;

  margin-bottom: 12px;
  border: 1px solid #dce9df;
  border-radius: 10px;
}

.custom-input ion-label {
  color: #486b55 !important;
  font-size: 12px !important;
  font-weight: 650 !important;
  margin-bottom: 7px !important;
}

.custom-input ion-label span {
  color: #dc3545;
}

.custom-input ion-input,
.custom-input ion-textarea {
  --color: #244b35;
  font-size: 13px;
}

.textarea-input {
  --min-height: 85px;
}

.modal-actions {
  display: flex;
  gap: 10px;
  margin: 18px 0 8px;
}

.modal-actions ion-button {
  --border-radius: 9px;
  --box-shadow: none;
  min-height: 45px;
  width: 100%;
  margin: 0;
  font-size: 13px;
  font-weight: 650;
  text-transform: none;
}

.save-button {
  --background: #16834a;
}

/* RESPONSIVE MOBILE */
@media (max-width: 650px) {
  .mustahik-content {
    --padding-start: 12px;
    --padding-end: 12px;
  }

  .page-heading {
    align-items: flex-start;
    flex-direction: column;
  }

  .page-heading h1 {
    font-size: 21px;
  }

  .add-button {
    width: 100%;
    margin: 0;
  }

  .summary-grid {
    gap: 9px;
  }

  .summary-card {
    padding: 12px;
    gap: 8px;
  }

  .summary-icon {
    width: 34px;
    height: 34px;
    font-size: 17px;
  }

  .summary-card span {
    font-size: 10px;
  }

  .summary-card h3 {
    font-size: 19px;
  }

  .content-card {
    padding: 12px;
  }

  .table-heading {
    align-items: flex-start;
  }

  /* FILTER MOBILE */
  .filter-panel {
    display: flex;
    flex-direction: column;
    align-items: stretch;
    gap: 10px;
    padding: 12px;
    background: #f5f9f6;
    border: 1px solid #e0ebe3;
    border-radius: 12px;
  }

  .custom-search {
    flex: none;
    width: 100%;
    min-width: 0;
    height: 44px;
  }

  .category-filter {
    flex: none;
    width: 100%;
    max-width: 100%;
    min-width: 0;
    height: 42px;
    min-height: 42px;
    margin: 0;
    font-size: 12px;
  }

  .form-category-filter {
    height: 46px;
    min-height: 46px;
    font-size: 14px;
  }

  .asnaf-form-field {
    margin-bottom: 10px;
  }

  .reset-button {
    width: 100%;
    height: 42px;
    margin: 0;
  }

  /* TABEL MOBILE */
  .table-container {
    overflow-x: auto;
  }

  .mustahik-table {
    table-layout: fixed;
    min-width: 0;
  }

  .mustahik-table th {
    padding: 10px 4px;
    font-size: 9px;
    white-space: normal;
  }

  .mustahik-table td {
    padding: 10px 4px;
    font-size: 9px;
  }

  .col-no {
    width: 28px;
  }

  .col-name {
    width: 24%;
  }

  .col-address {
    width: 23%;
  }

  .col-phone {
    width: 16%;
  }

  .col-asnaf {
    width: 18%;
  }

  .col-action {
    width: 68px;
  }

  .name-cell {
    gap: 3px;
  }

  .name-cell strong {
    font-size: 9px;
    line-height: 1.4;
  }

  .name-cell small {
    font-size: 8px;
    overflow-wrap: anywhere;
  }

  .address-cell {
    line-height: 1.4;
  }

  .phone-cell {
    white-space: normal;
    overflow-wrap: anywhere;
  }

  .asnaf-badge {
    padding: 4px 5px;
    font-size: 8px;
    white-space: normal;
    line-height: 1.3;
  }

  .action-buttons {
    gap: 0;
  }

  .action-buttons ion-button {
    --padding-start: 2px;
    --padding-end: 2px;
    height: 30px;
    font-size: 15px;
  }

  /* PAGINATION MOBILE */
  .pagination-area {
    align-items: flex-start;
    flex-direction: column;
    gap: 12px;
  }

  .pagination-controls {
    align-self: flex-end;
    gap: 4px;
    max-width: 100%;
  }

  .pagination-info {
    font-size: 10px;
  }

  .page-button,
  .page-number-button {
    min-width: 30px;
    height: 32px;
    font-size: 10px;
  }

  /* MODAL MOBILE FULL SCREEN */
  .mustahik-modal {
    --width: 100%;
    --max-width: 100%;
    --height: 100%;
    --max-height: 100%;
    --border-radius: 0;
  }

  .modal-content {
    --padding-start: 16px;
    --padding-end: 16px;
    --padding-top: 10px;
    --padding-bottom: 30px;
  }

  .modal-inner {
    max-width: 100%;
  }

  .modal-heading {
    margin: 5px 0 17px;
  }

  .modal-heading h2 {
    font-size: 18px;
  }

  .modal-heading p {
    font-size: 12px;
  }

  .form-grid {
    grid-template-columns: 1fr;
    gap: 0;
  }

  .custom-input {
    --min-height: 66px;
    margin-bottom: 10px;
  }

  .textarea-input {
    --min-height: 80px;
  }

  .modal-actions {
    margin-top: 20px;
    padding-bottom: 10px;
  }

  .modal-actions ion-button {
    min-height: 48px;
    font-size: 13px;
  }
}

/* SCROLLBAR TIDAK TERLIHAT */
ion-content::part(scroll) {
  scrollbar-width: none;
  -ms-overflow-style: none;
}

ion-content::part(scroll)::-webkit-scrollbar {
  display: none;
  width: 0;
  height: 0;
}
</style>
