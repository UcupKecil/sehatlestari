<template>
  <ion-page>
    <ion-header>
      <ion-toolbar class="green-toolbar">
        <ion-buttons slot="start">
          <ion-back-button default-href="/admin/dashboard" />
        </ion-buttons>
        <ion-title>Kelola Realisasi</ion-title>
        <ion-buttons slot="end">
          <ion-button :disabled="loading" @click="loadData">
            <ion-icon :icon="refreshOutline" />
          </ion-button>
        </ion-buttons>
      </ion-toolbar>
    </ion-header>

    <ion-content :fullscreen="true" class="realisasi-content">

      <main class="page-container">
        <section class="page-heading">
          <div class="eyebrow">
            <ion-icon :icon="walletOutline" />
            PENGELOLAAN DANA
          </div>

          <h1>{{ isCampaignMode ? 'Realisasi Campaign' : 'Data Realisasi' }}</h1>

          <p>
            {{ isCampaignMode
              ? `Kelola laporan penyaluran dana untuk ${currentCampaignName}.`
              : 'Kelola laporan penyaluran dana dan dokumentasi kegiatan.' }}
          </p>

          <div class="date-label">
            <ion-icon :icon="calendarOutline" />
            {{ isCampaignMode ? currentCampaignName : today }}
          </div>
        </section>

        <!-- STATISTIK -->
        <section class="stats-grid">
          <div class="stat-card">
            <div class="stat-icon report-icon">
              <ion-icon :icon="documentTextOutline" />
            </div>
            <div class="stat-info">
              <span>Total Laporan</span>
              <strong>{{ campaignData.length }}</strong>
              <small>Data realisasi</small>
            </div>
          </div>

          <div class="stat-card">
            <div class="stat-icon money-icon">
              <ion-icon :icon="walletOutline" />
            </div>
            <div class="stat-info">
              <span>Total Dana Disalurkan</span>
              <strong>{{ formatRupiah(totalDisalurkan) }}</strong>
              <small>Akumulasi realisasi</small>
            </div>
          </div>
        </section>

        <!-- TABEL -->
        <section class="table-section">
          <div class="section-heading">
            <div>
              <h2>Daftar Realisasi</h2>
              <p>
                {{ isCampaignMode
                  ? `Laporan ${currentCampaignName}`
                  : 'Data laporan penggunaan dan penyaluran dana' }}
              </p>
            </div>

            <ion-button class="add-button" @click="bukaTambah">
              <ion-icon slot="start" :icon="addOutline" />
              Tambah Realisasi
            </ion-button>
          </div>

          <div class="filter-area">
  <div class="search-box">
    <ion-icon :icon="searchOutline" />

    <input
      v-model="searchQuery"
      type="text"
      placeholder="Cari judul laporan, campaign, atau mustahik..."
    />

    <button
      v-if="searchQuery"
      type="button"
      class="clear-search"
      @click="searchQuery = ''"
      aria-label="Hapus pencarian"
    >
      <ion-icon :icon="closeOutline" />
    </button>
  </div>

  <div class="filter-actions">
    <select v-model="filterTanggal" class="sort-select">
      <option value="">Semua Tanggal</option>
      <option value="terbaru">Tanggal Terbaru</option>
      <option value="terlama">Tanggal Terlama</option>
    </select>

    <button
  type="button"
  class="reset-button"
  @click="resetFilter"
>
  <ion-icon :icon="refreshOutline" />
  Reset
</button>
  </div>
</div>

          <div v-if="loading && campaignData.length === 0" class="state-box">
            <ion-spinner name="crescent" />
            <p>Memuat data realisasi...</p>
          </div>

          <div
            v-else-if="error && dataList.length === 0"
            class="state-box error-state"
          >
            <ion-icon :icon="alertCircleOutline" />
            <p>{{ error }}</p>
            <ion-button fill="outline" @click="loadData">Coba Lagi</ion-button>
          </div>

          <div v-else class="table-wrapper">
            <table class="realisasi-table">
              <thead>
                <tr>
                  <th>No.</th>
                  <th>Judul Laporan</th>
                  <th>Campaign</th>
                  <th>Mustahik</th>
                  <th>Tanggal</th>
                  <th>Jumlah Keluar</th>
                  <th>Aksi</th>
                </tr>
              </thead>

              <tbody>
                <tr v-for="(item, index) in paginatedData" :key="item.id">
                  <td>{{ (currentPage - 1) * perPage + index + 1 }}</td>

                  <td>
                    <div class="report-title">
                      <strong>{{ item.judul_laporan || 'Laporan Realisasi' }}</strong>
                      <small>ID: {{ item.id }}</small>
                    </div>
                  </td>

                  <td>
                    <span class="campaign-name">
                      {{ item.campaign?.judul || getCampaignName(item.campaign_kegiatan_id) }}
                    </span>
                  </td>

                  <td>{{ item.mustahik?.nama || '-' }}</td>
                  <td>{{ formatDate(item.tanggal_realisasi) }}</td>
                  <td class="amount-cell">{{ formatRupiah(item.jumlah_keluar) }}</td>

                  <td>
                    <div class="action-buttons">
                      <ion-button
                        fill="clear"
                        size="small"
                        class="edit-button"
                        @click="pilihEdit(item.id)"
                      >
                        <ion-icon slot="icon-only" :icon="createOutline" />
                      </ion-button>

                      <ion-button
                        fill="clear"
                        size="small"
                        class="delete-button"
                        @click="konfirmasiHapus(item)"
                      >
                        <ion-icon slot="icon-only" :icon="trashOutline" />
                      </ion-button>
                    </div>
                  </td>
                </tr>

                <tr v-if="paginatedData.length === 0">
                  <td colspan="7" class="empty-cell">
                    <ion-icon :icon="documentTextOutline" />
                    <strong>Data tidak ditemukan</strong>
                    <span>Belum ada laporan yang sesuai pencarian.</span>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>

          <div v-if="filteredData.length > 0" class="pagination-wrapper">
            <span>
              Menampilkan {{ startData }}–{{ endData }}
              dari {{ filteredData.length }} data
            </span>

            <div class="pagination-buttons">
              <button
                class="page-arrow"
                :disabled="currentPage <= 1"
                @click="currentPage--"
              >‹</button>

              <button
                v-for="page in visiblePages"
                :key="page"
                class="page-number"
                :class="{ active: currentPage === page }"
                @click="currentPage = page"
              >{{ page }}</button>

              <button
                class="page-arrow"
                :disabled="currentPage >= totalPages"
                @click="currentPage++"
              >›</button>
            </div>
          </div>
        </section>
      </main>

      <!-- MODAL FORM -->
      <ion-modal
        :is-open="modalOpen"
        class="realisasi-modal"
        :backdrop-dismiss="!loading"
        @didDismiss="tutupModal"
      >
        <div class="modal-container">
          <div class="modal-header">
            <div>
              <span class="modal-eyebrow">PENGELOLAAN DANA</span>
              <h2>{{ editId ? 'Edit Realisasi' : 'Tambah Realisasi' }}</h2>
              <p>Lengkapi informasi laporan penyaluran dana.</p>
            </div>

            <button class="close-button" :disabled="loading" @click="tutupModal">
              <ion-icon :icon="closeOutline" />
            </button>
          </div>

          <div class="modal-body">
            <div v-if="error" class="form-alert error-alert">
              <ion-icon :icon="alertCircleOutline" />
              {{ error }}
            </div>

            <div class="form-grid">

              <!-- CAMPAIGN -->
              <div class="form-group">
                <label>Campaign <span>*</span></label>

                <ion-input
                  v-if="isCampaignMode"
                  :model-value="currentCampaignName"
                  fill="outline"
                  readonly
                  disabled
                />

                <select
                  v-else
                  v-model.number="form.campaign_kegiatan_id"
                  class="form-select"
                >
                  <option :value="0" disabled>Pilih campaign</option>
                  <option
                    v-for="campaign in campaignList"
                    :key="campaign.id"
                    :value="Number(campaign.id)"
                  >
                    {{ campaign.judul }}
                  </option>
                </select>
              </div>

              <!-- MUSTAHIK -->
              <div class="form-group">
                <label>Mustahik <span>*</span></label>

                <select
                  v-model.number="form.mustahik_id"
                  class="form-select"
                >
                  <option :value="0" disabled>Pilih mustahik</option>
                  <option
                    v-for="mustahik in mustahikList"
                    :key="mustahik.id"
                    :value="Number(mustahik.id)"
                  >
                    {{ mustahik.nama }}
                    {{ mustahik.nik ? ` — ${mustahik.nik}` : '' }}
                  </option>
                </select>

                <small v-if="mustahikList.length === 0" class="field-hint">
                  Data mustahik belum tersedia.
                </small>
              </div>

              <!-- JUDUL -->
              <div class="form-group full-width">
                <label>Judul Laporan <span>*</span></label>
                <ion-input
                  v-model="form.judul_laporan"
                  type="text"
                  placeholder="Contoh: Penyaluran bantuan pendidikan"
                  fill="outline"
                />
              </div>

              <!-- NOMINAL -->
              <div class="form-group">
                <label>Jumlah Dana Keluar <span>*</span></label>
                <div class="currency-input">
                  <span>Rp</span>
                  <input
                    :value="currencyDisplay"
                    type="text"
                    inputmode="numeric"
                    placeholder="0"
                    @input="handleCurrencyInput"
                  />
                </div>
                <small class="field-hint">
                  Masukkan nominal dalam Rupiah.
                </small>
              </div>

              <!-- TANGGAL -->
              <div class="form-group">
                <label>Tanggal Realisasi <span>*</span></label>

                <button class="date-input" @click="dateModalOpen = true">
                  <ion-icon :icon="calendarOutline" />
                  <span :class="{ placeholder: !form.tanggal_realisasi }">
                    {{ formattedSelectedDate || 'Pilih tanggal realisasi' }}
                  </span>
                  <ion-icon :icon="chevronDownOutline" />
                </button>
              </div>

              <!-- EDITOR QUILL -->
              <div class="form-group full-width">
                <label>Rincian Kegiatan</label>

                <div class="editor-wrapper">
                  <QuillEditor
                    v-model:content="form.rincian_kegiatan"
                    content-type="html"
                    theme="snow"
                    :toolbar="[
                      [{ header: [1, 2, 3, false] }],
                      ['bold', 'italic', 'underline'],
                      [{ list: 'ordered' }, { list: 'bullet' }],
                      [{ align: [] }],
                      ['clean']
                    ]"
                    placeholder="Tuliskan rincian kegiatan realisasi..."
                  />
                </div>
              </div>

              <!-- BUKTI PENCAIRAN -->
              <div class="form-group full-width">
                <label>Bukti Pencairan</label>

                <div
                  class="upload-box"
                  :class="{ dragging: dragBukti }"
                  @dragover.prevent="dragBukti = true"
                  @dragleave.prevent="dragBukti = false"
                  @drop.prevent="handleDrop($event, 'bukti')"
                  @click="buktiInput?.click()"
                >
                  <input
                    ref="buktiInput"
                    type="file"
                    accept="image/*"
                    hidden
                    @change="handleFileSelect($event, 'bukti')"
                  />

                  <template v-if="buktiPreview">
                    <img :src="buktiPreview" class="image-preview" alt="Preview bukti pencairan" />
                    <div class="preview-info">
                      <strong>{{ buktiFile?.name || 'Bukti pencairan sebelumnya' }}</strong>
                      <span>Gambar siap digunakan</span>
                    </div>
                    <button
                      class="remove-file"
                      type="button"
                      @click.stop="removeFile('bukti')"
                    >
                      <ion-icon :icon="trashOutline" />
                    </button>
                  </template>

                  <template v-else>
                    <ion-icon :icon="cloudUploadOutline" class="upload-icon" />
                    <strong>Upload Bukti Pencairan</strong>
                    <span>Drag and drop gambar di sini atau klik untuk memilih</span>
                    <small>Format JPG, PNG, WEBP</small>
                  </template>
                </div>
              </div>

              <!-- FOTO KEGIATAN -->
              <div class="form-group full-width">
                <label>Foto Kegiatan</label>

                <div
                  class="upload-box"
                  :class="{ dragging: dragFoto }"
                  @dragover.prevent="dragFoto = true"
                  @dragleave.prevent="dragFoto = false"
                  @drop.prevent="handleDrop($event, 'foto')"
                  @click="fotoInput?.click()"
                >
                  <input
                    ref="fotoInput"
                    type="file"
                    accept="image/*"
                    hidden
                    @change="handleFileSelect($event, 'foto')"
                  />

                  <template v-if="fotoPreview">
                    <img :src="fotoPreview" class="image-preview" alt="Preview foto kegiatan" />
                    <div class="preview-info">
                      <strong>{{ fotoFile?.name || 'Foto kegiatan sebelumnya' }}</strong>
                      <span>Gambar siap digunakan</span>
                    </div>
                    <button
                      class="remove-file"
                      type="button"
                      @click.stop="removeFile('foto')"
                    >
                      <ion-icon :icon="trashOutline" />
                    </button>
                  </template>

                  <template v-else>
                    <ion-icon :icon="cloudUploadOutline" class="upload-icon" />
                    <strong>Upload Foto Kegiatan</strong>
                    <span>Drag and drop gambar di sini atau klik untuk memilih</span>
                    <small>Format JPG, PNG, WEBP</small>
                  </template>
                </div>
              </div>
            </div>

            <div class="modal-footer">
              <ion-button
                class="save-button"
                expand="block"
                :disabled="loading"
                @click="simpan"
              >
                <ion-spinner v-if="loading" name="crescent" />
                <template v-else>
                  <ion-icon slot="start" :icon="saveOutline" />
                  {{ editId ? 'Simpan Perubahan' : 'Simpan Realisasi' }}
                </template>
              </ion-button>
            </div>
          </div>
        </div>
      </ion-modal>

      <!-- POPUP KALENDER -->
      <ion-modal
        :is-open="dateModalOpen"
        class="date-modal"
        :backdrop-dismiss="true"
        @didDismiss="dateModalOpen = false"
      >
        <div class="date-modal-container">
          <div class="date-modal-header">
            <strong>Pilih Tanggal Realisasi</strong>
            <button @click="dateModalOpen = false">
              <ion-icon :icon="closeOutline" />
            </button>
          </div>

          <ion-datetime
            presentation="date"
            locale="id-ID"
            :first-day-of-week="1"
            :value="form.tanggal_realisasi || undefined"
            @ionChange="handleDateChange"
          />

          <ion-button expand="block" class="date-done-button" @click="dateModalOpen = false">
            Selesai
          </ion-button>
        </div>
      </ion-modal>
            <!-- ALERT HAPUS -->
      <ion-alert
        :is-open="alertHapusOpen"
        header="Hapus Realisasi"
        :message="`Yakin ingin menghapus laporan '${selectedItem?.judul_laporan || 'Realisasi'}'?`"
        :buttons="alertButtons"
        @didDismiss="alertHapusOpen = false"
      />

    </ion-content>
  </ion-page>
</template>

<script setup lang="ts">
import { computed, onMounted, onUnmounted, reactive, ref, watch } from 'vue';
import { useRoute } from 'vue-router';

import {
  IonPage, IonHeader, IonToolbar, IonButtons, IonBackButton, IonTitle,
  IonContent, IonButton, IonSpinner, IonInput, IonIcon,
  IonModal, IonAlert, IonDatetime
} from '@ionic/vue';

import { QuillEditor } from '@vueup/vue-quill';
import '@vueup/vue-quill/dist/vue-quill.snow.css';

import {
  addOutline, alertCircleOutline, calendarOutline, cloudUploadOutline,
  closeOutline, chevronDownOutline, createOutline, documentTextOutline,
  refreshOutline, saveOutline, searchOutline, trashOutline,
  walletOutline
} from 'ionicons/icons';

import {
  getRealisasi,
  getRealisasiDetail,
  createRealisasi,
  updateRealisasi,
  deleteRealisasi,
  getCampaigns,
  getMustahik
} from '../../services/adminService';

const route = useRoute();

const campaignId = computed(() => {
  const id = Number(route.params.campaignId);
  return Number.isInteger(id) && id > 0 ? id : null;
});

const isCampaignMode = computed(() => campaignId.value !== null);

const dataList = ref<any[]>([]);
const campaignList = ref<any[]>([]);
const mustahikList = ref<any[]>([]);

const loading = ref(false);
const error = ref('');
const modalOpen = ref(false);
const dateModalOpen = ref(false);
const alertHapusOpen = ref(false);
const selectedItem = ref<any>(null);
const editId = ref<number | null>(null);

const searchQuery = ref('');
const filterTanggal = ref('');
const currentPage = ref(1);
const perPage = 10;

const currencyDisplay = ref('');
const buktiFile = ref<File | null>(null);
const fotoFile = ref<File | null>(null);
const buktiPreview = ref('');
const fotoPreview = ref('');
const originalBuktiUrl = ref('');
const originalFotoUrl = ref('');

const buktiInput = ref<HTMLInputElement | null>(null);
const fotoInput = ref<HTMLInputElement | null>(null);

const dragBukti = ref(false);
const dragFoto = ref(false);

const form = reactive({
  campaign_kegiatan_id: 0,
  mustahik_id: 0,
  judul_laporan: '',
  jumlah_keluar: 0,
  tanggal_realisasi: '',
  rincian_kegiatan: '',
  bukti_pencairan: '',
  foto_kegiatan: ''
});

const today = computed(() => new Intl.DateTimeFormat('id-ID', {
  weekday: 'long',
  day: 'numeric',
  month: 'long',
  year: 'numeric'
}).format(new Date()));

function extractList(result: any): any[] {
  const data = result?.data ?? result;

  if (Array.isArray(data)) return data;
  if (Array.isArray(data?.data)) return data.data;
  if (Array.isArray(data?.campaigns)) return data.campaigns;
  if (Array.isArray(data?.mustahik)) return data.mustahik;
  if (Array.isArray(data?.realisasi)) return data.realisasi;

  return [];
}

function getCampaignName(id: number | string | null): string {
  if (!id) return '-';

  const campaign = campaignList.value.find(
    item => Number(item.id) === Number(id)
  );

  return campaign?.judul || `Campaign #${id}`;
}

const currentCampaignName = computed(() => {
  if (!campaignId.value) return '';

  const campaign = campaignList.value.find(
    item => Number(item.id) === campaignId.value
  );

  if (campaign?.judul) return campaign.judul;

  const realisasi = dataList.value.find(
    item => Number(item.campaign_kegiatan_id) === campaignId.value
  );

  return realisasi?.campaign?.judul || `Campaign #${campaignId.value}`;
});

const campaignData = computed(() => {
  if (!isCampaignMode.value) return dataList.value;

  return dataList.value.filter(
    item => Number(item.campaign_kegiatan_id) === campaignId.value
  );
});

const totalDisalurkan = computed(() => campaignData.value.reduce(
  (total, item) => total + Number(item.jumlah_keluar || 0),
  0
));

async function loadData() {
  loading.value = true;
  error.value = '';

  try {
    const results = await Promise.allSettled([
      getRealisasi(),
      getCampaigns(),
      getMustahik()
    ]);

    if (results[0].status === 'fulfilled') {
      dataList.value = extractList(results[0].value);
    } else {
      throw results[0].reason;
    }

    if (results[1].status === 'fulfilled') {
      campaignList.value = extractList(results[1].value);
    }

    if (results[2].status === 'fulfilled') {
      mustahikList.value = extractList(results[2].value);
    }
  } catch (err: any) {
    error.value = err?.response?.data?.message ||
      'Gagal memuat data realisasi.';
  } finally {
    loading.value = false;
  }
}

function formatRupiah(value: any): string {
  const nominal = Number(value || 0);

  // Format miliaran
  if (nominal >= 1000000000) {
    const miliar = nominal / 1000000000;

    return `Rp${new Intl.NumberFormat('id-ID', {
      maximumFractionDigits: 1
    }).format(miliar)} M`;
  }

  // Format jutaan
  if (nominal >= 1000000) {
    const juta = nominal / 1000000;

    return `Rp${new Intl.NumberFormat('id-ID', {
      maximumFractionDigits: 1
    }).format(juta)} Jt`;
  }

  // Format ribuan
  if (nominal >= 1000) {
    const ribu = nominal / 1000;

    return `Rp${new Intl.NumberFormat('id-ID', {
      maximumFractionDigits: 1
    }).format(ribu)} Rb`;
  }

  // Format nominal di bawah seribu
  return new Intl.NumberFormat('id-ID', {
    style: 'currency',
    currency: 'IDR',
    maximumFractionDigits: 0
  }).format(nominal);
}

function formatDate(value: any): string {
  if (!value) return '-';

  const date = new Date(`${String(value).slice(0, 10)}T00:00:00`);

  if (Number.isNaN(date.getTime())) return String(value);

  return new Intl.DateTimeFormat('id-ID', {
    day: '2-digit',
    month: 'short',
    year: '2-digit'
  }).format(date);
}

const formattedSelectedDate = computed(() => {
  if (!form.tanggal_realisasi) return '';

  const date = new Date(`${form.tanggal_realisasi}T00:00:00`);

  return new Intl.DateTimeFormat('id-ID', {
    day: 'numeric',
    month: 'long',
    year: 'numeric'
  }).format(date);
});

function handleDateChange(event: CustomEvent) {
  const value = event.detail.value;
  if (typeof value === 'string') {
    form.tanggal_realisasi = value.slice(0, 10);
  }
}

function handleCurrencyInput(event: Event) {
  const target = event.target as HTMLInputElement;
  const digits = target.value.replace(/\D/g, '');

  form.jumlah_keluar = Number(digits || 0);
  currencyDisplay.value = digits
    ? new Intl.NumberFormat('id-ID').format(Number(digits))
    : '';

  target.value = currencyDisplay.value;
}

const filteredData = computed(() => {
  let result = [...campaignData.value];
  const keyword = searchQuery.value.trim().toLowerCase();

  if (keyword) {
    result = result.filter(item => {
      const campaignName = item.campaign?.judul ||
        getCampaignName(item.campaign_kegiatan_id);

      const mustahikName = item.mustahik?.nama || '';

      return (
        String(item.judul_laporan || '').toLowerCase().includes(keyword) ||
        String(campaignName).toLowerCase().includes(keyword) ||
        String(mustahikName).toLowerCase().includes(keyword)
      );
    });
  }

  if (filterTanggal.value === 'terbaru') {
    result.sort((a, b) =>
      new Date(b.tanggal_realisasi || 0).getTime() -
      new Date(a.tanggal_realisasi || 0).getTime()
    );
  } else if (filterTanggal.value === 'terlama') {
    result.sort((a, b) =>
      new Date(a.tanggal_realisasi || 0).getTime() -
      new Date(b.tanggal_realisasi || 0).getTime()
    );
  }

  return result;
});

const totalPages = computed(() =>
  Math.max(1, Math.ceil(filteredData.value.length / perPage))
);

const paginatedData = computed(() => {
  const start = (currentPage.value - 1) * perPage;
  return filteredData.value.slice(start, start + perPage);
});

const startData = computed(() =>
  filteredData.value.length ? (currentPage.value - 1) * perPage + 1 : 0
);

const endData = computed(() =>
  Math.min(currentPage.value * perPage, filteredData.value.length)
);

const visiblePages = computed(() => {
  const end = Math.min(totalPages.value, currentPage.value + 2);
  const start = Math.max(1, end - 4);
  const pages: number[] = [];

  for (let page = start; page <= end; page++) pages.push(page);
  return pages;
});

watch([searchQuery, filterTanggal], () => {
  currentPage.value = 1;
});

watch(totalPages, value => {
  if (currentPage.value > value) currentPage.value = value;
});

watch(campaignId, id => {
  if (modalOpen.value && editId.value === null) {
    form.campaign_kegiatan_id = id || 0;
  }
  currentPage.value = 1;
});

function resetFilter() {
  searchQuery.value = '';
  filterTanggal.value = '';
  currentPage.value = 1;
}

function clearPreview() {
  if (buktiPreview.value.startsWith('blob:')) {
    URL.revokeObjectURL(buktiPreview.value);
  }

  if (fotoPreview.value.startsWith('blob:')) {
    URL.revokeObjectURL(fotoPreview.value);
  }

  buktiPreview.value = '';
  fotoPreview.value = '';
  buktiFile.value = null;
  fotoFile.value = null;
  originalBuktiUrl.value = '';
  originalFotoUrl.value = '';
}

function resetForm() {
  editId.value = null;
  clearPreview();

  Object.assign(form, {
    campaign_kegiatan_id: campaignId.value || 0,
    mustahik_id: 0,
    judul_laporan: '',
    jumlah_keluar: 0,
    tanggal_realisasi: '',
    rincian_kegiatan: '',
    bukti_pencairan: '',
    foto_kegiatan: ''
  });

  currencyDisplay.value = '';
  error.value = '';
}

function bukaTambah() {
  resetForm();

  if (isCampaignMode.value) {
    form.campaign_kegiatan_id = Number(campaignId.value);
  }

  modalOpen.value = true;
}

function tutupModal() {
  if (loading.value) return;

  modalOpen.value = false;
  dateModalOpen.value = false;
  resetForm();
}

function resolveImageUrl(path: string | null): string {
  if (!path) return '';

  // Jika sudah berupa URL lengkap
  if (path.startsWith('http://') || path.startsWith('https://')) {
    return path;
  }

  // Bersihkan garis miring di awal path
  const cleanPath = path.replace(/^\/+/, '');

  // Bentuk URL gambar dari server Laravel
  return `https://sehatlestariindonesia.vps-m.com/storage/${cleanPath}`;
}

function setExistingImage(kind: 'bukti' | 'foto', path: string) {
  const url = resolveImageUrl(path);

  if (kind === 'bukti') {
    originalBuktiUrl.value = path;
    buktiPreview.value = url;
  } else {
    originalFotoUrl.value = path;
    fotoPreview.value = url;
  }
}

function validateImage(file: File): boolean {
  if (!file.type.startsWith('image/')) {
    error.value = 'File harus berupa gambar.';
    return false;
  }

  const maxSize = 5 * 1024 * 1024;

  if (file.size > maxSize) {
    error.value = 'Ukuran gambar maksimal 5 MB.';
    return false;
  }

  return true;
}

function setImage(file: File, kind: 'bukti' | 'foto') {
  error.value = '';

  if (!validateImage(file)) return;

  const preview = URL.createObjectURL(file);

  if (kind === 'bukti') {
    if (buktiPreview.value.startsWith('blob:')) {
      URL.revokeObjectURL(buktiPreview.value);
    }

    buktiFile.value = file;
    buktiPreview.value = preview;
  } else {
    if (fotoPreview.value.startsWith('blob:')) {
      URL.revokeObjectURL(fotoPreview.value);
    }

    fotoFile.value = file;
    fotoPreview.value = preview;
  }
}

function handleFileSelect(event: Event, kind: 'bukti' | 'foto') {
  const input = event.target as HTMLInputElement;
  const file = input.files?.[0];

  if (file) setImage(file, kind);

  input.value = '';
}

function handleDrop(event: DragEvent, kind: 'bukti' | 'foto') {
  dragBukti.value = false;
  dragFoto.value = false;

  const file = event.dataTransfer?.files?.[0];
  if (file) setImage(file, kind);
}

function removeFile(kind: 'bukti' | 'foto') {
  if (kind === 'bukti') {
    if (buktiPreview.value.startsWith('blob:')) {
      URL.revokeObjectURL(buktiPreview.value);
    }

    buktiFile.value = null;
    buktiPreview.value = '';
    originalBuktiUrl.value = '';
    form.bukti_pencairan = '';
  } else {
    if (fotoPreview.value.startsWith('blob:')) {
      URL.revokeObjectURL(fotoPreview.value);
    }
        fotoFile.value = null;
    fotoPreview.value = '';
    originalFotoUrl.value = '';
    form.foto_kegiatan = '';
  }
}

function isiForm(item: any) {
  Object.assign(form, {
    campaign_kegiatan_id: isCampaignMode.value
      ? Number(campaignId.value)
      : Number(item?.campaign_kegiatan_id || 0),

    mustahik_id: Number(item?.mustahik_id || 0),
    judul_laporan: item?.judul_laporan || '',
    jumlah_keluar: Number(item?.jumlah_keluar || 0),
    tanggal_realisasi: item?.tanggal_realisasi
      ? String(item.tanggal_realisasi).slice(0, 10)
      : '',
    rincian_kegiatan: item?.rincian_kegiatan || '',
    bukti_pencairan: item?.bukti_pencairan || '',
    foto_kegiatan: item?.foto_kegiatan || ''
  });

  currencyDisplay.value = form.jumlah_keluar
    ? new Intl.NumberFormat('id-ID').format(form.jumlah_keluar)
    : '';

  if (item?.bukti_pencairan) {
    setExistingImage('bukti', item.bukti_pencairan);
  }

  if (item?.foto_kegiatan) {
    setExistingImage('foto', item.foto_kegiatan);
  }
}

async function pilihEdit(id: number) {
  loading.value = true;
  error.value = '';

  try {
    const result = await getRealisasiDetail(id);
    const item = result?.data ?? result?.realisasi ?? result;

    resetForm();
    editId.value = id;
    isiForm(item);
    modalOpen.value = true;
  } catch (err: any) {
    error.value = err?.response?.data?.message ||
      'Gagal mengambil detail realisasi.';
  } finally {
    loading.value = false;
  }
}

function validasiForm(): boolean {
  if (!form.campaign_kegiatan_id) {
    error.value = 'Campaign wajib dipilih.';
    return false;
  }

  if (!form.mustahik_id) {
    error.value = 'Mustahik wajib dipilih.';
    return false;
  }

  if (!form.judul_laporan.trim()) {
    error.value = 'Judul laporan wajib diisi.';
    return false;
  }

  if (!form.jumlah_keluar || form.jumlah_keluar < 1) {
    error.value = 'Jumlah dana keluar harus lebih dari 0.';
    return false;
  }

  if (!form.tanggal_realisasi) {
    error.value = 'Tanggal realisasi wajib dipilih.';
    return false;
  }

  return true;
}

function buildFormData(): FormData {
  const payload = new FormData();

  payload.append(
    'campaign_kegiatan_id',
    String(isCampaignMode.value ? campaignId.value : form.campaign_kegiatan_id)
  );

  payload.append('mustahik_id', String(form.mustahik_id));
  payload.append('judul_laporan', form.judul_laporan.trim());
  payload.append('jumlah_keluar', String(form.jumlah_keluar));
  payload.append('tanggal_realisasi', form.tanggal_realisasi);
  payload.append('rincian_kegiatan', form.rincian_kegiatan || '');

  if (buktiFile.value) {
    payload.append('bukti_pencairan', buktiFile.value);
  }

  if (fotoFile.value) {
    payload.append('foto_kegiatan', fotoFile.value);
  }

  return payload;
}

async function simpan() {
  error.value = '';

  if (isCampaignMode.value) {
    form.campaign_kegiatan_id = Number(campaignId.value);
  }

  if (!validasiForm()) return;

  loading.value = true;

  try {
    const payload = buildFormData();

    if (editId.value !== null) {
      await updateRealisasi(editId.value, payload);
    } else {
      await createRealisasi(payload);
    }

    modalOpen.value = false;
    resetForm();

    await loadData();
  } catch (err: any) {
    const validationErrors = err?.response?.data?.errors;

    if (validationErrors) {
      error.value = Object.values(validationErrors).flat().join(' ');
    } else {
      error.value = err?.response?.data?.message ||
        'Gagal menyimpan data realisasi.';
    }
  } finally {
    loading.value = false;
  }
}

function konfirmasiHapus(item: any) {
  selectedItem.value = item;
  alertHapusOpen.value = true;
}

const alertButtons = [
  { text: 'Batal', role: 'cancel' },
  {
    text: 'Hapus',
    role: 'destructive',
    handler: () => {
      if (selectedItem.value) hapusData(selectedItem.value.id);
    }
  }
];

async function hapusData(id: number) {
  loading.value = true;
  error.value = '';

  try {
    await deleteRealisasi(id);
    alertHapusOpen.value = false;
    selectedItem.value = null;
    await loadData();
  } catch (err: any) {
    error.value = err?.response?.data?.message ||
      'Gagal menghapus data realisasi.';
  } finally {
    loading.value = false;
  }
}


watch(modalOpen, open => {
  if (!open) dateModalOpen.value = false;
});

onMounted(loadData);

onUnmounted(() => {
  clearPreview();
});
</script>

<style>
/* QUILL EDITOR */
.ql-toolbar.ql-snow {
  border: 1px solid #dfe9e2 !important;
  border-radius: 9px 9px 0 0;
  background: #f8fbf9;
}

.ql-container.ql-snow {
  border: 1px solid #dfe9e2 !important;
  border-top: 0 !important;
  border-radius: 0 0 9px 9px;
  min-height: 150px;
  color: #244b35;
  font-size: 13px;
}

.ql-editor {
  min-height: 150px;
}
</style>

<style scoped>
.realisasi-content {
  --background: #f5f8f6;
  color: #244b35;
}

.green-toolbar {
  --background: #16834a;
  --color: #ffffff;
  --border-color: transparent;
}

.green-toolbar ion-title {
  color: #ffffff;
  font-weight: 700;
}

.green-toolbar ion-back-button,
.green-toolbar ion-button {
  --color: #ffffff;
}

.page-container {
  max-width: 1250px;
  margin: 0 auto;
  padding: 28px 5% 32px;
}

.page-heading {
  margin-bottom: 25px;
}

.eyebrow {
  color: #16834a;
  font-size: 11px;
  font-weight: 800;
  letter-spacing: 1.3px;
  display: flex;
  align-items: center;
  gap: 6px;
}

.page-heading h1 {
  margin: 9px 0 7px;
  color: #204a32;
  font-size: 28px;
  font-weight: 800;
}

.page-heading p {
  color: #78877e;
  font-size: 13px;
  margin: 0;
  line-height: 1.6;
}

.date-label {
  display: inline-flex;
  align-items: center;
  gap: 7px;
  margin-top: 13px;
  padding: 7px 11px;
  border-radius: 8px;
  background: #e8f5ec;
  color: #16834a;
  font-size: 11px;
  font-weight: 600;
}

.stats-grid {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 16px;
  margin-bottom: 25px;
}

.stat-card {
  background: #ffffff;
  border: 1px solid #e7eee9;
  border-radius: 13px;
  padding: 19px;
  display: flex;
  align-items: center;
  gap: 14px;
}

.stat-icon {
  width: 47px;
  height: 47px;
  flex-shrink: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 12px;
  font-size: 23px;
}

.report-icon {
  background: #e8f2ff;
  color: #3478bd;
}

.money-icon {
  background: #e7f5ec;
  color: #16834a;
}

.stat-info span,
.stat-info small {
  display: block;
  color: #829188;
  font-size: 11px;
}

.stat-info strong {
  display: block;
  color: #244b35;
  font-size: 20px;
  margin: 4px 0;
  overflow-wrap: anywhere;
}

.table-section {
  background: #ffffff;
  border: 1px solid #e7eee9;
  border-radius: 14px;
  padding: 22px;
  box-shadow: 0 3px 15px rgba(32, 74, 50, 0.035);
}

.section-heading {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 15px;
  margin-bottom: 20px;
}

.section-heading h2 {
  color: #244b35;
  font-size: 18px;
  margin: 0 0 5px;
}

.section-heading p {
  color: #829188;
  font-size: 12px;
  margin: 0;
}

.add-button,
.save-button {
  --background: #16834a;
  --border-radius: 9px;
  --box-shadow: none;
  font-size: 12px;
  text-transform: none;
}

/* =====================================
   FILTER DAN PENCARIAN
   MENGIKUTI TAMPILAN OPERASIONAL
===================================== */

/* =====================================
   FILTER DAN PENCARIAN
   SAMA DENGAN OPERASIONAL PAGE
===================================== */

.filter-area {
  display: flex;
  align-items: center;
  gap: 10px;
  margin: 20px 0;
}

.search-box {
  flex: 1;
  min-width: 180px;
  height: 42px;
  display: flex;
  align-items: center;
  gap: 10px;
  border: 1px solid #e3ebe5;
  border-radius: 10px;
  padding: 0 13px;
  background: #fff;
  color: #829187;
  transition: border-color 0.2s, box-shadow 0.2s;
  box-sizing: border-box;
}

.search-box:focus-within {
  border-color: #16834a;
  box-shadow: 0 0 0 3px rgba(22, 131, 74, 0.08);
}

.search-box > ion-icon {
  flex-shrink: 0;
  font-size: 18px;
  color: #829187;
}

.search-box input {
  flex: 1;
  min-width: 0;
  height: 100%;
  border: 0;
  outline: none;
  color: #244b35;
  background: transparent;
  font-family: inherit;
  font-size: 13px;
}

.search-box input::placeholder {
  color: #a6b1aa;
}

.clear-search {
  width: 25px;
  height: 25px;
  flex-shrink: 0;
  border: 0;
  border-radius: 6px;
  background: #f0f5f1;
  color: #819087;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
}

.clear-search ion-icon {
  font-size: 15px;
}

.sort-select {
  height: 42px;
  border: 1px solid #e3ebe5;
  border-radius: 10px;
  background: #fff;
  color: #52675a;
  padding: 0 12px;
  font-family: inherit;
  font-size: 12px;
  box-sizing: border-box;
  outline: none;
}

.sort-select:focus {
  border-color: #16834a;
}

.reset-button {
  height: 42px;
  padding: 0 13px;
  margin: 0;
  border: 1px solid #e3ebe5;
  border-radius: 10px;
  background: #ffffff;
  color: #61766a;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
  font-family: inherit;
  font-size: 12px;
  font-weight: 500;
  text-transform: none;
  box-sizing: border-box;
  cursor: pointer;
}

.filter-actions {
  display: flex;
  align-items: center;
  gap: 10px;
}
/* =====================================
   TABEL
===================================== */

.table-wrapper {
  width: 100%;
  max-width: 100%;
  overflow-x: hidden;
  border: 1px solid #e8eee9;
  border-radius: 9px;
}

.realisasi-table {
  width: 100%;
  min-width: 0;
  table-layout: fixed;
  border-collapse: collapse;
  text-align: left;
}

.realisasi-table th:nth-child(1),
.realisasi-table td:nth-child(1) {
  width: 5%;
  text-align: center;
}

.realisasi-table th:nth-child(2),
.realisasi-table td:nth-child(2) {
  width: 24%;
}

.realisasi-table th:nth-child(3),
.realisasi-table td:nth-child(3) {
  width: 18%;
}

.realisasi-table th:nth-child(4),
.realisasi-table td:nth-child(4) {
  width: 18%;
}

.realisasi-table th:nth-child(5),
.realisasi-table td:nth-child(5) {
  width: 12%;
  text-align: center;
}

.realisasi-table th:nth-child(6),
.realisasi-table td:nth-child(6) {
  width: 13%;
  text-align: right;
}

.realisasi-table th:nth-child(7),
.realisasi-table td:nth-child(7) {
  width: 10%;
  text-align: center;
}

.realisasi-table th {
  background: #f2f7f3;
  color: #557261;
  font-size: 11px;
  padding: 12px 8px;
  line-height: 1.4;
  border-bottom: 1px solid #e5ede7;
  overflow-wrap: anywhere;
  vertical-align: middle;
}

.realisasi-table td {
  padding: 12px 8px;
  color: #52675a;
  font-size: 12px;
  line-height: 1.5;
  border-bottom: 1px solid #edf1ee;
  vertical-align: middle;
  overflow-wrap: anywhere;
  box-sizing: border-box;
}

.realisasi-table tbody tr:last-child td {
  border-bottom: none;
}

.report-title {
  min-width: 0;
}

.report-title strong {
  display: block;
  color: #244b35;
  font-size: 11px;
  overflow-wrap: anywhere;
  line-height: 1.5;
}

.report-title small {
  display: block;
  color: #94a198;
  font-size: 10px;
  margin-top: 5px;
}

.campaign-name {
  display: inline-block;
  max-width: 100%;
  padding: 5px 7px;
  background: #e8f5ec;
  color: #16834a;
  border-radius: 6px;
  font-size: 10px;
  font-weight: 650;
  line-height: 1.5;
  overflow-wrap: anywhere;
  white-space: normal;
}

.amount-cell {
  color: #16834a !important;
  font-weight: 750;
  overflow-wrap: anywhere;
}

.action-buttons {
  display: flex;
  justify-content: center;
  align-items: center;
  gap: 0;
  flex-wrap: wrap;
}

.edit-button {
  --color: #16834a;
  --padding-start: 4px;
  --padding-end: 4px;
  margin: 0;
}

.delete-button {
  --color: #d34c4c;
  --padding-start: 4px;
  --padding-end: 4px;
  margin: 0;
}

.empty-cell {
  text-align: center !important;
  padding: 45px 15px !important;
}

.empty-cell ion-icon {
  display: block;
  font-size: 30px;
  color: #a4b8aa;
  margin: 0 auto 10px;
}

.empty-cell strong,
.empty-cell span {
  display: block;
}

.empty-cell strong {
  color: #557261;
  font-size: 13px;
}

.empty-cell span {
  color: #94a198;
  font-size: 11px;
  margin-top: 5px;
}

/* =====================================
   PAGINATION
===================================== */

.pagination-wrapper {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  margin-top: 17px;
  color: #829188;
  font-size: 11px;
}

.pagination-buttons {
  display: flex;
  gap: 5px;
}

.page-number,
.page-arrow {
  width: 30px;
  height: 30px;
  border: 1px solid #e1eae3;
  border-radius: 7px;
  background: #ffffff;
  color: #557261;
  cursor: pointer;
}

.page-number.active {
  background: #16834a;
  color: #ffffff;
  border-color: #16834a;
}

.page-arrow:disabled {
  opacity: 0.35;
}

/* =====================================
   LOADING DAN ERROR
===================================== */

.state-box {
  min-height: 180px;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  gap: 10px;
  color: #829188;
  font-size: 13px;
}

.state-box ion-spinner {
  color: #16834a;
}

.error-state ion-icon {
  color: #d34c4c;
  font-size: 25px;
}

/* =====================================
   MODAL REALISASI
===================================== */

.realisasi-modal {
  --width: 700px;
  --max-width: 95%;
  --height: auto;
  --max-height: 94%;
  --border-radius: 16px;
}

.modal-container {
  height: 100%;
  max-height: 94vh;
  display: flex;
  flex-direction: column;
  background: #ffffff;
  overflow: hidden;
  border-radius: 16px;
}

.modal-header {
  background: #16834a;
  color: #ffffff;
  padding: 20px 23px;
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  gap: 15px;
  flex-shrink: 0;
}

.modal-eyebrow {
  color: #d4efdd;
  font-size: 10px;
  font-weight: 750;
  letter-spacing: 1px;
}

.modal-header h2 {
  color: #ffffff;
  font-size: 19px;
  margin: 7px 0 5px;
}

.modal-header p {
  color: #e0f1e5;
  font-size: 11px;
  margin: 0;
}

.close-button {
  width: 34px;
  height: 34px;
  display: flex;
  align-items: center;
  justify-content: center;
  background: rgba(255, 255, 255, 0.16);
  border: none;
  border-radius: 8px;
  color: #ffffff;
  font-size: 21px;
}

.modal-body {
  padding: 22px;
  overflow-y: auto;
  flex: 1;
}

.form-grid {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 17px;
}

.form-group {
  min-width: 0;
}

.form-group.full-width {
  grid-column: 1 / -1;
}

.form-group label {
  display: block;
  color: #385a45;
  font-size: 12px;
  font-weight: 650;
  margin-bottom: 8px;
}

.form-group label span {
  color: #d34c4c;
}

.form-group ion-input {
  --background: #ffffff;
  --color: #244b35;
  --placeholder-color: #9ba9a0;
  --border-color: #dfe9e2;
  --border-radius: 8px;
  --highlight-color-focused: #16834a;
  font-size: 13px;
}

.form-select {
  width: 100%;
  height: 42px;
  padding: 0 12px;
  border: 1px solid #dfe9e2;
  border-radius: 8px;
  background: #ffffff;
  color: #244b35;
  font-family: inherit;
  font-size: 13px;
  outline: none;
}

.form-select:focus {
  border-color: #16834a;
}

.currency-input {
  height: 42px;
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 0 12px;
  border: 1px solid #dfe9e2;
  border-radius: 8px;
  color: #16834a;
  font-size: 13px;
  font-weight: 700;
}

.currency-input input {
  width: 100%;
  border: 0;
  outline: none;
  color: #244b35;
  font-size: 13px;
  background: transparent;
}

.field-hint {
  display: block;
  color: #829188;
  font-size: 10px;
  margin-top: 6px;
}

.date-input {
  width: 100%;
  height: 42px;
  padding: 0 12px;
  display: flex;
  align-items: center;
  gap: 9px;
  border: 1px solid #dfe9e2;
  border-radius: 8px;
  background: #ffffff;
  color: #244b35;
  font-size: 13px;
  text-align: left;
}

.date-input ion-icon:last-child {
  margin-left: auto;
  color: #829188;
}

.date-input .placeholder {
  color: #9ba9a0;
}

.editor-wrapper {
  overflow: hidden;
  border-radius: 9px;
}

.upload-box {
  min-height: 145px;
  padding: 16px;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-direction: column;
  gap: 7px;
  border: 2px dashed #cbded0;
  border-radius: 11px;
  background: #f9fcfa;
  cursor: pointer;
  position: relative;
  transition: 0.2s;
}

.upload-box:hover,
.upload-box.dragging {
  border-color: #16834a;
  background: #eef8f1;
}

.upload-icon {
  font-size: 28px;
  color: #16834a;
}

.upload-box strong {
  color: #385a45;
  font-size: 12px;
}

.upload-box span,
.upload-box small {
  color: #829188;
  font-size: 10px;
  text-align: center;
}

.image-preview {
  width: 100%;
  max-height: 190px;
  object-fit: contain;
  border-radius: 8px;
  background: #edf3ef;
}

.preview-info {
  display: flex;
  flex-direction: column;
  gap: 4px;
  text-align: center;
  overflow-wrap: anywhere;
}

.remove-file {
  position: absolute;
  top: 10px;
  right: 10px;
  width: 31px;
  height: 31px;
  border: none;
  border-radius: 50%;
  background: #fff0f0;
  color: #d34c4c;
  font-size: 16px;
}

.form-alert {
  padding: 11px 13px;
  border-radius: 8px;
  background: #fff0f0;
  color: #b42323;
  font-size: 12px;
  margin-bottom: 15px;
}

.modal-footer {
  margin-top: 22px;
}

.save-button {
  height: 44px;
  font-size: 13px;
  font-weight: 650;
}

/* =====================================
   MODAL TANGGAL
===================================== */

.date-modal {
  --width: 340px;
  --max-width: 95%;
  --height: auto;
  --border-radius: 16px;
}

.date-modal-container {
  padding: 17px;
  background: #ffffff;
}

.date-modal-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  color: #244b35;
  margin-bottom: 10px;
}

.date-modal-header button {
  border: 0;
  background: transparent;
  color: #557261;
  font-size: 20px;
}

.date-done-button {
  --background: #16834a;
  --border-radius: 8px;
  margin-top: 12px;
  text-transform: none;
}

/* =====================================
   TABLET
===================================== */

@media (max-width: 900px) {
  .realisasi-table th,
  .realisasi-table td {
    padding: 9px 5px;
    font-size: 10px;
  }

  .realisasi-table th {
    font-size: 10px;
  }

  .report-title strong {
    font-size: 10px;
  }

  .campaign-name {
    font-size: 9px;
    padding: 4px 5px;
  }
}

/* =====================================
   SMARTPHONE
===================================== */

@media (max-width: 650px) {
  .page-container {
    padding: 23px 14px 32px;
  }

  .page-heading h1 {
    font-size: 24px;
  }

  .stats-grid {
    gap: 10px;
  }

  .stat-card {
    padding: 13px 10px;
    gap: 9px;
  }

  .stat-icon {
    width: 37px;
    height: 37px;
    font-size: 19px;
  }

  .stat-info strong {
    font-size: 15px;
  }

  .table-section {
    padding: 15px 10px;
  }

  .section-heading {
    align-items: flex-start;
    flex-direction: column;
  }

  .add-button {
    width: 100%;
    margin: 0;
  }

  /* FILTER MOBILE */

  /* FILTER MOBILE */

.filter-area {
  flex-direction: column;
  align-items: stretch;
  gap: 9px;
}

.search-box,
.sort-select,
.reset-button {
  width: 100%;
  box-sizing: border-box;
}

.search-box {
  min-height: 42px;
}

.filter-actions {
  width: 100%;
  flex-direction: column;
  align-items: stretch;
  gap: 9px;
}

.filter-actions .sort-select,
.filter-actions .reset-button {
  width: 100%;
  min-height: 42px;
  margin: 0;
}

.reset-button {
  justify-content: center;
}

  /* TABEL MOBILE */

  .realisasi-table {
    width: 100%;
    min-width: 0;
    table-layout: fixed;
  }

  .realisasi-table th:nth-child(1),
  .realisasi-table td:nth-child(1) {
    width: 5%;
  }

  .realisasi-table th:nth-child(2),
  .realisasi-table td:nth-child(2) {
    width: 23%;
  }

  .realisasi-table th:nth-child(3),
  .realisasi-table td:nth-child(3) {
    width: 17%;
  }

  .realisasi-table th:nth-child(4),
  .realisasi-table td:nth-child(4) {
    width: 17%;
  }

  .realisasi-table th:nth-child(5),
  .realisasi-table td:nth-child(5) {
    width: 12%;
  }

  .realisasi-table th:nth-child(6),
  .realisasi-table td:nth-child(6) {
    width: 15%;
  }

  .realisasi-table th:nth-child(7),
  .realisasi-table td:nth-child(7) {
    width: 11%;
  }

  .realisasi-table th,
  .realisasi-table td {
    padding: 7px 3px;
    font-size: 9px;
    line-height: 1.4;
    overflow-wrap: anywhere;
  }

  .realisasi-table th {
    font-size: 9px;
  }

  .report-title strong {
    font-size: 9px;
  }

  .report-title small {
    font-size: 8px;
  }

  .campaign-name {
    font-size: 8px;
    padding: 3px 4px;
  }

  .action-buttons {
    gap: 0;
  }

  .edit-button,
  .delete-button {
    --padding-start: 2px;
    --padding-end: 2px;
    margin: 0;
    font-size: 10px;
  }

  .pagination-wrapper {
    align-items: flex-start;
    flex-direction: column;
  }

  .realisasi-modal {
    --width: 100%;
    --max-width: 100%;
    --height: 100%;
    --max-height: 100%;
    --border-radius: 0;
  }

  .modal-container {
    max-height: 100%;
    border-radius: 0;
  }

  .modal-header {
    padding: 18px 16px;
  }

  .modal-body {
    padding: 18px 16px;
  }

  .form-grid {
    grid-template-columns: 1fr;
    gap: 15px;
  }

  .form-group.full-width {
    grid-column: auto;
  }
}
</style>