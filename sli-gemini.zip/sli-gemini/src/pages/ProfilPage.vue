
<template>
  <ion-page>
    <ion-header>
      <ion-toolbar color="primary">
        <ion-title>Profil Yayasan</ion-title>
      </ion-toolbar>
    </ion-header>

    <ion-content class="ion-padding">
      <ion-spinner v-if="loading" />

      <ion-text color="danger" v-if="error">
        <p>{{ error }}</p>
      </ion-text>

      <ion-card v-if="profil">
        <ion-card-header>
          <ion-card-title>
            {{ profil.nama_yayasan || profil.nama || 'Profil Yayasan' }}
          </ion-card-title>
        </ion-card-header>

        <ion-card-content>
          <p>{{ profil.deskripsi || profil.profil || 'Belum ada deskripsi.' }}</p>

          <p v-if="profil.alamat">
            <strong>Alamat:</strong> {{ profil.alamat }}
          </p>
          <p v-if="profil.telepon || profil.no_telp">
            <strong>Telepon:</strong> {{ profil.telepon || profil.no_telp }}
          </p>
          <p v-if="profil.email">
            <strong>Email:</strong> {{ profil.email }}
          </p>
          <p v-if="profil.website">
            <strong>Website:</strong> {{ profil.website }}
          </p>
        </ion-card-content>
      </ion-card>

      <ion-text v-if="!loading && !profil && !error">
        <p>Data profil belum tersedia.</p>
      </ion-text>
    </ion-content>
  </ion-page>
</template>

<script setup lang="ts">
import { onMounted, ref } from 'vue';
import {
  IonPage, IonHeader, IonToolbar, IonTitle, IonContent,
  IonCard, IonCardHeader, IonCardTitle, IonCardContent,
  IonSpinner, IonText
} from '@ionic/vue';
import api from '../services/api';

const profil = ref<Record<string, any> | null>(null);
const loading = ref(false);
const error = ref('');

onMounted(async () => {
  loading.value = true;

  try {
    const response = await api.get('/yayasan/profil');
    const result = response.data?.data ?? response.data;
    profil.value = Array.isArray(result) ? result[0] : result;
  } catch (err: any) {
    error.value = err.response?.data?.message || 'Gagal mengambil profil yayasan.';
  } finally {
    loading.value = false;
  }
});
</script>
